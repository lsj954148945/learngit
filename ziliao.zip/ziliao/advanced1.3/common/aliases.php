<?php
Yii::setPathOfAlias('common', dirname(__DIR__));
Yii::setPathOfAlias('publicModels',dirname(__FILE__).'/models');
Yii::setPathOfAlias('utils',dirname(__FILE__).'/Utils.php');
