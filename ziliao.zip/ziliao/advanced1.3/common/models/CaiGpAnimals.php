<?php

/**
 * This is the model class for table "cai_gp_animals".
 *
 * The followings are the available columns in table 'cai_gp_animals':
 * @property string $id
 * @property string $animals
 * @property string $kill
 * @property integer $j_id
 * @property integer $period_id
 */
class CaiGpAnimals extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'cai_gp_animals';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('j_id, period_id', 'numerical', 'integerOnly'=>true),
			array('animals', 'length', 'max'=>21),
			array('kill', 'length', 'max'=>9),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, animals, kill, j_id, period_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
            'jcxx'=>array(self::BELONGS_TO,'CaiJcxx','','on'=>'t.period_id=jcxx.period_id'),
            'author'=>array(self::BELONGS_TO,'CaiAuthor','a_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'animals' => '生肖名',
			'kill' => '杀生肖',
			'j_id' => '特码',
			'period_id' => '期数',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('animals',$this->animals,true);
		$criteria->compare('kill',$this->kill,true);
		$criteria->compare('j_id',$this->j_id);
		$criteria->compare('period_id',$this->period_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CaiGpAnimals the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
