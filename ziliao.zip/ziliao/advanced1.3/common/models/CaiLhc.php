<?php

/**
 * This is the model class for table "cai_lhc".
 *
 * The followings are the available columns in table 'cai_lhc':
 * @property string $id
 * @property integer $period_id
 * @property string $yx
 * @property string $yw
 * @property string $yh
 * @property string $bb
 * @property string $sm
 * @property integer $j_id
 */
class CaiLhc extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'cai_lhc';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('period_id, j_id', 'numerical', 'integerOnly'=>true),
			array('yx', 'length', 'max'=>5),
			array('yw, yh', 'length', 'max'=>4),
			array('bb', 'length', 'max'=>10),
			array('sm', 'length', 'max'=>20),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, period_id, yx, yw, yh, bb, sm, j_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'period_id' => '期数',
			'yx' => '绝杀一肖',
			'yw' => '绝杀一尾',
			'yh' => '绝杀一合',
			'bb' => '绝杀半波',
			'sm' => '综合杀马',
			'j_id' => '开奖结果',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('period_id',$this->period_id);
		$criteria->compare('yx',$this->yx,true);
		$criteria->compare('yw',$this->yw,true);
		$criteria->compare('yh',$this->yh,true);
		$criteria->compare('bb',$this->bb,true);
		$criteria->compare('sm',$this->sm,true);
		$criteria->compare('j_id',$this->j_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CaiLhc the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
