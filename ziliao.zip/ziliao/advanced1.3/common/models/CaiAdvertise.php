<?php

/**
 * This is the model class for table "cai_advertise".
 *
 * The followings are the available columns in table 'cai_advertise':
 * @property string $id
 * @property string $hf_src
 * @property integer $hf_position
 * @property string $hf_url
 * @property string $couplet_src
 * @property integer $couplet_position
 * @property string $couplet_url
 */
class CaiAdvertise extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'cai_advertise';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('couplet_position', 'numerical', 'integerOnly'=>true),
			array('hf_src, hf_url, couplet_src, couplet_url', 'length', 'max'=>50),
			array('hf_position', 'length', 'max'=>20),
			array('hf_alt', 'length', 'max'=>30),
			array('hf_intro', 'length', 'max'=>150),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, hf_src, hf_position, hf_url, couplet_src, couplet_position, couplet_url, hf_intro, hf_alt', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'hf_src' => '横幅图片',
			'hf_position' => '横幅显示位置',
            'hf_intro' => '横幅简介',
            'hf_alt' => '横幅alt属性',
            'hf_url' => '横幅链接地址',
            'couplet_src' => '对联图片',
            'couplet_position' => '对联显示位置(0:左边，1:右边)',
            'couplet_url' => '横幅链接地址',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('hf_src',$this->hf_src,true);
		$criteria->compare('hf_intro',$this->hf_intro,true);
		$criteria->compare('hf_alt',$this->hf_alt,true);
		$criteria->compare('hf_position',$this->hf_position);
		$criteria->compare('hf_url',$this->hf_url,true);
		$criteria->compare('couplet_src',$this->couplet_src,true);
		$criteria->compare('couplet_position',$this->couplet_position);
		$criteria->compare('couplet_url',$this->couplet_url,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CaiAdvertise the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
