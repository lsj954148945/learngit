<?php

/**
 * This is the model class for table "cai_user".
 *
 * The followings are the available columns in table 'cai_user':
 * @property integer $id
 * @property string $uname
 * @property string $passwd
 * @property integer $addtime
 * @property integer $updatetime
 */
class CaiUser extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'cai_user';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('uname, passwd', 'required'),
			array('addtime, updatetime', 'numerical', 'integerOnly'=>true),
			array('uname', 'length', 'max'=>20),
			array('passwd', 'length', 'max'=>32),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, uname, passwd, addtime, updatetime', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'uname' => '用户名',
			'passwd' => '密码',
			'addtime' => 'Addtime',
			'updatetime' => 'Updatetime',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('uname',$this->uname,true);
		$criteria->compare('passwd',$this->passwd,true);
		$criteria->compare('addtime',$this->addtime);
		$criteria->compare('updatetime',$this->updatetime);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CaiUser the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

    public function login($name,$password){
        $crp="caitong2017";
        $password=md5($crp.$password);
        $data=self::model()->find(array(
            'condition'=>'uname=:uname and passwd=:passwd',
            'params'=>array(':uname'=>$name,':passwd'=>$password)
        ));
        return $data ? true : false;
    }

    public function authenticate($usernames,$password){
        if(!empty($usernames) && !empty($password)){
            $data=CaiUser::model()->find('uname=:uname',array(':uname'=>$usernames));
            if($data)   return $data->passwd == $password ? true : false;
        }
    }
}
