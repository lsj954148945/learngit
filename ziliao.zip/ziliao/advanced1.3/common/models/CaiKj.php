<?php

/**
 * This is the model class for table "cai_kj".
 *
 * The followings are the available columns in table 'cai_kj':
 * @property string $id
 * @property integer $period_id
 * @property string $num_sym_col
 * @property string $next_kj_time
 * @property string $lottery_time
 * @property string $shengxiao
 * @property string $danshuang
 * @property string $bose
 * @property string $size
 * @property string $wuxing
 * @property string $tetou
 * @property string $weishu
 * @property string $hedanshuang
 * @property string $jiaye
 * @property string $menshu
 * @property string $duanwei
 * @property string $yinyang
 * @property string $tiandi
 * @property string $jixiong
 * @property string $heibai
 * @property string $sexiao
 * @property string $bihua
 * @property string $sex
 * @property string $zonghedanshuang
 */
class CaiKj extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'cai_kj';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('period_id, num_sym_col, next_kj_time', 'required'),
			array('period_id', 'numerical', 'integerOnly'=>true),
			array('num_sym_col', 'length', 'max'=>200),
			array('next_kj_time', 'length', 'max'=>20),
			array('lottery_time, zonghedanshuang', 'length', 'max'=>15),
			array('shengxiao, danshuang, bose, size, wuxing, menshu, duanwei, yinyang, tiandi, jixiong, heibai, sex', 'length', 'max'=>5),
			array('tetou, weishu, hedanshuang, jiaye, sexiao, bihua', 'length', 'max'=>10),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, period_id, num_sym_col, next_kj_time, lottery_time, shengxiao, danshuang, bose, size, wuxing, tetou, weishu, hedanshuang, jiaye, menshu, duanwei, yinyang, tiandi, jixiong, heibai, sexiao, bihua, sex, zonghedanshuang', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
            'period'=>array(self::BELONGS_TO,'CaiPeriods','','on'=>'t.period_id=period.periods'),
            'jcxx'=>array(self::BELONGS_TO,'CaiJcxx','','on'=>'t.period_id=jcxx.period_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'period_id' => '开奖期数',
			'num_sym_col' => '开奖号码、生肖、颜色',
			'next_kj_time' => '下期开奖时间',
			'lottery_time' => '搅珠日期',
			'shengxiao' => '生肖',
			'danshuang' => '单双',
			'bose' => '波色',
			'size' => '大小',
			'wuxing' => '五行',
			'tetou' => '特头',
			'weishu' => '尾数',
			'hedanshuang' => '和单双',
			'jiaye' => '家野',
			'menshu' => '门数',
			'duanwei' => '段位',
			'yinyang' => '阴阳',
			'tiandi' => '天地',
			'jixiong' => '吉凶',
			'heibai' => '黑白',
			'sexiao' => '色肖',
			'bihua' => '笔画',
			'sex' => '男女',
			'zonghedanshuang' => '总和单双',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('period_id',$this->period_id);
		$criteria->compare('num_sym_col',$this->num_sym_col,true);
		$criteria->compare('next_kj_time',$this->next_kj_time,true);
		$criteria->compare('lottery_time',$this->lottery_time,true);
		$criteria->compare('shengxiao',$this->shengxiao,true);
		$criteria->compare('danshuang',$this->danshuang,true);
		$criteria->compare('bose',$this->bose,true);
		$criteria->compare('size',$this->size,true);
		$criteria->compare('wuxing',$this->wuxing,true);
		$criteria->compare('tetou',$this->tetou,true);
		$criteria->compare('weishu',$this->weishu,true);
		$criteria->compare('hedanshuang',$this->hedanshuang,true);
		$criteria->compare('jiaye',$this->jiaye,true);
		$criteria->compare('menshu',$this->menshu,true);
		$criteria->compare('duanwei',$this->duanwei,true);
		$criteria->compare('yinyang',$this->yinyang,true);
		$criteria->compare('tiandi',$this->tiandi,true);
		$criteria->compare('jixiong',$this->jixiong,true);
		$criteria->compare('heibai',$this->heibai,true);
		$criteria->compare('sexiao',$this->sexiao,true);
		$criteria->compare('bihua',$this->bihua,true);
		$criteria->compare('sex',$this->sex,true);
		$criteria->compare('zonghedanshuang',$this->zonghedanshuang,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CaiKj the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
