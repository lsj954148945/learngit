<?php

/**
 * This is the model class for table "cai_general_config".
 *
 * The followings are the available columns in table 'cai_general_config':
 * @property integer $id
 * @property string $config_ptsjg
 * @property string $config_jzt
 * @property string $config_mystery
 * @property string $config_sixanimals
 * @property string $config_tp
 * @property string $config_yjyx
 * @property string $config_mixed
 */
class CaiGeneralConfig extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'cai_general_config';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('config_ptsjg, config_jzt, config_mystery, config_sixanimals, config_tp, config_yjyx, config_mixed, config_xggp, xg_url, config_sqsx, picture_area, pyramid_area', 'length', 'max'=>200),
			array('url', 'length', 'max'=>50),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, config_ptsjg, config_jzt, config_mystery, config_sixanimals, config_tp, config_yjyx, config_mixed, config_xggp, config_sqsx, url, xg_url, picture_area, pyramid_area', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
            'url' => '综合采集地址',
            'xg_url' => '香港挂牌采集地址',
			'config_ptsjg' => '平特输尽光规则',
			'config_jzt' => '金字塔采集规则',
            'pyramid_area' => '金字塔替换规则',
            'config_mystery' => '玄机采集规则',
            'config_sixanimals' => '六和绝杀规则',
            'config_tp' => '特平采集规则',
            'config_yjyx' => '一句一肖采集规则',
            'config_mixed' => '综合资料采集规则',
            'config_xggp' => '香港挂牌采集规则',
            'config_sqsx' => '三期四肖采集规则',
            'picture_area' => '彩图采集规则',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('url',$this->url,true);
		$criteria->compare('xg_url',$this->url,true);
		$criteria->compare('config_ptsjg',$this->config_ptsjg,true);
		$criteria->compare('config_jzt',$this->config_jzt,true);
		$criteria->compare('pyramid_area',$this->pyramid_area,true);
		$criteria->compare('config_mystery',$this->config_mystery,true);
		$criteria->compare('config_sixanimals',$this->config_sixanimals,true);
		$criteria->compare('config_tp',$this->config_tp,true);
		$criteria->compare('config_yjyx',$this->config_yjyx,true);
		$criteria->compare('config_mixed',$this->config_mixed,true);
		$criteria->compare('config_xggp',$this->config_xggp,true);
		$criteria->compare('config_sqsx',$this->config_sqsx,true);
		$criteria->compare('picture_area',$this->picture_area,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CaiGeneralConfig the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
