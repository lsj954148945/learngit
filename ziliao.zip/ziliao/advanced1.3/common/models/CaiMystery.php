<?php

/**
 * This is the model class for table "cai_mystery".
 *
 * The followings are the available columns in table 'cai_mystery':
 * @property string $id
 * @property string $kbs
 * @property string $slx
 * @property string $cyz
 * @property integer $j_id
 * @property string $bs
 * @property string $question
 * @property string $explain
 * @property integer $period_id
 */
class CaiMystery extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'cai_mystery';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('period_id', 'numerical', 'integerOnly'=>true),
			array('kbs, slx, cyz', 'length', 'max'=>30),
			array('bs', 'length', 'max'=>10),
			array('question', 'length', 'max'=>80),
			array('explain', 'length', 'max'=>255),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, kbs, slx, cyz, bs, question, explain, period_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
            'jcxx'=>array(self::BELONGS_TO,'CaiJcxx','','on'=>'t.period_id=jcxx.period_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'kbs' => '看波色',
			'slx' => '杀两肖',
			'cyz' => '猜一字',
			'bs' => '波色',
			'question' => '问题',
			'explain' => '解释',
			'period_id' => '期数',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('kbs',$this->kbs,true);
		$criteria->compare('slx',$this->slx,true);
		$criteria->compare('cyz',$this->cyz,true);
		$criteria->compare('bs',$this->bs,true);
		$criteria->compare('question',$this->question,true);
		$criteria->compare('explain',$this->explain,true);
		$criteria->compare('period_id',$this->period_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CaiMystery the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
