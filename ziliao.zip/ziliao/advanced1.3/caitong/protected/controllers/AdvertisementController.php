<?php

class AdvertisementController extends AdminController{
    public function actionIndex(){
        $ad=CaiAdvertise::model()->findAll(array("condition"=>"hf_src is not null","order"=>"id desc","limit"=>Utils::PAGE_SIZE_FIFTEEN));
        $this->render("index",array("ad"=>$ad));
    }

    public function actionAdd(){
        $model=new CaiAdvertise();
        if(isset($_POST["CaiAdvertise"])){
            $name=$this->getImg($_FILES["CaiAdvertise"]["name"],"../upload/image/banner/","hf_src");
            $model->attributes=$_POST["CaiAdvertise"];
            $model->hf_src=$name;
            $model->hf_position=$_POST["CaiAdvertise"]["hf_position"];
            if($model->save()){
                move_uploaded_file($_FILES["CaiAdvertise"]["tmp_name"]["hf_src"],$name);
                $this->redirect($this->createUrl("advertisement/index"));
            }else{
                $this->redirect($this->createUrl("advertisement/add",array("model"=>$_POST["CaiAdvertise"])));
            }
        }
        $this->render("add",array("model"=>$model));
    }

    public function actionUpdate(){
        $id=(int) Yii::app()->request->getParam("id");
        $model=CaiAdvertise::model()->find("id =:id",array(":id"=>$id));
        if(isset($_POST["CaiAdvertise"])){
            $name=$this->getImg($_FILES["CaiAdvertise"]["name"],"../upload/image/banner/","hf_src");
            $model->hf_src=empty($name) ? $model->hf_src : $name;
            $model->hf_position=$_POST["CaiAdvertise"]["hf_position"];
            $model->hf_alt=$_POST["CaiAdvertise"]["hf_alt"];
            $model->hf_url=$_POST["CaiAdvertise"]["hf_url"];
            if($model->save()){
                move_uploaded_file($_FILES["CaiAdvertise"]["tmp_name"]["hf_src"],$name);
                $this->redirect($this->createUrl("advertisement/index"));
            }else{
                $this->redirect($this->createUrl("advertisement/update",array("id"=>$id)));
            }
        }
        $this->render("update",array("model"=>$model));
    }

    public function actionDelete(){
        $id=(int)Yii::app()->request->getParam("id");
        if(isset($id)){
            $res=CaiAdvertise::model()->deleteByPk($id);
            die(json_encode($res ? 200 : -200));
        }
    }

    public function actionCouplet(){
        $model=CaiAdvertise::model()->findAll(array("condition"=>"couplet_src is not null"));
        $this->render("couplet",array("model"=>$model));
    }

    public function actionAddCouplet(){
        $model=new CaiAdvertise();
        $model->couplet_position=1;
        if(isset($_POST["CaiAdvertise"])){
            $name=$this->getImg($_FILES["CaiAdvertise"]["name"],"../upload/image/couplet/","couplet_src");
            $model->couplet_url=$_POST["CaiAdvertise"]["couplet_url"];
            $model->couplet_position=$_POST["CaiAdvertise"]["couplet_position"];
            $model->couplet_src=$name;
            $res=move_uploaded_file($_FILES["CaiAdvertise"]["tmp_name"]["couplet_src"],$name);
            $this->redirect($this->createUrl($model->save() && $res ? "advertisement/couplet" : "advertisement/addCouplet"));
        }
        $this->render("addCouplet",array("model"=>$model));
    }

    public function actionUpdateCouplet(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiAdvertise::model()->findByPk($id);
        if(isset($_POST["CaiAdvertise"])){
            $name=$this->getImg($_FILES["CaiAdvertise"]["name"],"../upload/image/couplet/","couplet_src");
            $model->couplet_url=$_POST["CaiAdvertise"]["couplet_url"];
            $model->couplet_position=$_POST["CaiAdvertise"]["couplet_position"];
            $model->couplet_src=$name ? $name : $model->couplet_src;
            !empty($name) ? move_uploaded_file($_FILES["CaiAdvertise"]["tmp_name"]["couplet_src"],$name) : "";
            if($model->save())      $this->redirect($this->createUrl("advertisement/couplet"));
            else        $this->redirect($this->createUrl("advertisement/updateCouplet"));
        }
        $this->render("updateCouplet",array("model"=>$model));
    }

    public function actionDeleteCouplet(){
        $id=(int)Yii::app()->request->getParam("id");
        $res=CaiAdvertise::model()->deleteByPk($id);
        die(json_encode($res ? 200 : -200));
    }

    public function getImg($data,$path,$coloum){
        if(isset($data) && !empty($data[$coloum])){
            if(!is_dir($path))  mkdir($path,0777,true);
            $bname=$data[$coloum];
            $ext=explode(".",$bname)[1];
            if(in_array($ext,Utils::$ext_name))     $name=$path.time().".".$ext;
            return $name;
        }
    }

}
