<?php
/**
 * Created by JetBrains PhpStorm.
 * User: SE MON
 * Date: 17-7-22
 * Time: 下午6:03
 * To change this template use File | Settings | File Templates.
 */

class AuthorController extends AdminController{
    public function actionIndex(){
        $page=(int)Yii::app()->request->getParam("page");
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=CaiAuthor::model()->count();
        $pages=ceil($total/$pageSize);
        $condition=array("limit"=>$pageSize,"order"=>"id desc","offset"=>0);
        if($page && $page > 0){
            $offset=($page-1)*$pageSize;
            $condition["offset"]=$offset;
            $data=CaiAuthor::model()->findAll($condition);
            $html="";
            foreach($data as $k => $v){
                $html .= '<tr>
                                <td><input type="checkbox" name="post[]" value="'.$v->id.'"></td>
                                <td>'.$v->id.'</td>
                                <td>'.$v->name.'</td>
                                <td>'.date("Y-m-d H:i:s",$v->addtime).'</td>
                                <td>
                                    <div id="caozuo">
                                        <a href="'.$this->createUrl("author/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                        <a onclick="deleteAuthor('.$v->id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                                    </div>
                                </td>
                            </tr>';
            }
            die(json_encode($html));
        }
        $data=CaiAuthor::model()->findAll($condition);
        $this->render("index",array("data"=>$data,"pages"=>$pages));
    }

    public function actionAdd(){
        $model=new CaiAuthor();
        if(isset($_POST["CaiAuthor"])){
            $model->attributes=$_POST["CaiAuthor"];
            $model->addtime=time();
            $res=$model->save();
            $this->redirect($this->createUrl($res ? "author/index" : "author/add"));
        }
        $this->render("add",array("model"=>$model));
    }

    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiAuthor::model()->findByPk($id);
        if(isset($_POST["CaiAuthor"])){
            $model->attributes=$_POST["CaiAuthor"];
            $model->updatetime=time();
            $res=$model->save();
            $this->redirect($this->createUrl($res ? "author/index" : "author/update&id=".$model->id));
        }
        $this->render("update",array("model"=>$model));
    }

    public function actionDelete(){
        $id=(int)Yii::app()->request->getParam("id");
        $result=CaiAuthor::model()->deleteByPk($id);
        die(json_encode($result ? 200 : -200));
    }
}