<?php
/**
 * Created by JetBrains PhpStorm.
 * User: SE MON
 * Date: 17-8-2
 * Time: 下午2:18
 * To change this template use File | Settings | File Templates.
 */

class PictureController extends AdminController{

    public function actionLotteryPic(){
        $page=(int)Yii::app()->request->getParam("page");
        $ajax=Yii::app()->request->getParam('isAjax');
        $pageSize=Utils::PAGE_SIZE_TEN;
        $condition=array("condition"=>"lottery_content is not null","order"=>"id desc","limit"=>$pageSize,"offset"=>0);
        $total=CaiPictures::model()->count($condition["condition"]);
        $pages=ceil($total/$pageSize);
        if($page && $page > 0 && $page <= $pages && $ajax){
            $num=$total-($page-1)*$pageSize;
            $condition["offset"]=($page-1)*$pageSize;
            $model=CaiPictures::model()->findAll($condition);
            $html="";
            foreach($model as $k => $v){
                $html .='<tr>
                            <td><input type="checkbox" name="numberId" value="'.$v->id.'"></td>
                            <td>'.$v->id.'</td>
                            <td>'.$v->name.'</td>
                            <td>'.strip_tags($v->lottery_content).'</td>
                            <td>
                                <a href="'.$this->createUrl("picture/updateLotteryPic",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                <a onclick="deleteMysteryAnimal('.$v->id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                            </td>
                        </tr>';
                $num--;
            }
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $model=CaiPictures::model()->findAll($condition);
        $this->render("lotteryPic",array("model"=>$model,"pages"=>$pages,"total"=>$total,"page"=>$page,"pageSize"=>$pageSize));
    }

    public function actionAddLotteryPic(){
        $model=new CaiPictures();
        if(isset($_POST["CaiPictures"])){
            $model->attributes=$_POST["CaiPictures"];
            $this->redirect($this->createUrl($model->save() ? "picture/lotteryPic" : "picture/addLotteryPic"));
        }
        $this->render("addLotteryPic",array("model"=>$model));
    }

    public function actionUpdateLotteryPic(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiPictures::model()->findByPk($id);
        if(isset($_POST["CaiPictures"])){
            $model->attributes=$_POST["CaiPictures"];
            $this->redirect($this->createUrl($model->save() ? "picture/lotteryPic" : "picture/updateLotteryPic&id=".$model->id));
        }
        $this->render("updateLotteryPic",array("model"=>$model));
    }

    public function actionDelete(){
        $id=(int)Yii::app()->request->getParam("id");
        $res=CaiPictures::model()->deleteByPk($id);
        die(json_encode($res ? 200 : -200));
    }

}