<?php

class GpSixAnimalsController extends AdminController{
    public function actionIndex(){
        $page=(int)Yii::app()->request->getParam("page");
        $ajax=Yii::app()->request->getParam("isAjax");
        $page=$page ? $page : 1;
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=CaiGpAnimals::model()->count();
        $pages=ceil($total/$pageSize);
        $condition=array("order"=>"t.period_id desc","limit"=>$pageSize,"offset"=>0);
        if($page && $page > 0 && $page <= $pages && $ajax){
            $condition["offset"]=($page-1)*$pageSize;
            $model=CaiGpAnimals::model()->findAll($condition);
            $html="";
            $num=$total-($page-1)*$pageSize;
            foreach($model as $k => $v){
                $html .='<tr>
                            <td><input type="checkbox" name="numberId" value="'.$v->id.'"></td>
                            <td>'.$num.'</td>
                            <td>'.$v->period_id.'</td>
                            <td>'.$v->animals.'</td>
                            <td>'.$v->kill.'</td>
                            <td>
                                <a href="'.$this->createUrl("gpSixAnimals/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                <a onclick="deleteGpSixAnimals('.$v->id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                            </td>
                        </tr>';
                $num--;
            }
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $model=CaiGpAnimals::model()->findAll($condition);
        $this->render("index",array("model"=>$model,"pages"=>$pages,"page"=>$page,"pageSize"=>$pageSize,"total"=>$total));;
    }

    public function actionAdd(){
        $model=new CaiGpAnimals();
        if(isset($_POST["CaiGpAnimals"])){
            $model->attributes=$_POST["CaiGpAnimals"];
            $model->period_id=trim($_POST["CaiGpAnimals"]["period_id"]);
            $this->redirect($this->createUrl($model->save() ? "gpSixAnimals/index" : "gpSixAnimals/add"));
        }
        $this->render("add",array("model"=>$model));
    }

    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiGpAnimals::model()->findByPk($id);
        if(isset($_POST["CaiGpAnimals"])){
            $model->attributes=$_POST["CaiGpAnimals"];
            $model->period_id=trim($_POST["CaiGpAnimals"]["period_id"]);
            $this->redirect($this->createUrl($model->save() ? "gpSixAnimals/index" : "gpSixAnimals/update&id=".$model->id));
        }
        $this->render("update",array("model"=>$model));
    }

    public function actionDelete(){
        $id=(int)Yii::app()->request->getParam("id");
        $res=CaiGpAnimals::model()->deleteByPk($id);
        die(json_encode($res ? 200 : -200));
    }

}