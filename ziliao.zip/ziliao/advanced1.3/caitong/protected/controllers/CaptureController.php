<?php

class CaptureController extends AdminController{
    public function actionIndex(){
        $page=(int)Yii::app()->request->getParam("page");
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=CaiCapture::model()->count();
        $pages=ceil($total/$pageSize);
        $condition=array("limit"=>$pageSize,"offset"=>0);
        if($page > 0 && $page <= $pages){
            $condition["offset"]=($page-1)*$pageSize;
            $model=CaiCapture::model()->findAll($condition);
            $html="";
            foreach($model as $k => $v){
                $html .='<tr>
                        <td><input type="checkbox" name="post[]" value="'.$v->id.'"></td>
                        <td>'.$v->id.'</td>
                        <td>'.$v->config_name.'</td>
                        <td>'.$v->capture_url.'</td>
                        <td>'.htmlentities($v->url_area).'</td>
                        <td>'.htmlentities($v->title_rule).'</td>
                        <td>'.htmlentities($v->content_rule).'</td>
                        <td>'.htmlentities($v->author_rule).'</td>
                        <td>'.$v->contain_url.'</td>
                        <td>
                            <div id="caozuo">
                                <a href="'.$this->createUrl("capture/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                <a onclick="capture('.$v->id.')" class="btn btn-s-md btn-primary mf20 ">采集</a>
                                <a onclick="deleteCapture('.$v->id .')" class="btn btn-s-md btn-warning mf20">删除</a>
                            </div>
                        </td>
                    </tr>';
            }
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $model=CaiCapture::model()->findAll($condition);
        $this->render("index",array("model"=>$model,"pages"=>$pages));
    }

    public function actionAdd(){
        $model=new CaiCapture();
        $nav=CaiNav::model()->findAll();
        $periods=CaiPeriods::model()->findAll(array("order"=>"id desc"));
        if(isset($_POST["CaiCapture"])){
            $model->attributes=$_POST["CaiCapture"];
            $model->nav_id=$_POST["CaiCapture"]["type"] == 2 ? 0 : $_POST["CaiCapture"]["nav_id"];
            if($model->save())      $this->redirect($this->createUrl("capture/index"));
            else    $this->redirect($this->createUrl("capture/add"));
        }
        $this->render("add",array("model"=>$model,"nav"=>$nav,"periods"=>$periods));
    }

    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiCapture::model()->findByPk($id);
        $nav=CaiNav::model()->findAll();
        $periods=CaiPeriods::model()->findAll(array("order"=>"id desc"));
        if(isset($_POST["CaiCapture"])){
            $model->attributes=$_POST["CaiCapture"];
            if($model->save())      $this->redirect($this->createUrl("capture/index"));
            else    $this->redirect($this->createUrl("capture/update",array("id"=>$model->id)));
        }
        $this->render("update",array("model"=>$model,"nav"=>$nav,"periods"=>$periods));
    }

    public function actionDelete(){
        $id=(int)Yii::app()->request->getParam("id");
        $res=CaiCapture::model()->deleteByPk($id);
        die(json_encode($res ? 200 : -200));
    }

    //采集传奇高手贴以及栏目
    public function actionAddContent(){
        ini_set("max_execution_time",1200);
        $id=(int)Yii::app()->request->getParam("id");
        if($id > 0){
            $config=CaiCapture::model()->with("nav")->findByPk($id);
            $urls=array();
            if($config->type == 1){
                $info=file_get_contents($config->capture_url);
                $pages=intval($config->config_page);
                if($pages && $pages > 1){
                    $str=substr($config->capture_url,strrpos($config->capture_url,"/")+1);
                    preg_match('/[0-9]+/',$str,$number);
                    $start=intval($number[0]);
                    for($i=$start;$i<($start+$pages);$i++)      $data_url[]=$config->contain_url."index_".$i.".html";
                    $html=self::multiCurl($data_url);
                    $contents="";
                    foreach($html as $t)        $contents .=$t;
                    $nav_content=strip_tags($contents,"<a>");
                    preg_match_all('/(href=\".*html)+/',$nav_content,$test);
                    if(isset($test[0]) && count($test[0]) > 0){
                        if(!empty($config->contain_url)){
                            foreach($test[0] as $k => $v)
                                if(!stripos($v,$config->domain))  $test[0][$k]=$config->domain.str_replace('href="',"",$v);
                        }
                        $urls=$test[0];
                    }
                }else{
                    preg_match('/'.str_replace(Utils::$pattern,Utils::$replace,$config->url_area).'/ism',$info,$content);
                    $nav_content=strip_tags($content[0],"<a>");
                    preg_match_all('/(href=\".*html)+/',$nav_content,$test);
                    if(isset($test[0]) && count($test[0]) > 0){
                        if(!empty($config->contain_url)){
                            foreach($test[0] as $k => $v)
                                if(!stripos($v,$config->domain))  $test[0][$k]=$config->domain.str_replace('href="',"",$v);
                        }
                        $urls=$test[0];
                    }
                }
            }elseif($config->type == 2){
                $info=file_get_contents($config->capture_url);
                preg_match('/'.str_replace(Utils::$pattern,Utils::$replace,$config->url_area).'/ism',$info,$content);
                $content=strip_tags($content[0],"<a>");
                preg_match_all('/(href=\".*html)+/',$content,$test);
                if(isset($test[0]) && count($test[0]) > 0){
                    if(!empty($config->contain_url)){
                        foreach($test[0] as $k => $v)
                            if(!stripos($v,$config->domain))  $test[0][$k]=$config->domain.str_replace('href="',"",$v);
                    }
                    $urls=$test[0];
                }
            }
            $num=$this::captureContent($urls,$config);
            die(json_encode(array("msg"=>($config->type == 1 ? $config->nav->nav_name : "传奇高手贴")."共发布了".$num."条数据")));
        }
    }

    public function actionGeneral(){
        $model=CaiGeneralConfig::model()->find();
        if(!$model)     $model=new CaiGeneralConfig();
        if(isset($_POST["CaiGeneralConfig"])){
            $model->attributes=$_POST["CaiGeneralConfig"];
            $model->save();
            $this->redirect($this->createUrl("capture/general"));
        }
        $this->render("general",array("model"=>$model));
    }

    public function actionLottery(){
        $model=CaiCaptureLottery::model()->find();
        if(!$model)     $model=new CaiCaptureLottery();
        if(isset($_POST["CaiCaptureLottery"])){
            $model->attributes=$_POST["CaiCaptureLottery"];
            $model->save();
            $this->redirect($this->createUrl("capture/lottery"));
        }
        $this->render("lottery",array("model"=>$model));
    }

    public function actionPicture(){
        $model=CaiGeneralConfig::model()->find();
        if(!$model)     $model=new CaiCaptureLottery();
        if(isset($_POST["CaiGeneralConfig"])){
            $model->picture_area=$_POST["CaiGeneralConfig"]["picture_area"];
            $model->save();
            $this->redirect($this->createUrl("capture/picture"));
        }
        $this->render("picture",array("model"=>$model));
    }

    //采集对应的栏目内容
    public static function captureContent($urls,$rule){
        $i=0;
        $data=self::multiCurl($urls);
        foreach($data as $k => $v){
            $code=mb_detect_encoding($v,Utils::$all_code);
            $contents=mb_convert_encoding($v,"utf-8",$code);
            preg_match("/".str_replace(Utils::$pattern,Utils::$replace,$rule->title_rule)."/ism",$contents,$title);
            preg_match("/".str_replace(Utils::$pattern,Utils::$replace,$rule->content_rule)."/ism",$contents,$content);
            preg_match("/".str_replace(Utils::$pattern,Utils::$replace,$rule->author_rule)."/ism",$contents,$author);

            $content_pattern=array("/".str_replace(Utils::$pattern,Utils::$replace,$rule->filter_content_area)."/ism","/(<script>.*?<\\/script>)+/ism","/<div class=\"tlinks\">.*<div class=\"page\">/ism");
            $coloum=array(
                "title"=>isset($title[0]) ? strip_tags($title[0]) : "",
                "author_name"=>isset($author[0]) ? str_replace("高手作者:","",strip_tags($author[0])) : "",
                //"content"=>isset($content[0]) ? trim(strip_tags(preg_replace($content_pattern,array("",""),$content[0]))) : "",
                "content"=>isset($content[0]) ? trim(preg_replace($content_pattern,array("",""),$content[0])) : "",
            );
            if($rule->type == 1){
                $coloum["nav_id"]=$rule->nav_id;
                try{
                    self::insertNav($coloum) ?  $i++ : $i;
                }catch (Exception $e){};
            }elseif($rule->type == 2){
                $coloum["period_id"]=intval(substr(trim(strip_tags($title[0])),0,9));
                try{
                    self::insertCqgst($coloum) ? $i++ : $i;
                }catch (Exception $e){};
            }
        }
        return $i;
    }

    //采集开奖
    public function actionCaptureLottery(){
        ini_set("max_execution_time",1200);
        $param=Yii::app()->request->getParam("lottery");
        $type=Yii::app()->request->getParam("type");
        if($param == "captureLottery"){
            $number=$tm=0;
            $lottery=CaiCaptureLottery::model()->find();
            $content=@file_get_contents($lottery->url);
            preg_match("/".preg_replace("/\\//","\\/",$lottery->rule)."/ism",$content,$lottery_content);
            $lottery_content=preg_replace(array("/<\\/tr>/","/<\\/td>/","/<\\/div>/","/<div class=\"hm blueBoClass\">/","/<div class=\"hm greenBoClass\">/","/<div class=\"hm redBoClass\">/"),array("[or]","[line]","[an]","blue[an]","green[an]","red[an]"),$lottery_content);
            $lottery_content=strip_tags($lottery_content[0]);
            $lottery_content=explode("[or]",$lottery_content);
            array_shift($lottery_content);
            array_pop($lottery_content);
            foreach($lottery_content as $key => $l){
                $lot=explode("[line]",$l);
                $sym_arr=explode("[an]",str_replace("[an][an]","[an]",$lot[2]));
                $sym="";
                $period=intval(substr(trim($lot[1]),0,3));
                $arr=explode("[an]",$lot[3]);
                foreach($sym_arr as $k => $v){
                    if($k<18){
                        $sym .= $v.($k % 3 == 0 || $k % 3 == 1 ? "：" : ($k < 17 ? "，" : ""));
                    }
                }
                $data=array(
                    "period_id"=>$period,"num_sym_col"=>trim($sym),"name"=>trim($arr[2]),"number"=>trim($arr[1]),"color"=>trim($arr[0]),"lottery_time"=>trim($lot[0]),
                    "shengxiao"=>trim($lot[4]),"danshuang"=>trim($lot[5]),"bose"=>trim($lot[6]),"size"=>trim($lot[7]),"wuxing"=>trim($lot[8]),
                    "tetou"=>trim($lot[9]),"weishu"=>trim($lot[10]),"hedanshuang"=>trim($lot[11]),"jiaye"=>trim($lot[12]),"menshu"=>trim($lot[13]),
                    "duanwei"=>trim($lot[14]),"yinyang"=>trim($lot[15]),"tiandi"=>trim($lot[16]),"jixiong"=>trim($lot[17]),"heibai"=>trim($lot[18]),
                    "sexiao"=>trim($lot[19]),"bihua"=>trim($lot[20]),"sex"=>trim($lot[21]),"zonghedanshuang"=>trim($lot[22])
                );
                try{
                    if(self::insertKj($data)) $number++;
                    if(self::insertJcxx($data))   $tm++;
                    self::insertPeriod($period);
                }catch (Exception $e){};
                if(!$type)      break;
            }
            die(json_encode("开奖信息共采集了 $number 条！特码共采集了 $tm 条"));
        }
    }

    //采集彩图
    public function actionCapturePicture(){
        ini_set("max_execution_time",1200);
        $model=CaiGeneralConfig::model()->find();
        if(isset($_POST["picture"])){
            $html=@file_get_contents($model->url);
            preg_match("/".str_replace("/","\\/",$model->picture_area)."/ism",$html,$content);
            if(isset($content[0]))  preg_match_all('/src\s*=\s*(\")(.*?)\\1/i',$content[0],$url);
            if(isset($url[2])){
                $path="../upload/image/xgpicture/";
                $xgPicture=new CaiXgPicture();
                $gpct=self::getImage($url[2][0],$path.time()."1.jpg");
                $mdxj=self::getImage($url[2][1],$path.time()."2.jpg");
                if(empty($gpct) && empty($mdxj)){
                    die(json_encode("没有采集到任何图片"));
                }else{
                    $xgPicture->gpct=$gpct;
                    $xgPicture->mdxj=$mdxj;
                    $xgPicture->save();
                    $msg="";
                    if($gpct)   $msg.="挂牌彩图采集了1张图片    ";
                    if($mdxj)   $msg.="秘典玄机采集了1张图片";
                    die(json_encode($msg));
                }
            }
        }
    }

    public static function getImage($url,$filename){
        if(empty($url) && empty($filename))    return false;
        ob_start();
        readfile($url);
        $img=ob_get_contents();
        ob_end_clean();
        $fp=fopen($filename,"a");
        $size=fwrite($fp,$img);
        fclose($fp);
        return $size > 0 ? $filename : "";
    }

    public static function insertCqgst($data=array()){
        if($data){
            $model=new CaiCqgst();
            $model->title=$data["title"];
            $model->content=$data["content"];
            $model->author_name=$data["author_name"];
            $model->period_id=$data["period_id"];
            $model->addtime=time();
            $model->mobile_title=$data["author_name"];
            if($model->save())      return true;
        }
        return false;
    }

    public static function insertNav($data=array()){
        if($data){
            $model=new CaiNews();
            $model->title=$data["title"];
            $model->content=$data["content"];
            $model->nav_id=$data["nav_id"];
            $model->author_name=$data["author_name"];
            $model->publish_time=time();
            $model->status=1;
            if($model->save())      return true;
        }
        return false;
    }

    public static function createCh($url){
        $ch=curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_USERAGENT,"Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0)");
        curl_setopt($ch,CURLOPT_REFERER,$url);//设置来源
        curl_setopt($ch,CURLOPT_ENCODING,"gzip");//编码压缩
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($ch,CURLOPT_FOLLOWLOCATION,1);
        curl_setopt($ch,CURLOPT_MAXREDIRS,5);
        curl_setopt($ch,CURLOPT_TIMEOUT,60);
        curl_setopt($ch,CURLOPT_HEADER,0);
        return $ch;
    }

    public static function multiCurl($urls=array()){
        if($urls){
            $curl=$data=array();
            $handle=curl_multi_init();
            foreach($urls as $k => $v){
                $curl[$k]=self::createCh($v);
                curl_multi_add_handle($handle,$curl[$k]);
            }
            do{
                $mrc=curl_multi_exec($handle,$active);
            }while($mrc == CURLM_CALL_MULTI_PERFORM);
            while($active && $mrc == CURLM_OK){
                if(curl_multi_select($handle) != -1)  usleep(10);
                do{
                    $mrc=curl_multi_exec($handle,$active);
                }while($mrc==CURLM_CALL_MULTI_PERFORM);
            }
            foreach($curl as $k1 => $v1){
                if(curl_error($curl[$k1]) == "")    $data[$k1]=(string)curl_multi_getcontent($curl[$k1]);
                curl_multi_remove_handle($handle,$curl[$k1]);
                curl_close($curl[$k1]);
            }
            return $data;
        }
        return false;
    }

    //采集综合内容
    public function actionCaptureMixed(){
        ini_set("max_execution_time",1200);
        $param=Yii::app()->request->getParam("mixed");
        $type=Yii::app()->request->getParam("type");
        if(isset($param) && $param == "captureMixed"){
            $general=CaiGeneralConfig::model()->find();
            $content=file_get_contents($general->url);
            $ptsjg_num=$pyramid_num=$mystery_num=$six_num=$tp_num=$yjyx_num=$mixed_num=$xggp_num=$sqsx_num=0;

            //平特输尽光
            preg_match("/".preg_replace("/\\//","\\/",$general->config_ptsjg)."/ism",$content,$ptsjg);
            $ptsjg=strip_tags(preg_replace(array("/<\\/tr>/","/<\\/td>/"),array("[or]","[line]"),$ptsjg[0]));
            $ptsjg=explode("[or]",$ptsjg);
            array_pop($ptsjg);
            if(!$type) $ptsjg=array($ptsjg[0]);
            foreach($ptsjg as $k1 => $pt){
                $pt=array_unique(explode("[line]",$pt));
                $pt_data=array("period_id"=>intval(substr(trim($pt[0]),0,3)),"pt_title"=>$pt[2],"pt_answer"=>$pt[3],"jg_title"=>isset($pt[6]) ? $pt[6] : $pt[2]);
                try{
                    if(self::insertPtsjg($pt_data))     $ptsjg_num++;
                }catch (Exception $e){};
            }

            //金字塔
            preg_match("/".preg_replace("/\\//","\\/",$general->config_jzt)."/ism",$content,$pyramid);
            $pyramid=preg_replace(array("/<\\/tr>/","/<\\/td>/"),array("[or]","[line]"),$pyramid[0]);
            $pyramid=strip_tags(str_replace(strpos($general->url,"072888.co") === false ? trim($general->pyramid_area) : "请所有彩民牢记本站永久域名:www.072888.com 以上资料长期免费公开.请大家互相转告！","[info]",$pyramid));
            $pyramid=explode("[info]",$pyramid);
            array_shift($pyramid);
            if(!$type) $pyramid=array($pyramid[0]);
            foreach($pyramid as $k => $py){
                if(!empty($py)){
                    $pyr1=explode("[or]",$py);
                    array_shift($pyr1);
                    array_pop($pyr1);
                    foreach($pyr1 as $v1){
                        $pyr2=explode("[line]",$v1);
                        $period=intval(substr(trim($pyr2[0]),0,3));
                        $pyramid_data=array("period_id"=>$period,"name"=>trim(mb_substr($pyr2[0],7)),"content"=>trim($pyr2[1]));
                        try{
                            if(self::insertPyramid($pyramid_data))  $pyramid_num++;
                        }catch (Exception $e){};
                    }
                }
            }

            //六肖
            preg_match("/".preg_replace("/\\//","\\/",$general->config_sixanimals)."/ism",$content,$sixanimals);
            $sixanimals=strip_tags(preg_replace(array("/<\\/tr>/","/<\\/td>/"),array("[or]","[line]"),$sixanimals[0]));
            $sixanimals=explode("[or]",$sixanimals);
            array_shift($sixanimals);
            array_pop($sixanimals);
            if(!$type) $sixanimals=array($sixanimals[0]);
            foreach($sixanimals as $s){
                $six=explode("[line]",$s);
                $period=intval(substr(trim($six[0]),0,3));
                $six_data=array(
                    "period_id"=>$period,
                    "yx"=>trim(mb_substr($six[0],16)),
                    "yw"=>trim(mb_substr($six[1],14)),
                    "yh"=>trim(mb_substr($six[2],14)),
                    "bb"=>trim(mb_substr($six[3],14)),
                    "many_number"=>trim($six[4]),
                );
                try{
                    if(self::insertSixAnimals($six_data))   $six_num++;
                }catch (Exception $e){};
            }

            //平特
            preg_match("/".preg_replace("/\\//","\\/",$general->config_tp)."/ism",$content,$pt);
            $pt=strip_tags(preg_replace(array("/<\\/tr>/","/<\\/td>/"),array("[or]","[line]"),$pt[0]));
            $pt=explode("[or]",$pt);
            array_shift($pt);
            array_pop($pt);
            if(!$type) $pt=array($pt[0]);
            foreach($pt as $p){
                $pt1=explode("[line]",$p);
                $pt_data=array("period_id"=>intval(substr(trim($pt1[0]),0,3)),"tp_content"=>trim($pt1["1"]));
                try{
                    if(self::insertTp($pt_data))    $tp_num++;
                }catch (Exception $e){};
            }

            //一句一肖
            preg_match("/".preg_replace("/\\//","\\/",$general->config_yjyx)."/ism",$content,$xgyj);
            $xgyj=strip_tags(preg_replace(array("/<\\/tr>/","/<\\/td>/"),array("[or]","[line]"),$xgyj[0]));
            $xgyj=explode("[or]",$xgyj);
            array_shift($xgyj);
            array_pop($xgyj);
            if(!$type) $xgyj=array($xgyj[0]);
            foreach($xgyj as $xg){
                $yj=explode("[line]",$xg);
                $yj_data=array("period_id"=>intval(substr(trim($yj[1]),0,3)),"xjyx_content"=>trim($yj[1]));
                try{
                    if(self::insertYjyx($yj_data))      $yjyx_num++;
                }catch (Exception $e){};
            }

            //综合
            preg_match("/".preg_replace("/\\//","\\/",$general->config_mixed)."/ism",$content,$mixed);
            $mixed=strip_tags(preg_replace(array("/<\\/td>/","/<\\/font>/"),array("[or]","[line]"),$mixed[0]));
            $mixed=explode("[or]",$mixed);
            array_pop($mixed);
            if(!$type) $mixed=array($mixed[0]);
            foreach($mixed as $mi){
                $m=explode("[line]",$mi);
                $m=!isset($m[1]) ? explode(":",$m[0]) : $m;
                $mixed_data=array("name"=>trim($m[0]),"content"=>trim($m[1]));
                try{
                    if(self::insertMixed($mixed_data))     $mixed_num++;
                }catch (Exception $e){};
            }

            //三期必出四肖
            preg_match("/".preg_replace("/\\//","\\/",$general->config_sqsx)."/ism",$content,$sqsx);
            $sqsx=strip_tags(preg_replace(array("/<\\/tr>/","/<\\/td>/",),array("[or]","[line]"),$sqsx[0]));
            $sqsx=explode("[or]",$sqsx);
            array_pop($sqsx);
            if(!$type) $sqsx=array($sqsx[0]);
            foreach($sqsx as $s){
                $sq=explode("[line]",$s);
                $sqsx_data=array("period_id"=>str_replace("期",",",trim($sq[0])),"animals"=>trim($sq[2]));
                try{
                    if(self::insertSqsx($sqsx_data))    $sqsx_num++;
                }catch (Exception $e){};
            }

            //玄机
            preg_match("/".preg_replace("/\\//","\\/",$general->config_mystery)."/ism",$content,$mystery);
            $mystery=preg_replace("/<\\/td>/","[line]",$mystery[0]);
            //$mystery=strip_tags(str_replace('智慧决定金钱、人气决定生存；爆棚的人气就是我们的源动力，介绍更多朋友来 黑马堂论坛，黑马堂论坛将越早爆料。',"[info]",$mystery));
            $mystery=strip_tags(str_replace('智慧决定金钱、人气决定生存；爆棚的人气就是我们的源动力，介绍更多朋友来彩民论坛，彩民论坛将越早爆料。',"[info]",$mystery));
            $mystery=explode("[info]",$mystery);
            array_pop($mystery);
            if(!$type)   $mystery=array($mystery[0]);
            foreach($mystery as $k => $my){
                $mys=explode("[line]",$my);
                array_shift($mys);
                $period=intval(substr(trim($mys[0]),0,3));
                $mys_data=array(
                    "period_id"=>$period,
                    //"kbs"=>trim(mb_substr($mys[1],14)),
                    "kbs"=>trim(mb_substr($mys[1],12)),
                    //"slx"=>trim(mb_substr($mys[2],14)),
                    "slx"=>trim(mb_substr($mys[2],12)),
                    //"cyz"=>trim(mb_substr($mys[3],14)),
                    "cyz"=>trim(mb_substr($mys[3],12)),
                    "question"=>trim($mys[5]),
                    "bs"=>trim($mys[6]),
                    "explain"=>trim($mys[7]),
                );
                try{
                    if(self::insertMystery($mys_data))   $mystery_num++;
                }catch (Exception $e){};
            }
            $message="平特输尽光采集了 $ptsjg_num 条，金字塔采集了 $pyramid_num 条，玄机采集了 $mystery_num 条，六肖采集了 $six_num 条，平特采集了 $tp_num 条，一句一肖采集了 $yjyx_num 条，
                    综合信息采集了 $mixed_num 条";
            die(json_encode($message));
        }
    }

    //采集挂牌
    public function actionCaptureGp(){
        $param=Yii::app()->request->getParam("param");
        if($param == "xggp"){
            $general=CaiGeneralConfig::model()->find();
            $content=file_get_contents($general->url);
            $xggp_num=0;
            //香港挂牌
            preg_match("/".preg_replace("/\\//","\\/",$general->config_xggp)."/ism",$content,$xggp);
            $xggp=strip_tags(preg_replace(array("/<\\/tr>/","/<\\/td>/"),array("[or]","[line]"),$xggp[0]));
            $xggp=explode("[or]",$xggp);
            array_pop($xggp);
            foreach($xggp as $xg){
                $xg1=explode("[line]",$xg);
                $xggp_data=array("animals"=>trim(mb_substr($xg1[0],strpos($xg1[0],"【")+3,18)),"kill"=>trim(mb_substr($xg1[1],strpos($xg1[1],"【")+3,6)),"period_id"=>intval(substr(trim($xg1[0]),0,3)),"j_id"=>2);
                try{
                    if(self::insertXggp($xggp_data))    $xggp_num++;
                }catch (Exception $e){};
            }
        }
        die(json_encode("香港挂牌采集了 $xggp_num 条"));
    }

    public static function insertPtsjg($data=array()){
        if($data){
            $ptsjg=new CaiPtsjg();
            $ptsjg->pt_title=trim($data["pt_title"]);
            $ptsjg->pt_answer=trim($data["pt_answer"]);
            $ptsjg->jg_title=trim($data["jg_title"]);
            $ptsjg->period_id=$data["period_id"];
            $ptsjg->addtime=time();
            if($ptsjg->save())      return true;
            return false;
        }
    }

    public static function insertPyramid($data=array()){
        if($data){
            $pyramid=new CaiPyramid();
            $pyramid->name=$data["name"];
            $pyramid->content=$data["content"];
            $pyramid->period_id=$data["period_id"];
            if($pyramid->save())        return true;
            return false;
        }
    }

    public static function insertYjyx($data=array()){
        if($data){
            $xgyj=new CaiYx();
            $xgyj->xjyx_content=$data["xjyx_content"];
            $xgyj->period_id=$data["period_id"];
            if($xgyj->save())   return true;
        }
        return false;
    }

    public static function insertTp($data=array()){
        if($data){
            $tp=new CaiYx();
            $tp->tp_content=$data["tp_content"];
            $tp->period_id=$data["period_id"];
            if($tp->save())     return true;
            return false;
        }
    }

    public static function insertSixAnimals($data=array()){
        if($data){
            $six=new CaiSixLottery();
            $six->yx=$data["yx"];
            $six->yw=$data["yw"];
            $six->yh=$data["yh"];
            $six->bb=$data["bb"];
            $six->many_number=$data["many_number"];
            $six->period_id=$data["period_id"];
            $six->j_id=12;
            if($six->save())    return true;
            return false;
        }
    }

    public static function insertMystery($data=array()){
        if($data){
            $mystery=new CaiMystery();
            $mystery->period_id=$data["period_id"];
            $mystery->kbs=$data["kbs"];
            $mystery->slx=$data["slx"];
            $mystery->cyz=$data["cyz"];
            $mystery->bs=$data["bs"];
            $mystery->question=$data["question"];
            $mystery->explain=$data["explain"];
            $mystery->save();
            if($mystery->save())    return true;
            return false;
        }
    }

    public static function insertMixed($data=array()){
        if($data){
            $mixed=new CaiPublicInfo();
            $mixed->name=$data["name"];
            $mixed->content=$data["content"];
            if($mixed->save())      return true;
            return false;
        }
    }

    public static function insertXggp($data=array()){
        if($data){
            $xggp=new CaiGpAnimals();
            $xggp->animals=$data["animals"];
            $xggp->kill=$data["kill"];
            $xggp->period_id=$data["period_id"];
            $xggp->j_id=2;
            if($xggp->save())   return true;
            return false;
        }
    }

    public static function insertSqsx($data=array()){
        if($data){
            $sqsx=new CaiFourAnimals();
            $sqsx->period_id=$data["period_id"];
            $sqsx->animals=$data["animals"];
            if($sqsx->save())   return true;
            return false;
        }
    }

    public static function insertKj($data=array()){
        if($data){
            $timestamp=strtotime($data["lottery_time"]);
            $week=date("w",$timestamp);
            $time=0;
            if($week == 2 || $week == 4){
                $time=date("Y-m-d H:i",($timestamp+69*3600+30*60));
            }elseif($week == 6){
                $time=date("Y-m-d H:i",$timestamp+93*3600+30*60);
            }else{
                $time=date("Y-m-d",time());
            }

            $kj=new CaiKj();
            $kj->period_id=$data["period_id"];
            $kj->num_sym_col=$data["num_sym_col"];
            $kj->next_kj_time=$time;
            $kj->lottery_time=$data["lottery_time"];
            $kj->shengxiao=$data["shengxiao"];
            $kj->danshuang=$data["danshuang"];
            $kj->bose=$data["bose"];
            $kj->size=$data["size"];
            $kj->wuxing=$data["wuxing"];
            $kj->tetou=$data["tetou"];
            $kj->weishu=$data["weishu"];
            $kj->hedanshuang=$data["hedanshuang"];
            $kj->jiaye=$data["jiaye"];
            $kj->menshu=$data["menshu"];
            $kj->duanwei=$data["duanwei"];
            $kj->yinyang=$data["yinyang"];
            $kj->tiandi=$data["tiandi"];
            $kj->jixiong=$data["jixiong"];
            $kj->heibai=$data["heibai"];
            $kj->sexiao=$data["sexiao"];
            $kj->bihua=$data["bihua"];
            $kj->sex=$data["sex"];
            $kj->zonghedanshuang=$data["zonghedanshuang"];
            if($kj->save())     return true;
            return false;
        }
    }

    public static function insertJcxx($data=array()){
        if($data){
            $jc=new CaiJcxx();
            $jc->period_id=$data["period_id"];
            $jc->symbolic_name=$data["name"];
            $jc->right_number=$data["number"];
            $jc->color=$data["color"];
            if($jc->save())     return true;
            return false;
        }
    }

    public static function insertPeriod($data){
        if($data){
            $period=new CaiPeriods();
            $period->periods=$data;
            $period->save();
        }
    }

}