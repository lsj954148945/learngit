<?php
/**
 * Created by JetBrains PhpStorm.
 * User: SE MON
 * Date: 17-8-1
 * Time: 下午7:55
 * To change this template use File | Settings | File Templates.
 */

class SixLotteryController extends AdminController{
    public function actionIndex(){
        $page=(int)Yii::app()->request->getParam("page");
        $ajax=Yii::app()->request->getParam("isAjax");
        $page=$page ? $page : 1;
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=CaiSixLottery::model()->count();
        $pages=ceil($total/$pageSize);
        $condition=array("order"=>"t.period_id desc","limit"=>$pageSize,"offset"=>0);
        if($page && $page > 0 && $page <= $pages && $ajax){
            $condition["offset"]=($page-1)*$pageSize;
            $model=CaiSixLottery::model()->with("jcxx")->findAll($condition);
            $html="";
            $num=$total-($page-1)*$pageSize;
            foreach($model as $k => $v){
                $html .='<tr>
                            <td><input type="checkbox" name="numberId" value="'.$v->id.'"></td>
                            <td>'.$num.'</td>
                            <td>'.$v->period_id.' 期</td>
                            <td>'.$v->yx.'</td>
                            <td>'.$v->yx.'</td>
                            <td>'.$v->yh.'</td>
                            <td>'.$v->bb.'</td>
                            <td>'.$v->many_number.'</td>
                            <td>'.(isset($v->jcxx->symbolic_name) && isset($v->jcxx->right_number) ? $v->jcxx->symbolic_name.$v->jcxx->right_number : "").'</td>
                            <td>
                                <a href="'.$this->createUrl("sixLottery/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                <a onclick="deleteSixLottery('.$v->id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                            </td>
                        </tr>';
                $num--;
            }
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $model=CaiSixLottery::model()->with("jcxx")->findAll($condition);
        $this->render("index",array("model"=>$model,"pages"=>$pages,"page"=>$page,"pageSize"=>$pageSize,"total"=>$total));
    }

    public function actionAdd(){
        $model=new CaiSixLottery();
        $jcxx=CaiJcxx::model()->findAll(array("order"=>"id desc","limit"=>Utils::PAGE_SIZE_TEN));
        if(isset($_POST["CaiSixLottery"])){
            $model->attributes=$_POST["CaiSixLottery"];
            $model->period_id=trim($_POST["CaiSixLottery"]["period_id"]);
            $this->redirect($this->createUrl($model->save() ? "sixLottery/index" : "sixLottery/add"));
        }
        $this->render("add",array("model"=>$model,"jcxx"=>$jcxx));
    }

    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $jcxx=CaiJcxx::model()->findAll(array("order"=>"id desc","limit"=>Utils::PAGE_SIZE_TEN));
        $model=CaiSixLottery::model()->findByPk($id);
        if(isset($_POST["CaiSixLottery"])){
            $model->attributes=$_POST["CaiSixLottery"];
            $model->period_id=trim($_POST["CaiSixLottery"]["period_id"]);
            $this->redirect($this->createUrl($model->save() ? "sixLottery/index" : "sixLottery/update&id=".$model->id));
        }
        $this->render("add",array("model"=>$model,"jcxx"=>$jcxx));
    }

    public function actionDelete(){
        $id=Yii::app()->request->getParam("id");
        if(strpos($id,",") === false){
            $id=intval($id);
            if($id && $id > 0){
                $res=CaiSixLottery::model()->deleteByPk($id);
            }
        }else{
            $id=explode(",",$id);
            array_pop($id);
            foreach($id as $v){
                $res=CaiSixLottery::model()->deleteByPk(intval($v));
            }
        }
        die(json_encode($res ? 200 : -200));
        $res=CaiSixLottery::model()->deleteByPk($id);
    }

}