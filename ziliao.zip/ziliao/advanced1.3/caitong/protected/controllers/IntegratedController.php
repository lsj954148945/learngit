<?php

class IntegratedController extends AdminController{
    public function actionIndex(){
        $page=(int)Yii::app()->request->getParam("page");
        $ajax=Yii::app()->request->getParam("isAjax");
        $page=$page ? $page : 1;
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=CaiPublicInfo::model()->count();
        $pages=ceil($total/$pageSize);
        $condition=array("order"=>"id desc","limit"=>$pageSize,"offset"=>0);
        if($page && $page > 0 && $page <= $pages && $ajax){
            $condition["offset"]=($page-1)*$pageSize;
            $model=CaiPublicInfo::model()->findAll($condition);
            $html="";
            $num=$total-($page-1)*$pageSize;
            foreach($model as $k => $v){
                $html .='<tr>
                            <td><input type="checkbox" name="numberId" value="'.$v->id.'"></td>
                            <td>'.$num.'</td>
                            <td>'.$v->name.'</td>
                            <td>'.$v->content.'</td>
                            <td>
                                <a href="'.$this->createUrl("integrated/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                <a onclick="deleteIntegrated('.$v->id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                            </td>
                        </tr>';
                $num--;
            }
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $model=CaiPublicInfo::model()->findAll($condition);
        $this->render("index",array("model"=>$model,"pages"=>$pages,"page"=>$page,"pageSize"=>$pageSize,"total"=>$total));
    }

    public function actionAdd(){
        $model=new CaiPublicInfo();
        if(isset($_POST["CaiPublicInfo"])){
            $model->attributes=$_POST["CaiPublicInfo"];
            $this->redirect($this->createUrl($model->save() ? "integrated/index" : "integrated/add"));
        }
        $this->render("add",array("model"=>$model));
    }

    public  function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiPublicInfo::model()->findByPk($id);
        if(isset($_POST["CaiPublicInfo"])){
            $model->attributes=$_POST["CaiPublicInfo"];
            $this->redirect($this->createUrl($model->save() ? "integrated/index" : "integrated/upadte&id=".$model->id));
        }
        $this->render("update",array("model"=>$model));
    }

    public function actionDelete(){
        $id=Yii::app()->request->getParam("id");
        if(strpos($id,",") === false){
            $id=intval($id);
            if($id && $id > 0){
                $res=CaiPublicInfo::model()->deleteByPk($id);
            }
        }else{
            $id=explode(",",$id);
            array_pop($id);
            foreach($id as $v){
                $res=CaiPublicInfo::model()->deleteByPk(intval($v));
            }
        }
        die(json_encode($res ? 200 : -200));
    }

}