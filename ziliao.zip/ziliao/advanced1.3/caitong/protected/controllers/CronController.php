<?php
/**
 * Created by JetBrains PhpStorm.
 * User: SE MON
 * Date: 17-9-30
 * Time: 下午7:24
 * To change this template use File | Settings | File Templates.
 */
include "CaptureController.php";
class CronController extends Controller{
    public function actionIndex(){
        ini_set("max_execution_time",1200);
        $number=$tm=0;
        $lottery=CaiCaptureLottery::model()->find();
        $content=@file_get_contents($lottery->url);
        preg_match("/".preg_replace("/\\//","\\/",$lottery->rule)."/ism",$content,$lottery_content);
        $lottery_content=preg_replace(array("/<\\/tr>/","/<\\/td>/","/<\\/div>/","/<div class=\"hm blueBoClass\">/","/<div class=\"hm greenBoClass\">/","/<div class=\"hm redBoClass\">/"),array("[or]","[line]","[an]","blue[an]","green[an]","red[an]"),$lottery_content);
        $lottery_content=strip_tags($lottery_content[0]);
        $lottery_content=explode("[or]",$lottery_content);
        array_shift($lottery_content);
        array_pop($lottery_content);
        foreach($lottery_content as $key => $l){
            $lot=explode("[line]",$l);
            $sym_arr=explode("[an]",str_replace("[an][an]","[an]",$lot[2]));
            $sym="";
            $period=intval(substr(trim($lot[1]),0,3));
            $arr=explode("[an]",$lot[3]);
            foreach($sym_arr as $k => $v){
                if($k<18){
                    $sym .= $v.($k % 3 == 0 || $k % 3 == 1 ? "：" : ($k < 17 ? "，" : ""));
                }
            }
            $data=array(
                "period_id"=>$period,"num_sym_col"=>trim($sym),"name"=>trim($arr[2]),"number"=>trim($arr[1]),"color"=>trim($arr[0]),"lottery_time"=>trim($lot[0]),
                "shengxiao"=>trim($lot[4]),"danshuang"=>trim($lot[5]),"bose"=>trim($lot[6]),"size"=>trim($lot[7]),"wuxing"=>trim($lot[8]),
                "tetou"=>trim($lot[9]),"weishu"=>trim($lot[10]),"hedanshuang"=>trim($lot[11]),"jiaye"=>trim($lot[12]),"menshu"=>trim($lot[13]),
                "duanwei"=>trim($lot[14]),"yinyang"=>trim($lot[15]),"tiandi"=>trim($lot[16]),"jixiong"=>trim($lot[17]),"heibai"=>trim($lot[18]),
                "sexiao"=>trim($lot[19]),"bihua"=>trim($lot[20]),"sex"=>trim($lot[21]),"zonghedanshuang"=>trim($lot[22])
            );
            try{
                if(CaptureController::insertKj($data))  $number++;
                if(CaptureController::insertJcxx($data))   $tm++;
                CaptureController::insertPeriod($period);
            }catch (Exception $e){};
        }
    }

    public function crond(){
        //函数设置与客户机断开是否终止脚本的执行     关掉浏览器，php脚本也可以继续执行
        ignore_user_abort();
        //让程序无限执行
        set_time_limit(0);
    }

}