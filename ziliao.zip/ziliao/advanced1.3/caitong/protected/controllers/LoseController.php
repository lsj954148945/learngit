<?php
/**
 * Created by JetBrains PhpStorm.
 * User: SE MON
 * Date: 17-8-1
 * Time: 下午2:02
 * To change this template use File | Settings | File Templates.
 */

class LoseController extends AdminController{
    public function actionIndex(){
        $page=(int)Yii::app()->request->getParam("page");
        $ajax=Yii::app()->request->getParam("isAjax");
        $page=$page ? $page : 1;
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=CaiPtsjg::model()->count();
        $pages=ceil($total/$pageSize);
        $condition=array("order"=>"t.period_id desc","limit"=>$pageSize,"offset"=>0);
        if($pages && $page >0 && $page <= $pages && $ajax){
            $condition["offset"]=($page-1)*$pageSize;
            $model=CaiPtsjg::model()->with(array())->findAll($condition);
            $html="";
            $num=$total-($page-1)*$pageSize;
            foreach($model as $k => $v){
                $html .=' <tr>
                                <td><input type="checkbox" name="numberId" value="'.$v->id.'"></td>
                                <td>'.$num.'</td>
                                <td>'.$v->period_id.'</td>
                                <td>'.$v->pt_title.'</td>
                                <td>'.$v->pt_answer.'</td>
                                <td>'.$v->jg_title.'</td>
                                <td>
                                    <a href="'.$this->createUrl("lose/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                    <a onclick="deleteLose('.$v->id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                                </td>
                            </tr>';
                $num--;
            }
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $model=CaiPtsjg::model()->with(array())->findAll($condition);
        $this->render("index",array("model"=>$model,"pages"=>$pages,"page"=>$page,"pageSize"=>$pageSize,"total"=>$total));
    }

    public function actionAdd(){
        $model=new CaiPtsjg();
        if(isset($_POST["CaiPtsjg"])){
            $model->attributes=$_POST["CaiPtsjg"];
            $model->period_id=trim($_POST["CaiPtsjg"]["period_id"]);
            $this->redirect($this->createUrl($model->save() ? "lose/index" : "lose/add"));
        }
        $this->render("add",array("model"=>$model));
    }

    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiPtsjg::model()->findByPk($id);
        if(isset($_POST["CaiPtsjg"])){
            $model->attributes=$_POST["CaiPtsjg"];
            $model->period_id=trim($_POST["CaiPtsjg"]["period_id"]);
            $this->redirect($this->createUrl($model->save() ? "lose/index" : "lose/update&id=".$model->id));
        }
        $this->render("update",array("model"=>$model));
    }

    public function actionDelete(){
        $id=Yii::app()->request->getParam("id");
        if(strpos($id,",") === false){
            $id=intval($id);
            if($id && $id > 0){
                $res=CaiPtsjg::model()->deleteByPk($id);
            }
        }else{
            $id=explode(",",$id);
            array_pop($id);
            foreach($id as $v){
                $res=CaiPtsjg::model()->deleteByPk(intval($v));
            }
        }
        die(json_encode($res ? 200 : -200));
    }
}