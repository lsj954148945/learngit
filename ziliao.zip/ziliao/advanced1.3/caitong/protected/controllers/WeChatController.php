<?php
/**
 * Created by JetBrains PhpStorm.
 * User: SE MON
 * Date: 17-8-1
 * Time: 上午10:19
 * To change this template use File | Settings | File Templates.
 */

class WeChatController extends AdminController{
    public function actionIndex(){
        $page=(int)Yii::app()->request->getParam("page");
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=CaiWeChat::model()->count();
        $pages=ceil($total/$pageSize);
        $condition=array("order"=>"t.id desc","limit"=>$pageSize,"offset"=>0);
        if($page && $page > 0 && $page <= $pages){
            $condition["offset"]=($page-1)*$pageSize;
            $html="";
            $model=CaiWeChat::model()->findAll($condition);
            foreach($model as $k => $v){
                $html .=' <tr>
                            <td><input type="checkbox" name="post[]" value="'.$v->id.'"></td>
                            <td>'.$v->id.'</td>
                            <td>'.$v->title.'</td>
                            <td>'.$v->url.'</td>
                            <td>
                                <div id="caozuo">
                                    <a href="'.$this->createUrl("weChat/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                    <a onclick="deleteWeChat('.$v->id .')" class="btn btn-s-md btn-warning mf20">删除</a>
                                </div>
                            </td>
                        </tr>';

            }
            die(json_encode($html));
        }
        $model=CaiWeChat::model()->findAll($condition);
        $this->render("index",array("model"=>$model,"pages"=>$pages));
    }

    public function actionAdd(){
        $model=new CaiWeChat();
        if(isset($_POST["CaiWeChat"])){
            $model->attributes=$_POST["CaiWeChat"];
            $model->save();
            $this->redirect($this->createUrl($model->save() ? "weChat/index" : "weChat/add"));
        }
        $this->render("add",array("model"=>$model));
    }

    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiWeChat::model()->findByPk($id);
        if(isset($_POST["CaiWeChat"])){
            $model->attributes=$_POST["CaiWeChat"];
            $this->redirect($this->createUrl($model->save() ? "weChat/index" : "weChat/update&id=".$model->id));
        }
        $this->render("update",array("model"=>$model));
    }

    public function actionDelete(){
        $id=(int)Yii::app()->request->getParam("id");
        if($id && $id > 0){
            $res=CaiWechat::model()->deleteByPk($id);
            die(json_encode($res ? 200 : -200));
        }
    }
}