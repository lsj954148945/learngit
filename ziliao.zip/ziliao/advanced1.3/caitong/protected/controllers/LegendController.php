<?php

class LegendController extends AdminController{
    public function actionIndex(){
        $page=(int)Yii::app()->request->getParam("page");
        $ajax=Yii::app()->request->getParam("isAjax");
        $page=$page ? $page : 1;
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=CaiYx::model()->count("tp_content is not null");
        $pages=ceil($total/$pageSize);
        $condition=array("condition"=>"tp_content is not null","order"=>"period_id desc","limit"=>$pageSize,"offset"=>0);
        if($page && $page > 0 && $page <= $pages && $ajax){
            $condition["offset"]=($page-1)*$pageSize;
            $model=CaiYx::model()->findAll($condition);
            $html="";
            $num=$total-($page-1)*$pageSize;
            foreach($model as $k => $v){
                $html .='<tr>
                            <td><input type="checkbox" name="numberId" value="'.$v->id.'"></td>
                            <td>'.$num.'</td>
                            <td>'.$v->period_id.' 期</td>
                            <td>'.$v->tp_content.'</td>
                            <td>
                                <a href="'.$this->createUrl("legend/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                <a onclick="deleteSixLottery('.$v->id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                            </td>
                        </tr>';
                $num--;
            }
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $model=CaiYx::model()->findAll($condition);
        $this->render("index",array("model"=>$model,"pages"=>$pages,"page"=>$page,"pageSize"=>$pageSize,"total"=>$total));
    }

    public function actionAdd(){
        $model=new CaiYx();
        if(isset($_POST["CaiYx"])){
            $model->attributes=$_POST["CaiYx"];
            $model->period_id=trim($_POST["CaiYx"]["period_id"]);
            $this->redirect($this->createUrl($model->save() ? "legend/index" : "legend/add"));
        }
        $this->render("add",array("model"=>$model));
    }
    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiYx::model()->findByPk($id);
        if(isset($_POST["CaiYx"])){
            $model->attributes=$_POST["CaiYx"];
            $model->period_id=trim($_POST["CaiYx"]["period_id"]);
            $this->redirect($this->createUrl($model->save() ? "legend/index" : "legend/update&id=".$model->id));
        }
        $this->render("update",array("model"=>$model));
    }

    public function actionDelete(){
        $id=Yii::app()->request->getParam("id");
        if(strpos($id,",") === false){
            $id=intval($id);
            if($id && $id > 0){
                $res=CaiYx::model()->deleteByPk($id);
            }
        }else{
            $id=explode(",",$id);
            array_pop($id);
            foreach($id as $v){
                $res=CaiYx::model()->deleteByPk(intval($v));
            }
        }
        die(json_encode($res ? 200 : -200));
    }

}