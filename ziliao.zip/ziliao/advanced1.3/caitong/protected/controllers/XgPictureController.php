<?php

class XgPictureController extends AdminController{
    public function actionIndex(){
        $page=(int)Yii::app()->request->getParam("page");
        $ajax=Yii::app()->request->getParam("isAjax");
        $page=$page ? $page : 1;
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=CaiXgPicture::model()->count();
        $pages=ceil($total/$pageSize);
        $condition=array("order"=>"id desc","limit"=>$pageSize,"offset"=>0);
        if($page && $page > 0 && $page <= $pages && $ajax){
            $condition["offset"]=($page-1)*$pageSize;
            $model=CaiXgPicture::model()->findAll($condition);
            $html="";
            $num=$total-($page-1)*$pageSize;
            foreach($model as $k => $v){
                $html .='<tr>
                            <td><input type="checkbox" name="numberId" value="'.$v->id.'"></td>
                            <td>'.$num.'</td>
                            <td><img src="'.$v->gpct.'" id="gpct_'.$v->id.'" onmouseover="showPic(\''.$v->gpct.'\')"  onmouseout="hidePic()" width="50" height="50"></td>
                            <td><img src="'.$v->mdxj.'" id="mdxj_'.$v->id.'" onmouseover="showPic(\''.$v->mdxj.'\')" onmouseout="hidePic()" width="50" height="50"></td>
                            <td>
                                <a href="'.$this->createUrl("xgPicture/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                <a onclick="deleteXgPicture('.$v->id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                            </td>
                        </tr>';
                $num--;
            }
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $model=CaiXgPicture::model()->findAll($condition);
        $this->render("index",array("model"=>$model,"pages"=>$pages,"page"=>$page,"pageSize"=>$pageSize,"total"=>$total));
    }

    public function actionAdd(){
        $model=new CaiXgPicture();
        if(isset($_POST["CaiXgPicture"])){
            $data=$this->uploadPic($_FILES["CaiXgPicture"]);
            $model->period_id=intval($_POST["CaiXgPicture"]["period_id"]);
            $model->gpct=isset($data["gpct"]) ? $data["gpct"] : "";
            $model->mdxj=isset($data["mdxj"]) ? $data["mdxj"] : "";
            $this->redirect($this->createUrl($model->save() ? "xgPicture/index" : "xgPicture/add"));
        }
        $this->render("add",array("model"=>$model));
    }

    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiXgPicture::model()->findByPk($id);
        $periods=CaiPeriods::model()->findAll(array("order"=>"id desc","limit"=>Utils::PAGE_SIZE_FIFTEEN));
        if(isset($_POST["CaiXgPicture"])){
            $param=$_FILES["CaiXgPicture"];
            $data=$this->uploadPic($param);
            $model->period_id=intval($_POST["CaiXgPicture"]["period_id"]);
            $model->gpct=isset($data["gpct"]) ? $data["gpct"] : $model->gpct;
            $model->mdxj=isset($data["mdxj"]) ? $data["mdxj"] : $model->mdxj;
            $this->redirect($this->createUrl($model->save() ? "xgPicture/index" : "xgpicture/update&id=".$model->id));
        }
        $this->render("update",array("model"=>$model,"periods"=>$periods));
    }

    public function actionDelete(){
        $id=Yii::app()->request->getParam("id");
        if(strpos($id,",") === false){
            $id=intval($id);
            if($id && $id > 0){
                $res=CaiXgPicture::model()->deleteByPk($id);
            }
        }else{
            $id=explode(",",$id);
            array_pop($id);
            foreach($id as $v){
                $res=CaiXgPicture::model()->deleteByPk(intval($v));
            }
        }
        die(json_encode($res ? 200 : -200));
    }

    public function uploadPic($data){
        $path="../upload/image/xgpicture/";
        !is_dir($path) ? mkdir($path,0777,true) : "";
        $data1=$error=array();
        $ext=Utils::$ext_name;
        $name1=isset($data["name"]["gpct"]) ? $data["name"]["gpct"] : "";
        $name2=isset($data["name"]["mdxj"]) ? $data["name"]["mdxj"] : "";
        $ext1=!empty($name1) ? explode(".",$name1) : "";
        $ext2=!empty($name2) ? explode(".",$name2) : "";
        isset($ext1[1]) && in_array($ext1[1],$ext) ?  $data1["gpct"]=$path.time().$name1 : $error["gpct"]=false;
        isset($ext2[1]) && in_array($ext2[1],$ext) ? $data1["mdxj"]=$path.time().$name2 : $error["mdxj"]=false;
        !isset($error["gpct"])  ? move_uploaded_file($data["tmp_name"]["gpct"],$data1["gpct"]) : "";
        !isset($error["mdxj"])  ? move_uploaded_file($data["tmp_name"]["mdxj"],$data1["mdxj"]) : "";
        return $data1;
    }

}