<?php

class SiteController extends AdminController
{

	public function actionIndex()
	{
        $model=new CaiSeo();
        $data=CaiSeo::model()->find();
        if($data)   $model=$data;
        $src=$data->logo_src;
        if(isset($_POST["CaiSeo"]) && $_POST["CaiSeo"]){
            $model->attributes=$_POST["CaiSeo"];
            $data ? $model->updatetime=time() : $model->addtime=time();
            $name="";
            if(isset($_FILES["CaiSeo"]["name"]["logo_src"]) && $_FILES["CaiSeo"]["error"]["logo_src"] == 0){
                $path=Utils::$img_path."logo/";
                $ext=explode(".",$_FILES["CaiSeo"]["name"]["logo_src"])[1];
                if(in_array($ext,Utils::$ext_name)){
                    if(!is_dir($path))  mkdir($path,0777,true);
                    $name=$path."logo.".$ext;
                    move_uploaded_file($_FILES["CaiSeo"]["tmp_name"]["logo_src"],$name);
                }
            }
            $model->logo_src=!empty($name) ? $name : $src;
            $model->save();
            $this->redirect($this->createUrl("site/index"));
        }
		$this->render("index",array("model"=>$model));
	}

	/**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionLogout()
	{
        Yii::app()->session["uname"]=null;
		$this->redirect($this->createUrl("login/login"));
	}
    public function actionUpdatePassword(){
        $crp="caitong2017";
        $model=CaiUser::model()->find("uname=:uname",array(':uname'=>Yii::app()->session["uname"]));
        $password=$model->passwd;
        $model->passwd="";
        if(isset($_POST["CaiUser"]["uname"]) && $_POST["CaiUser"]["uname"]){
            $new_pass=$_POST["CaiUser"]["passwd"] ? $_POST["CaiUser"]["passwd"] : $password;
            $model->attributes=$_POST["CaiUser"];
            $model->passwd=$new_pass  ?  md5($crp.$new_pass) : $password;
            if($model->save())   $this->redirect($this->createUrl("site/index"));
            else    $this->render("updatePassword",array("model"=>$model));
        }
        $this->render("updatePassword",array("user"=>Yii::app()->session["uname"],"model"=>$model));
    }

}