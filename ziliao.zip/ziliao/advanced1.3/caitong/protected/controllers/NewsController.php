<?php

class NewsController extends AdminController{
    public function actionIndex(){
        $page=Yii::app()->request->getParam('page');
        $page=$page ?  $page : 1;
        $cate=Yii::app()->request->getParam('cate');
        $ajax=Yii::app()->request->getParam('isAjax');
        $content=Yii::app()->request->getParam('findContent');
        $nav_id=isset($_POST["nid"]) && !empty($_POST["nid"]);
        $nid=$nav_id ? intval($_POST["nid"]) : "";
        $criteria=new CDbCriteria();
        $criteria->order='t.sort desc,t.id desc';
        $criteria->condition="t.status =1".($nav_id ? " and t.nav_id=".$nid : "").(!empty($content) ? " and t.content like'%".trim($content)."%'" : "");
        $total = CaiNews::model()->count($criteria);
        $condition=array(
            'criteria'=>$criteria,
            'pagination'=>array(
                'pageSize'=>Utils::PAGE_SIZE_TEN,
                'currentPage'=>$page-1
            ));

        if(isset($page) && isset($ajax) && $ajax == 1){
            $condition['pagination']['currentPage']=$page-1;
            $data=(new CActiveDataProvider('CaiNews',$condition))->getData();
            $html=$this->ajaxNews($data);
            die(json_encode(array('html'=>$html,'page'=>$page)));
        }

        $data=(new CActiveDataProvider('CaiNews',$condition))->getData();
        $nav=CaiNav::model()->findAll(array('select'=>'id,nav_name'));
        $pages=ceil($total/Utils::PAGE_SIZE_TEN);
        $data=array('data'=>$data,"pages"=>$pages,"nav"=>$nav,"page"=>$page,"nid"=>$nid,"total"=>$total);
        $data["nid"]=isset($_POST["nid"]) ? $_POST["nid"] : "";
        $this->render('index',$data);
    }

    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $nav=CaiNav::model()->findAll();
        $criteria=new CDbCriteria();
        $criteria->addCondition('t.id=:id');
        $criteria->params[':id']=$id;
        $model=CaiNews::model()->find($criteria);
        if(isset($_POST['CaiNews']) && $_POST['CaiNews']){
            preg_match_all('/src=["\"].*?["\"]/',$model->content,$match);
            $urls="";
            $num=count($match[0]);
            if($num > 0)
                for($i=0;$i<$num;$i++)      $urls .= preg_replace('/"|src=/',"",$match[0][$i]).",";
            $model->attributes=$_POST['CaiNews'];
            $model->img_src=!empty($urls) ? $urls : "";
            $model->title=trim($_POST['CaiNews']['title']);
            $model->content=trim($_POST['CaiNews']['content']);
            $bool=$model->save();
            $this->redirect($this->createUrl($bool ? 'news/index' : 'news/update/id/'.$id));
        }
        $this->render('update',array('nav'=>$nav,"model"=>$model));
    }

    public function actionAdd(){
        $nav=CaiNav::model()->findAll();
        $model=new CaiNews();
        $author=CaiAuthor::model()->findAll();
        if(is_array($nav) && count($nav) <= 0)    $this->redirect($this->createUrl('news/nav'));
        if(isset($_POST['CaiNews'])  &&  $_POST['CaiNews']){
            preg_match_all('/src=["\"].*?["\"]/',$_POST['CaiNews']["content"],$match);
            $urls="";
            $num=count($match[0]);
            if($num > 0)
                for($i=0;$i<$num;$i++)      $urls .= preg_replace('/"|src=/',"",$match[0][$i]).",";
            $model->attributes=$_POST['CaiNews'];
            $model->img_src=!empty($urls) ? $urls : "";
            $model->publish_time=time();
            $model->u_id=1;
            $this->redirect($this->createUrl($model->save() ? 'news/index' : 'news/add'));
        }
        $this->render('add',array('model'=>$model,'nav'=>$nav,"author"=>$author));
    }
    public function actionDelete(){
        $id=(int)Yii::app()->request->getParam("id");
        if($id && $id > 0){
            $res=CaiNews::model()->updateByPk($id,array("status"=>0),"status =:status",array(":status"=>1));
            die(json_encode($res ? 200 : -200));
        }
    }
    public function actionNav(){
        header('Content-Type:text/html;charset=utf-8');
        $model=new CaiNav();
        if(isset($_POST['CaiNav'])){
            $model->attributes=$_POST["CaiNav"];
            $model->addtime=time();
            $model->sort=0;
            $model->save();
            $this->redirect($this->createUrl($model->save() ? 'news/menu' : 'news/nav'));
        }
        $this->render('nav',array("model"=>$model));
    }

    public function actionMenu(){
        $page=(int)Yii::app()->request->getParam("page");
        $pageSize=Utils::PAGE_SIZE_TEN;
        $condition=array("order"=>"id desc","offset"=>0,"limit"=>$pageSize);
        $total=CaiNav::model()->count();
        $pages=ceil($total/$pageSize);
        if($page && $page > 0){
            $condition["offset"]=($page-1)*(Utils::PAGE_SIZE_TEN);
            $nav=CaiNav::model()->findAll($condition);
            $html="";
            foreach($nav as $k => $v){
                $html .='<tr>
                            <td><input type="checkbox" name="post[]" value="'.$v->id.'"></td>
                            <td>'.$v->id.'</td>
                            <td>'.$v->nav_name.'</td>
                            <td>'.$v->title.'</td>
                            <td>'.$v->keywords.'</td>
                            <td>'.$v->nickname.'</td>
                            <td>'.date('Y-m-d',$v->addtime).'</td>
                            <td>
                                <a href="'.$this->createUrl("news/updateNav",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                <a onclick="deleteNav('.$v->id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                            </td>
                        </tr>';
            }
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $nav=CaiNav::model()->findAll($condition);
        $this->render('menu',array("nav"=>$nav,"pages"=>$pages));
    }

    public function actionDeleteNav(){
        $id=(int)Yii::app()->request->getParam("id");
        if($id && $id > 0){
            $res=CaiNav::model()->deleteByPk($id);
            die(json_encode($res ? 200 : -200));
        }
    }

    public function actionUpdateNav($id){
        $model=CaiNav::model()->findByPk($id);
        if(isset($_POST['CaiNav']) && $_POST['CaiNav']){
            $model->attributes=$_POST['CaiNav'];
            $model->sort=0;
            $model->updatetime=time();
            if($model->save())     $this->redirect($this->createUrl('menu'));
            else    $this->redirect($this->createUrl('menu'));
        };
        $this->render('updateNav',array('model'=>$model));
    }

    public function actionSecondMenu(){
        $page=(int)Yii::app()->request->getParam("page");
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=CaiNav::model()->count("n_id is not null");
        $pages=ceil($total/$pageSize);
        $condition=array("condition"=>"n_id is not null","order"=>"id desc","offset"=>0,"limit"=>$pageSize);
        $nav_name=CaiNav::model()->findAll(array("select"=>"id,nav_name","condition"=>"n_id is null"));
        $arr=array();
        foreach($nav_name as $k => $v)        $arr[$v->n_id]=$v->nav_name;
        if($page && $page > 0){
            $condition["offset"]=($page-1)*$pageSize;
            $data=CaiNav::model()->findAll($condition);
            $html="";
            foreach($data as $k1 => $v1){
                $html .=' <tr>
                            <td><input type="checkbox" name="post[]" value="'.$v1->n_id.'"></td>
                            <td>'.$v1->n_id.'</td>
                            <td>'.$v1->c_name.'</td>
                            <td>'.$arr[$v1->n_id].'</td>
                            <td>'.date("Y-m-d H:i:s",$v1->time).'</td>
                            <td>
                                <div id="caozuo">
                                    <a href="'.$this->createUrl("author/update",array("id"=>$v1->n_id)).'" class="btn btn-s-md btn-info">修 改</a>
                                    <a onclick="deleteSecondMenu('.$v1->n_id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                                </div>
                            </td>
                        </tr>';
            }
            die(json_encode($html));
        }
        $data=CaiNav::model()->findAll($condition);
        $this->render("secondMenu",array("data"=>$data,"nav_name"=>$arr,"pages"=>$pages));
    }

    public function actionAddSecondMenu(){
        $model=new CaiNav();
        $nav=CaiNav::model()->findAll(array("condition"=>"n_id is null"));
        if(isset($_POST["CaiNav"])){
            $model->attributes=$_POST["CaiNav"];
            $model->time=time();
            $res=$model->save();
            $this->redirect($this->createUrl($res ? "news/secondMenu" : "news/addSecondMenu"));
        }
        $this->render("addSecondMenu",array("nav"=>$nav,"model"=>$model));
    }

    public function actionUpdateSecondMenu(){
        $id=(int)Yii::app()->request->getParam("id");
        $nav=CaiNav::model()->findAll(array("condition"=>"n_id is null"));
        $model=CaiNav::model()->findByPk($id);
        if(isset($_POST["CaiNav"])){
            $model->attributes=$_POST["CaiNav"];
            $model->update_time=time();
            $res=$model->save();
            $this->redirect($this->createUrl($res ? "news/secondMenu" : "news/update&id=".$model->n_id));
        }
        $this->render("updateSecondMenu",array("model"=>$model,"nav"=>$nav));
    }

    public function actionDeleteSecondMenu(){
        $id=(int)Yii::app()->request->getParam("id");
        $res=CaiNav::model()->deleteByPk($id);
        die(json_encode($res ? 200 : -200));
    }

    public function actionYearPic(){
        $page=Yii::app()->request->getParam("page");
        $pageSize=Utils::PAGE_SIZE_TEN;
        $condition=array("order"=>"id desc","offset"=>0,"limit"=>Utils::PAGE_SIZE_TEN);
        $total=CaiPictures::model()->count(array("condition"=>"year_content is not null"));
        $pages=ceil($total/$pageSize);
        if(isset($page) && $page >=1){
            $offset=($page-1)*$pageSize;
            $condition["offset"]=$offset;
            $ajacData=CaiPictures::model()->findAll($condition);
            $html="";
            if(count($ajacData) >0){
                foreach($ajacData as $k => $v){
                    $html .='<tr>
                                <td><input type="checkbox" name="post[]" value="'.$v->id.'"></td>
                                <td>'.$v->id.'</td>
                                <td>'.$v->name.'</td>
                                <td><img src="'.$v->year_content.'" width="50" height="50" onmouseover="showYear('.$v->year_content.')" onmouseout="hidePic()"></td>
                                <td>
                                    <div id="caozuo">
                                        <a href="'.$this->createUrl("news/updatePic",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                        <a onclick="deletePic('.$v->id.')" class="btn btn-s-md btn-warning">删除</a>
                                    </div>
                                </td>
                        </tr>';
                }
            }
            die(json_encode($html));
        }
        $data=CaiPictures::model()->findAll($condition);
        $this->render("yearPic",array("data"=>$data,"pages"=>$pages));
    }

    public function actionAddPic(){
        $model=new CaiPictures();
        $model->sort=0;
        $model->isCustomized=0;
        $data=CaiPictures::model()->findAll(array("order"=>"id desc"));
        if(isset($_POST["CaiPictures"]["name"])){
            $src=$this->uploadYearPic();
            $src == "" || $src == false ? $this->redirect($this->createUrl("news/addPic",array("model"=>$_POST["CaiPictures"]))) : "";
            $model->name=$_POST["CaiPictures"]["name"];
            $model->year_content=$src;
            $model->sort=intval($_POST["CaiPictures"]["sort"]);
            $upload=move_uploaded_file($_FILES["CaiPictures"]["tmp_name"]["year_content"],$src);
            if($model->save() && $upload)       $this->redirect($this->createUrl("news/yearPic"));
            else        $this->redirect($this->createUrl("news/addPic",array("model"=>$_POST["CaiPictures"])));
        }
        $this->render("addPic",array("model"=>$model,"data"=>$data));
    }
    public function actionUpdatePic(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiPictures::model()->findByPk($id);
        if(isset($_POST["CaiPictures"])){
            $content=$model->year_content;
            $src=$this->uploadYearPic();
            $model->name=trim($_POST["CaiPictures"]["name"]);
            $model->year_content= $src == "" | $src == false ? $content : $src;
            $model->sort=intval($_POST["CaiPictures"]["sort"]);
            if($src)  move_uploaded_file($_FILES["CaiPictures"]["tmp_name"]["year_content"],$src);
            $this->redirect($this->createUrl($model->save() ? "news/yearPic" : "news/updatePic&id=".$model->id));
        }
        $this->render("updatePic",array("model"=>$model));
    }

    public function actionDeletePic(){
        $id=(int)Yii::app()->request->getParam("id");
        $res=CaiPictures::model()->deleteByPk($id);
        die(json_encode($res ?  200 : -200)) ;
    }

    public function actionRecycleNews(){
        $page=(int)Yii::app()->request->getParam("page");
        $pageSize=Utils::PAGE_SIZE_TEN;
        $condition=array("condition"=>"status = 0","order"=>"sort desc","limit"=>$pageSize);
        $total=CaiNews::model()->count($condition);
        $condition["offset"]=0;
        $pages=ceil($total/ $pageSize);
        if($page && $page > 0){
            $condition["offset"]=($page-1)*$pageSize;
            $data=CaiNews::model()->findAll($condition);
            $html=$this->ajaxNews($data);
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $data=CaiNews::model()->findAll($condition);
        $this->render("recycleNews",array("data"=>$data,"pages"=>$pages));
    }

    public function actionRecover(){
        $id=(int)Yii::app()->request->getParam("id");
        if($id && $id > 0){
            $res=CaiNews::model()->updateByPk($id,array("status"=>1),"status=:status",array(":status"=>0));
            die(json_encode($res ? 200 : -200));
        }
    }

    public function ajaxNews($data){
        if(count($data) > 0){
            $html="";
            foreach($data as $k => $v){
                $html .='<tr>'.
                    '<td><input type="checkbox" name="post[]" value="'.$v->id.'"></td>'.
                    '<td>'.$v->id.'</td>'.
                    '<td>'.mb_substr($v->title,0,30,"UTF-8").'</td>'.
                    '<td><div style="height: 30px !important;overflow: hidden;">'.mb_substr(strip_tags($v->content),0,80,"UTF-8").'......</div></td>'.
                    '<td>'.date("Y-m-d H:i:s",$v->publish_time).'</td>'.
                    '<td>'.$v->author_name.'</td>'.
                    '<td>'.
                    '<div id="caozuo">'.
                    '<a href="'.$this->createUrl("news/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>'.
                    '<a href="'.$this->createUrl("news/delete",array("id"=>$v->id)).'" class="btn btn-s-md btn-warning">删除</a>'.
                    '</div>'.
                    '</td>'.
                    '</tr>';
            }
            return $html;
        }
    }

    public function uploadYearPic(){
        $name="";
        $content=$_FILES["CaiYearPic"]["name"]["year_content"];
        if(isset($content) && $content){
            $path="../upload/image/years/";
            !is_dir($path) ? mkdir($path,0777,true) : "";
            $type=array("jpeg","jpg","png","gif");
            $ext=explode(".",$_FILES["CaiYearPic"]["name"]["content"]);
            if(in_array($ext[1],$type))     $name=$path.time().".".$ext[1];
            else       return -200;
        }
        return  $name;
    }

}