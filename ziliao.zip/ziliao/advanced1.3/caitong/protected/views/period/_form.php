<section class="scrollable wrapper w-f">
    <div class="col-sm-12">
        <?php  $form=$this->beginWidget("CActiveForm",array(
            'id'=>'period',
            'enableClientValidation'=>true,
            //'enableAjaxValidation'=>true,
            'clientOptions'=>array(
                'validateOnSubmit'=>true,
                /*'afterValidate'=>'js:function(form,data,hasError){
                    if(!hasError){
                        $.ajax({
                            "type":"POST",
                            "url":url,
                            "success":function(data){
                                var res =eval("("+data+")");
                                if("success"==res.code){
                                    if(res.addressId>0){
                                        $("#addressId").val(res.addressId);
                                    }
                                    $("#address_info").prepend(res.html);
                                    clearAddr();
                                }else{
                                    clearAddr();
                                }
                            }
                        })
                    }

                }'*/
            ),
            'htmlOptions'=>array("class"=>"form-horizontal")
        ));?>
        <section class="panel panel-default">
            <header class="panel-heading f20"> <strong>新闻添加管理界面</strong> </header>
            <div class="panel-body">
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'periods',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-10">
                        <?php echo $form->textField($model,"periods",array("class"=>"form-control","placeholder"=>""));?>
                        <?php echo $form->error($model,"periods");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
            </div>
            <footer class="panel-footer text-center bg-light lter">
                <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
            </footer>
        </section>
        <?php  $this->endWidget();?>
    </div>
</section>
</section>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
    <div class="wrapper"></div>
</aside>
</section>
</section>
</section>