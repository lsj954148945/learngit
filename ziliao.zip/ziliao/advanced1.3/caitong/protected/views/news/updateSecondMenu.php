<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index");?>">首页</a> ->
                <a href="<?php echo $this->createUrl("news/menu");?>">导航管理</a> ->
                <a href="<?php echo $this->createUrl("news/addSecondMenu");?>">修改子栏目</a></p>
        </header>
        <?php $this->renderPartial('_second_menu',array('nav'=>$nav,'model'=>$model));?>