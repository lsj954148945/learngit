<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index");?>">首页</a> ->
                <a href="<?php echo $this->createUrl("news/index");?>">新闻管理</a> ->
                <a href="<?php echo $this->createUrl("news/updatePic",array("id"=>$model->id));?>">修改全年资料图</a></p>
        </header>
        <section class="scrollable wrapper w-f">
            <div class="col-sm-12">
                <section class="panel panel-default">
                    <header class="panel-heading f20"> <strong>修改全年资料图界面</strong> </header>
                    <?php $this->renderPartial('_year',array('model'=>$model));?>
            </div>
        </section>
    </section>
    <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
    <aside class="bg-light lter b-l aside-md hide" id="notes">
        <div class="wrapper"></div>
    </aside>
</section>
</section>
</section>
