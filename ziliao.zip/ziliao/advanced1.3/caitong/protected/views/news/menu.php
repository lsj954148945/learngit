            <!-- /.aside -->
            <section id="content">
                <section class="vbox">
                    <header class="header bg-white b-b b-light">
                        <p class="f16"><a href="<?php echo $this->createUrl("site/index")?>">首页</a> ->
                            <a href="<?php echo $this->createUrl("news/menu");?>">导航管理</a> ->
                            <a href="<?php echo $this->createUrl("news/menu");?>">导航管理页面</a></p>
                    </header>
                    <section class="scrollable padder">
                        <div class="m-b-md">
                            <h3 class="m-b-none">导航管理界面</h3>
                        </div>
                        <section class="panel panel-default">
                            <header class="panel-heading"> 导航列表</header>
                            <div class="row text-sm wrapper">
                                <div class="col-sm-9 m-b-xs f16">
                                    <button type="submit" class="btn btn-success btn-s-xs"><a href="<?php echo $this->createUrl('news/nav')?>" class="btn-success">添加导航</a></button>
                                </div>
                                <div class="col-sm-3">
                                    <div class="input-group">
                                        <input type="text" class="input-sm form-control" placeholder="Search">
                                        <span class="input-group-btn"><button class="btn btn-sm btn-default" type="button">查 询</button></span>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-striped b-t b-light text-sm">
                                    <thead>
                                    <tr>
                                        <th class="30"><input type="checkbox"></th>
                                        <th style="width:200px !important;" >序号</th>
                                        <th class="th-sortable col-sm-2" data-toggle="class">导航显示名称 </th>
                                        <th class="th-sortable col-sm-3" data-toggle="class">导航标题 </th>
                                        <th class="th-sortable col-sm-2" data-toggle="class">导航关键词 </th>
                                        <th class="th-sortable col-sm-2" data-toggle="class">导航别名 </th>
                                        <th class="col-sm-1">时间</th>
                                        <th class="col-sm-2">操作</th>
                                    </tr>
                                    </thead>
                                    <tbody id="news">
                                    <?php
                                        if(is_array($nav) && $nav){
                                            foreach($nav as $k =>$v){?>
                                                <tr>
                                                    <td><input type="checkbox" name="post[]" value="<?php echo $v->id?>"></td>
                                                    <td><?php echo $v->id?></td>
                                                    <td><?php echo $v->nav_name?></td>
                                                    <td><?php echo $v->title?></td>
                                                    <td><?php echo $v->keywords?></td>
                                                    <td><?php echo $v->nickname?></td>
                                                    <td><?php echo date("Y-m-d",$v->addtime);?></td>
                                                    <td>
                                                        <a href="<?php echo $this->createUrl("news/updateNav",array("id"=>$v->id));?>" class="btn btn-s-md btn-info">修 改</a>
                                                        <a onclick="deleteNav(<?php echo $v->id?>)" class="btn btn-s-md btn-warning mf20">删除</a>
                                                    </td>
                                                </tr>
                                    <?php }}?>
                                    </tbody>
                                </table>
                            </div>
                            <!--采集需要使用，请勿删除-->
                            <div style="display: none;">
                                <select id="capture">
                                <?php
                                    if(is_array($nav) && $nav){
                                        foreach($nav as $n => $v1){
                                ?>
                                    <option value="<?php echo $v1->id;?>"><?php echo $v1->nav_name;?></option>
                                <?php }}?>
                                </select>
                            </div>
                            <!--采集需要使用，请勿删除-->
                            <footer class="panel-footer">
                                <div class="row">
                                    <div class="col-sm-4 hidden-xs"></div>
                                    <div class="col-sm-8 text-left text-center-xs">
                                        <ul class="pagination pagination-sm m-t-none m-b-none" id="pageCss">
                                            <a class="page" onclick="newContent(1)">首页</a>
                                            <?php if($pages){
                                                for($i=1;$i<=$pages;$i++){
                                                    ?>
                                                    <a class="page  <?php echo $i == 1 ? "page_red" : "";?>" id="page<?php echo $i;?>" onclick="newContent(<?php echo $i?>);"><?php echo $i;?></a>
                                                <?php }}?>
                                            <?php if($pages > 1) echo '<a class="page" onclick="newContent('.$pages.')">最后一页</a>';?>
                                        </ul>
                                    </div>
                                </div>
                            </footer>
                        </section>
                    </section>
                </section>
                <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
            <aside class="bg-light lter b-l aside-md hide" id="notes">
                <div class="wrapper">Notification</div>
            </aside>
        </section>
    </section>
</section>
<script type="text/javascript">
    function newContent(page){
        if(page && page >0){
            $.ajax({
                ur:"<?php echo $this->createUrl("news/index")?>",
                data:{page:page,isAjax:1},
                dataType:"json",
                method:"post",
                success:function(data){
                    if(data){
                        $(".page").each(function(i,n){
                            $(this).removeClass("page_red");
                        });
                        $("#page"+page).addClass("page_red");
                        $("#news").html(data.html);
                    }
                }
            })
        }
    }

    function deleteNav(param){
        if(param && parseInt(param) > 0){
            if(confirm("确定要删除吗？")){
                $.ajax({
                    method:"post",
                    dataType:"json",
                    url:"<?php echo $this->createUrl("news/deleteNav")?>",
                    data:{id:param},
                    success:function(data){
                        if(data && data ==200){
                            window.location.href="";
                        }
                    }
                })
            }
        }
    }
</script>
