<?php  $form=$this->beginWidget("CActiveForm",array(
    'htmlOptions'=>array("class"=>"form-horizontal","enctype"=>"multipart/form-data")
));?>
<div class="panel-body">
   <!-- <div class="form-group">
        <?php /*echo $form->LabelEx($model,'isCustomized',array('class'=>'col-sm-2 control-label'));*/?>
        <div class="col-sm-10">
            <?php /*echo $form->radioButtonList($model,"isCustomized",array("0"=>"否","1"=>"是"),array("separator"=>"&nbsp;&nbsp;&nbsp;&nbsp;"));*/?>
        </div>
    </div>-->
    <div class="form-group" id="customized">
        <?php echo $form->LabelEx($model,'name',array('class'=>'col-sm-2 control-label'));?>
        <div class="col-sm-10">
            <?php echo $form->textField($model,"name",array("class"=>"form-control"));?>
        </div>
    </div>
   <!-- <div class="form-group" id="default_name" style="<?php /*if($model->isNewRecord) echo "display:block"*/?>">
        <?php /*echo $form->LabelEx($model,'name',array('class'=>'col-sm-2 control-label'));*/?>
        <div class="col-sm-10">
            <?php /*echo $form->dropDownList($model,"name",CHtml::listData($data,"name","name"),array("class"=>"form-control"));*/?>
        </div>
    </div>-->
    <div class="form-group">
        <?php echo $form->LabelEx($model,'sort',array('class'=>'col-sm-2 control-label'));?>
        <div class="col-sm-10" id="sort">
            <?php echo $form->textField($model,"sort",array("class"=>"form-control"));?>
        </div>
    </div>
        <div class="form-group" id="show_nav">
            <?php echo $form->LabelEx($model,'content',array('class'=>'col-sm-2 control-label'));?>
            <div class="col-sm-4">
                <?php echo $form->fileField($model,"content",array("class"=>"form-control"));?>
            </div>
        </div>
        <?php if($this->action->id == "updatePic"){?>
            <div class="form-group">
                <div class="col-sm-2"></div>
                <div class="col-sm-7">
                    <img src="<?php echo $model->content?>" width="300" height="300">
                </div>
            </div>
        <?php }?>
    <div class="line line-dashed line-lg pull-in"></div>
</div>
    <footer class="panel-footer text-center bg-light lter">
        <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
    </footer>
    </section>
<?php  $this->endWidget();?>