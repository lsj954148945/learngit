<script type="text/javascript" charset="utf-8" src="<?php echo Yii::app()->baseUrl;?>/themes/js/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="<?php echo Yii::app()->baseUrl;?>/themes/js/ueditor.all.js"> </script>
<script type="text/javascript" charset="utf-8" src="<?php echo Yii::app()->baseUrl;?>/themes/js/zh-cn.js"></script>

            <section class="scrollable wrapper w-f">
                <div class="col-sm-12">
                    <?php  $form=$this->beginWidget("CActiveForm",array(
                        'htmlOptions'=>array("class"=>"form-horizontal","enctype"=>"multipart/form-data")
                    ));?>
                        <section class="panel panel-default">
                            <header class="panel-heading f20"> <strong>新闻添加管理界面</strong> </header>
                            <div class="panel-body">
                                <div class="form-group" id="show_nav">
                                    <?php echo $form->LabelEx($model,'nav_id',array('class'=>'col-sm-2 control-label'));?>
                                    <div class="col-sm-4">
                                        <?php echo $form->dropDownList($model,"nav_id",CHtml::listData($nav,"id","nav_name"),array("class"=>"form-control"));?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <?php echo $form->LabelEx($model,'title',array('class'=>'col-sm-2 control-label'));?>
                                    <div class="col-sm-7">
                                        <?php echo $form->textField($model,"title",array("class"=>"form-control","placeholder"=>"新闻标题"));?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <?php echo $form->LabelEx($model,'sort',array('class'=>'col-sm-2 control-label'));?>
                                    <div class="col-sm-7">
                                        <?php echo $form->textField($model,"sort",array("class"=>"form-control"));?>
                                    </div>
                                </div>
                                <div class="line line-dashed line-lg pull-in"></div>
                                <div class="form-group">
                                    <?php echo $form->LabelEx($model,'u_id',array('class'=>'col-sm-2 control-label'));?>
                                    <div class="col-sm-7">
                                        <?php echo $form->textField($model,"author_name",array("class"=>"form-control"));?>
                                    </div>
                                </div>
                                <div class="line line-dashed line-lg pull-in"></div>
                                <div class="form-group">
                                    <?php echo $form->LabelEx($model,'content',array('class'=>'col-sm-2 control-label'));?>
                                    <div class="col-sm-6">
                                        <?php echo $form->textArea($model,"content",array("id"=>"editor","row"=>8,"cols"=>100));?>
                                        <script type="text/javascript">
                                            var editor = new UE.ui.Editor({initialFrameHeight:340});
                                            editor.render("editor");
                                        </script>
                                    </div>
                                </div>
                                <div class="line line-dashed line-lg pull-in"></div>
                            </div>
                            <footer class="panel-footer text-center bg-light lter">
                                <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
                            </footer>
                        </section>
                    <?php  $this->endWidget();?>
                </div>
            </section>
        </section>
        <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
        <aside class="bg-light lter b-l aside-md hide" id="notes">
            <div class="wrapper"></div>
        </aside>
        </section>
    </section>
</section>

<script type="text/javascript">
    //建议使用工厂方法getEditor创建和引用编辑器实例，如果在某个闭包下引用该编辑器，直接调用UE.getEditor('editor')就能拿到相关的实例
    var ue = UE.getEditor('editor',{'enterTag':''});
</script>