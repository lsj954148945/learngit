            <!-- /.aside -->
            <section id="content">
                <section class="vbox">
                    <header class="header bg-white b-b b-light">
                        <p class="f16"><a href="<?php echo $this->createUrl("site/index")?>">首页</a> ->
                            <a href="<?php echo $this->createUrl("user/updatePassword");?>">用户管理</a> ->
                            <a href="<?php echo $this->createUrl("user/updatePassword");?>">密码修改</a></p>
                    </header>
                    <section class="scrollable wrapper w-f">
                        <div class="col-sm-12">
                            <?php $form=$this->beginWidget("CActiveForm",array(
                                    "htmlOptions"=>array("class"=>"form-horizontal")
                            ));?>
                                <section class="panel panel-default">
                                    <header class="panel-heading f20"> <strong>密码修改</strong> </header>
                                    <div class="panel-body">
                                        <div class="form-group">
                                            <?php echo $form->LabelEx($model,"uname",array("class"=>"col-sm-3 control-label"));?>
                                            <div class="col-sm-9">
                                                <?php echo $form->textField($model,"uname",array("class"=>"form-control parsley-validated"));?>
                                            </div>
                                        </div>
                                        <div class="line line-dashed line-lg pull-in"></div>
                                        <div class="form-group">
                                            <?php echo $form->LabelEx($model,"passwd",array("class"=>"col-sm-3 control-label"));?>
                                            <div class="col-sm-9">
                                                <?php echo $form->passwordField($model,"passwd",array("class"=>"form-control parsley-validated"));?>
                                            </div>
                                        </div>
                                    </div>
                                    <footer class="panel-footer text-right bg-light lter">
                                        <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
                                    </footer>
                                </section>
                            <?php $this->endWidget();?>
                        </div>
                    </section>
                </section>
                <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
            <aside class="bg-light lter b-l aside-md hide" id="notes">
                <div class="wrapper">Notification</div>
            </aside>
        </section>
    </section>
