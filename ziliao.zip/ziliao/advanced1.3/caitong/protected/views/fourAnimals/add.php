<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index");?>">首页</a> ->
                <a href="<?php echo $this->createUrl("fourAnimals/index");?>">三期必出四肖管理</a> ->
                <a>添加三期必出四肖</a></p>
        </header>
        <?php $this->renderPartial('_form',array('model'=>$model));?>
