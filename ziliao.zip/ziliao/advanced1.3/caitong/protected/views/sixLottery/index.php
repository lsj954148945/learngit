<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index")?>">首页</a> ->
                <a href="<?php echo $this->createUrl("sixLottery/index");?>">六和绝杀管理</a> ->
                <a>六和绝杀管理页面</a></p>
        </header>
        <section class="scrollable padder">
            <div class="m-b-md">
                <h3 class="m-b-none">六和绝杀管理界面</h3>
            </div>
            <section class="panel panel-default">
                <header class="panel-heading"> 六和绝杀列表</header>
                <div class="row text-sm wrapper">
                    <div class="col-sm-9 m-b-xs f16">
                        <button type="submit" class="btn btn-success btn-s-xs"><a href="<?php echo $this->createUrl('sixLottery/add')?>" class="btn-success">添加六和绝杀</a></button>&nbsp;&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="deleteSixLottery(1,true)">批量删除</a>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped b-t b-light text-sm">
                        <thead>
                        <tr>
                            <th class="30"><input type="checkbox"></th>
                            <th style="width:200px !important;" >序号</th>
                            <th class="th-sortable col-sm-1" data-toggle="class">期数 </th>
                            <th class="th-sortable col-sm-1" data-toggle="class">绝杀一肖 </th>
                            <th class="th-sortable col-sm-1" data-toggle="class">绝杀一尾 </th>
                            <th class="th-sortable col-sm-1" data-toggle="class">绝杀一合</th>
                            <th class="th-sortable col-sm-1" data-toggle="class">绝杀半波 </th>
                            <th class="th-sortable col-sm-3" data-toggle="class">绝杀综合 </th>
                            <th class="th-sortable col-sm-2" data-toggle="class">特码 </th>
                            <th class="col-sm-2">操作</th>
                        </tr>
                        </thead>
                        <tbody id="news">
                        <?php
                        if(isset($model)){
                            foreach($model as $k =>$v){?>
                                <tr>
                                    <td><input type="checkbox" name="numberId" value="<?php echo $v->id?>"></td>
                                    <td><?php echo $v->id?></td>
                                    <td><?php echo $v->period_id;?> 期</td>
                                    <td><?php echo $v->yx;?></td>
                                    <td><?php echo $v->yw;?></td>
                                    <td><?php echo $v->yh;?></td>
                                    <td><?php echo $v->bb;?></td>
                                    <td><?php echo $v->many_number;?></td>
                                    <td><?php echo isset($v->jcxx->symbolic_name) && isset($v->jcxx->right_number) ? $v->jcxx->symbolic_name.$v->jcxx->right_number : "";?></td>
                                    <td>
                                        <a href="<?php echo $this->createUrl("sixLottery/update",array("id"=>$v->id));?>" class="btn btn-s-md btn-info">修 改</a>
                                        <a onclick="deleteSixLottery(<?php echo $v->id;?>)" class="btn btn-s-md btn-warning mf20">删除</a>
                                    </td>
                                </tr>
                            <?php }}?>
                        </tbody>
                    </table>
                </div>
                <footer class="panel-footer">
                    <div class="row">
                        <div class="col-sm-4 hidden-xs"></div>
                        <div class="col-sm-8 text-left text-center-xs">
                            <?php if(isset($pages)){?>
                                <ul class="pagination pagination-sm m-t-none m-b-none" id="pageCss">
                                    <a class="page" onclick="newContent(1)">首页</a>
                                    <?php if($pages){
                                        for($i=1;$i<=$pages;$i++){
                                            if($i < 11){
                                            ?>
                                            <a class="page  <?php echo $i == 1 ? "page_red" : "";?>" id="page<?php echo $i;?>" onclick="newContent(<?php echo $i.(isset($nid) ? ",".$nid : "")?>);"><?php echo $i;?></a>
                                        <?php }}}?>
                                    <?php
                                    if($pages > 1 && $page < $pages){
                                        echo '<a class="page" onclick="nextPage()">下一页</a>';
                                    }
                                    ?>
                                    <?php if($pages > 1) echo '<a class="page" onclick="newContent('.$pages.')">最后一页</a>&nbsp;&nbsp;';?>
                                    <span>共<?php echo $pages;?>页</span>
                                    <span>共<?php echo $total;?>条记录</span>
                                    <input id="inputPage" type="text" value="" style="width: 50px;margin: 0 6px;">
                                    <a class="page" onclick="inputPage()">跳转</a>
                                </ul>
                            <?php }?>
                        </div>
                    </div>
                </footer>
            </section>
        </section>
    </section>
    <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
</section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
    <div class="wrapper"><input type="hidden" id="cu_pg" value="1"></div>
</aside>
<input type="hidden" name="csrf" id="csrf" value="<?php echo Yii::app()->request->getCsrfToken();?>">
</section>
</section>
</section>
<script type="text/javascript">
    var url="<?php echo $this->createUrl("sixLottery/index")?>";
    var dele_url="<?php echo $this->createUrl("sixLottery/delete")?>";
    var pages=<?php echo $pages;?>;
    var total=<?php echo $total;?>;

    function newContent(page){
        ajaxCommon(page,pages,url,total);
    }
    function deleteSixLottery(param,batch){
        deleteInfo(param,batch,dele_url);
    }

    function nextPage(){
        var page=parseInt($("#cu_pg").val())+1;
        ajaxCommon(page,pages,url,total);
    }

    function inputPage(){
        var page=parseInt($("#inputPage").val());
        ajaxCommon(page,pages,url,total);
    }


</script>