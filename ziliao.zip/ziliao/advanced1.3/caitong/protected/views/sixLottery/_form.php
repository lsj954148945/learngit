<section class="scrollable wrapper w-f">
    <div class="col-sm-12">
        <?php  $form=$this->beginWidget("CActiveForm",array(
            'htmlOptions'=>array("class"=>"form-horizontal","enctype"=>"multipart/form-data")
        ));?>
        <section class="panel panel-default">
            <header class="panel-heading f20"> <strong>六和绝杀管理界面</strong> </header>
            <div class="panel-body">
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'period_id',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"period_id",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"period_id");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'yx',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"yx",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"yx");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'yw',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"yw",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"yw");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'yh',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"yh",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"yh");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'bb',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"bb",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"bb");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'many_number',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"many_number",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"many_number");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'j_id',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <select name="CaiSixLottery[j_id]" class="form-control">
                        <?php
                            if(isset($jcxx)){
                                foreach($jcxx as $k => $v){
                        ?>
                            <option value="<?php echo $v->id?>" <?php if($model->j_id == $v->id) echo 'selected="selected"';?>><?php echo $v->symbolic_name." ".$v->right_number;?></option>
                        <?php  }}?>
                        </select>
                        <?php echo $form->error($model,"j_id");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
            </div>
            <footer class="panel-footer text-center bg-light lter">
                <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
            </footer>
        </section>
        <?php  $this->endWidget();?>
    </div>
</section>
</section>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
    <div class="wrapper"></div>
</aside>
</section>
</section>
</section>