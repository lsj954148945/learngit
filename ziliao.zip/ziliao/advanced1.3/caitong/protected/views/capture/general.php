<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index")?>">首页</a> ->
                <a href="<?php echo $this->createUrl("capture/index")?>">采集管理</a> ->
                <a>综合采集管理</a></p>
        </header>
        <section class="scrollable wrapper w-f">
            <div class="col-sm-12">
                <?php $form=$this->beginWidget("CActiveForm",array(
                    "htmlOptions"=>array("class"=>"form-horizontal","enctype"=>"multipart/form-data")
                ));?>
                <section class="panel panel-default">
                    <header class="panel-heading f20"> <strong>综合采集管理界面</strong>
                        <a href="javascript:void(0)" onclick="captureMixed('','onedata')" style="font-weight: bold;font-size: 18px;cursor: hand;" id="onedata">采集最新综合</a>
                        <a href="javascript:void(0)" onclick="captureMixed('all','onedata')" style="font-weight: bold;font-size: 18px;cursor: hand;" id="manydatas">采集所有综合</a>
                        <a href="javascript:void(0)" onclick="captureGp('xggp')" style="font-weight: bold;font-size: 18px;cursor: hand;" id="xggp">采集香港挂牌</a>
                    </header>
                    <div class="panel-body">
                        <div class="form-group">
                            <div class="col-sm-12" id="capture-info"></div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12" id="showmessage" style="font-size: 20px;color: red;display:none;">数据采集当中！请勿在短时间内重复点击！</div>
                        </div>
                        <div class="form-group">
                            <?php echo $form->LabelEx($model,"url",array("class"=>"col-sm-2 control-label"));?>
                            <div class="col-sm-10">
                                <?php echo $form->urlField($model,"url",array("class"=>"form-control")); ?>
                            </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                            <?php echo $form->LabelEx($model,"config_ptsjg",array("class"=>"col-sm-2 control-label"));?>
                            <div class="col-sm-10">
                                <?php echo $form->textField($model,"config_ptsjg",array("class"=>"form-control")); ?>
                            </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                            <?php echo $form->LabelEx($model,"config_jzt",array("class"=>"col-sm-2 control-label"));?>
                            <div class="col-sm-10">
                                <?php echo $form->textField($model,"config_jzt",array("class"=>"form-control")); ?>
                            </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                            <?php echo $form->LabelEx($model,"pyramid_area",array("class"=>"col-sm-2 control-label"));?>
                            <div class="col-sm-10">
                                <?php echo $form->textField($model,"pyramid_area",array("class"=>"form-control")); ?>
                            </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                            <?php echo $form->LabelEx($model,"config_mystery",array("class"=>"col-sm-2 control-label"));?>
                            <div class="col-sm-10">
                                <?php echo $form->textField($model,"config_mystery",array("class"=>"form-control")); ?>
                            </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                            <?php echo $form->LabelEx($model,"config_sixanimals",array("class"=>"col-sm-2 control-label"));?>
                            <div class="col-sm-10">
                                <?php echo $form->textField($model,"config_sixanimals",array("class"=>"form-control")); ?>
                            </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                            <?php echo $form->LabelEx($model,"config_tp",array("class"=>"col-sm-2 control-label"));?>
                            <div class="col-sm-10">
                                <?php echo $form->textField($model,"config_tp",array("class"=>"form-control")); ?>
                            </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                            <?php echo $form->LabelEx($model,"config_yjyx",array("class"=>"col-sm-2 control-label"));?>
                            <div class="col-sm-10">
                                <?php echo $form->textField($model,"config_yjyx",array("class"=>"form-control")); ?>
                            </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                            <?php echo $form->LabelEx($model,"config_mixed",array("class"=>"col-sm-2 control-label"));?>
                            <div class="col-sm-10">
                                <?php echo $form->textField($model,"config_mixed",array("class"=>"form-control")); ?>
                            </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                            <?php echo $form->LabelEx($model,"config_xggp",array("class"=>"col-sm-2 control-label"));?>
                            <div class="col-sm-10">
                                <?php echo $form->textField($model,"config_xggp",array("class"=>"form-control")); ?>
                            </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                            <?php echo $form->LabelEx($model,"xg_url",array("class"=>"col-sm-2 control-label"));?>
                            <div class="col-sm-10">
                                <?php echo $form->textField($model,"xg_url",array("class"=>"form-control")); ?>
                            </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                        <div class="form-group">
                            <?php echo $form->LabelEx($model,"config_sqsx",array("class"=>"col-sm-2 control-label"));?>
                            <div class="col-sm-10">
                                <?php echo $form->textField($model,"config_sqsx",array("class"=>"form-control")); ?>
                            </div>
                        </div>
                        <div class="line line-dashed line-lg pull-in"></div>
                    </div>
                    <footer class="panel-footer text-center bg-light lter">
                        <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
                    </footer>
                </section>
                <?php $this->endWidget();?>
            </div>
        </section>
    </section>
    <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
</section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
    <div class="wrapper">Notification</div>
</aside>
</section>
</section>
</section>
<script type="text/javascript">
    function captureMixed(param,id){
        if(id == "onedata" && param == ""){
            $("#onedata").css("color","red");
            $("#manydatas").css("color","#2e3e4e");
        }else{
            $("#manydatas").css("color","red");
            $("#onedata").css("color","#2e3e4e");
        }
        $("#showmessage").show();
        $.ajax({
            type:"post",
            dataType:"json",
            url:"<?php echo $this->createUrl("capture/captureMixed");?>",
            data:{mixed:"captureMixed",type:param},
            success:function(data){
                if(data){
                    $("#showmessage").hide();
                    $("#capture-info").text(data);
                }
            }
        })
    }
    function captureGp(id){
        $("#xggp").css("color","red");
        $("#manydatas").css("color","#2e3e4e");
        $("#onedata").css("color","#2e3e4e");
        $("#showmessage").show();
        $.ajax({
            type:"post",
            dataType:"json",
            url:"<?php echo $this->createUrl("capture/captureGp");?>",
            data:{param:"xggp"},
            success:function(data){
                if(data){
                    $("#showmessage").hide();
                    $("#capture-info").text(data);
                }
            }
        })
    }
</script>