<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index");?>">首页</a> ->
                <a href="<?php echo $this->createUrl("capture/index");?>">采集配置管理</a> ->
                <a>采集配置管理页面</a></p>
        </header>
        <section class="scrollable padder">
            <section class="panel panel-default">
                <header class="panel-heading"> 采集配置列表</header>
                <div class="row text-sm wrapper">
                    <div class="col-sm-4 m-b-xs f16">
                        <button type="submit" class="btn btn-success btn-s-xs"><a href="<?php echo $this->createUrl("capture/add");?>" class="btn-success">添加采集配置信息</a></button>
                    </div>
                    <div class="col-sm-4 m-b-xs f16" id="msg"></div>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped b-t b-light text-sm">
                        <thead>
                        <tr>
                            <th class="30"><input type="checkbox"></th>
                            <th style="width:100px !important;" >序号</th>
                            <th class="th-sortable col-sm-1" data-toggle="class">配置名称 </th>
                            <th class="th-sortable col-sm-1" data-toggle="class">采集网址 </th>
                            <th class="th-sortable col-sm-2" data-toggle="class">设置采集区域 </th>
                            <th class="th-sortable col-sm-1" data-toggle="class">标题采集规则 </th>
                            <th class="th-sortable col-sm-2" data-toggle="class">内容采集规则 </th>
                            <th class="th-sortable col-sm-1" data-toggle="class">作者采集规则 </th>
                            <th class="th-sortable col-sm-1" data-toggle="class">必须包含的链接 </th>
                            <th class="col-sm-3">操作</th>
                        </tr>
                        </thead>
                        <tbody id="news">
                        <?php
                        if(isset($model)){
                            foreach($model as $k => $v){
                                ?>
                                <tr>
                                    <td><input type="checkbox" name="post[]" value="<?php echo $v->id;?>"></td>
                                    <td><?php echo $v->id;?></td>
                                    <td><?php echo $v->config_name;?></td>
                                    <td><?php echo $v->capture_url;?></td>
                                    <td><?php echo htmlentities($v->url_area);?></td>
                                    <td><?php echo htmlentities($v->title_rule);?></td>
                                    <td><?php echo htmlentities($v->content_rule);?></td>
                                    <td><?php echo htmlentities($v->author_rule);?></td>
                                    <td><?php echo $v->contain_url;?></td>
                                    <td>
                                        <div id="caozuo">
                                            <a href="<?php echo $this->createUrl("capture/update",array("id"=>$v->id));?>" class="btn btn-s-md btn-info">修 改</a>
                                            <a onclick="capture(<?php echo $v->id;?>)" class="btn btn-s-md btn-primary mf20 ">采集</a>
                                            <a onclick="deleteCapture(<?php echo $v->id ;?>)" class="btn btn-s-md btn-warning mf20">删除</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php }
                        }?>
                        </tbody>
                    </table>
                </div>
                <footer class="panel-footer">
                    <div class="row">
                        <div class="col-sm-4 hidden-xs"></div>
                        <div class="col-sm-8 text-left text-center-xs">
                            <?php if(isset($pages)){?>
                                <ul class="pagination pagination-sm m-t-none m-b-none" id="pageCss">
                                    <a class="page" onclick="newContent(1)">首页</a>
                                    <?php if($pages){
                                        for($i=1;$i<=$pages;$i++){
                                            ?>
                                            <a class="page  <?php echo $i == 1 ? "page_red" : "";?>" id="page<?php echo $i;?>" onclick="newContent(<?php echo $i.(isset($nid) ? ",".$nid : "")?>);"><?php echo $i;?></a>
                                        <?php }}?>
                                    <?php if($pages > 1) echo '<a class="page" onclick="newContent('.$pages.')">最后一页</a>';?>
                                </ul>
                            <?php }?>
                        </div>
                    </div>
                </footer>
            </section>
        </section>
    </section>
    <div id="dialogs">
        <a href="javascript:closeDiv()">关闭</a>
        <div id="info">
            <span>数据正在采集中，请不要重复点击</span></br></br>
            <span id="results"></span>
        </div>
    </div>
    <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
    <input type="hidden" name="csrf" id="csrf" value="<?php echo Yii::app()->getRequest()->getCsrfToken();?>">
    <aside class="bg-light lter b-l aside-md hide" id="notes">
        <div class="wrapper"><input type="hidden" id="cu_pg" value="1"></div>
    </aside>
</section>
</section>
</section>
<script type="text/javascript">
    function newContent(page){
        if(page && page >0){
            $.ajax({
                ur:"<?php echo $this->createUrl("capture/index")?>",
                data:{page:page,csrf:$("#csrf").val()},
                dataType:"json",
                method:"post",
                success:function(data){
                    if(data){
                        $(".page").each(function(i,n){
                            $(this).removeClass("page_red");
                        });
                        $("#page"+page).addClass("page_red");
                        $("#news").html(data.html);
                    }
                }
            })
        }
    }

    function deleteCapture(param){
        if(param && param > 0){
            if(confirm("确定要删除吗？")){
                $.ajax({
                    method:"post",
                    dataType:"json",
                    url:"<?php echo $this->createUrl("capture/delete")?>",
                    data:{id:parseInt(param),csrf:$("#csrf").val()},
                    success:function(data){
                        if(data && data == 200){
                            window.location.href="";
                        }
                    }
                })
            }
        }
    }

    function capture(param){
        var id=parseInt(param);
        if(id > 0){
            $("#dialogs").show();
            $.ajax({
                type:"post",
                dataType:"json",
                url:"<?php echo $this->createUrl("capture/addContent");?>",
                data:{id:id},
                success:function(data){
                    if(data.msg){
                        $("#results").text(data.msg);
                        $("#results").show();
                        setTimeout("hideDiv()",2000);
                        setTimeout("closeDiv()",4000);
                    }
                }
            });
        }
    }

    function hideDiv(){
        $("#results").hide();
    }

    function closeDiv(){
        $("#dialogs").hide();
    }

</script>