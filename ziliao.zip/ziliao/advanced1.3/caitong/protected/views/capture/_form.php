<section class="scrollable wrapper w-f">
    <div class="col-sm-12">
        <?php  $form=$this->beginWidget("CActiveForm",array(
            "htmlOptions"=>array("class"=>"form-horizontal","enctype"=>"multipart/form-data")
        ));?>
        <section class="panel panel-default">
            <header class="panel-heading f20"> <strong>采集配置管理界面</strong> </header>
            <div class="panel-body">
                <div class="form-group" id="show_nav">
                    <?php echo $form->LabelEx($model,"config_name",array("class"=>"col-sm-2 control-label"));?>
                    <div class="col-sm-4">
                        <?php echo $form->textField($model,"config_name",array("class"=>"form-control"));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"capture_url",array("class"=>"col-sm-2 control-label"));?>
                    <div class="col-sm-7">
                        <?php echo $form->urlField($model,"capture_url",array("class"=>"form-control","placeholder"=>""));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"domain",array("class"=>"col-sm-2 control-label"));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"domain",array("class"=>"form-control","placeholder"=>""));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"url_area",array("class"=>"col-sm-2 control-label"));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"url_area",array("class"=>"form-control","placeholder"=>""));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"title_rule",array("class"=>"col-sm-2 control-label"));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"title_rule",array("class"=>"form-control"));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"content_rule",array("class"=>"col-sm-2 control-label"));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"content_rule",array("class"=>"form-control"));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"author_rule",array("class"=>"col-sm-2 control-label"));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"author_rule",array("class"=>"form-control"));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"save_tag",array("class"=>"col-sm-2 control-label"));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"save_tag",array("class"=>"form-control"));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"contain_url",array("class"=>"col-sm-2 control-label"));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"contain_url",array("class"=>"form-control"));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"type",array("class"=>"col-sm-2 control-label"));?>
                    <div class="col-sm-7">
                        <?php echo $form->radioButtonList($model,"type",array("1"=>"栏目采集","2"=>"高手贴采集"),array("separator"=>"","style"=>"width:40px;display:inline-block"));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group" id="nav_id">
                    <?php echo $form->LabelEx($model,"nav_id",array("class"=>"col-sm-2 control-label"));?>
                    <div class="col-sm-7">
                        <select name="CaiCapture[nav_id]" class="form-control">
                        <?php if(isset($nav)){?>
                            <?php foreach($nav as $k => $v){?>
                            <option value="<?php echo $v->id;?>" <?php if($model->nav_id == $v->id) echo 'selected="selected"';?>><?php echo $v->nav_name;?></option>
                        <?php }}?>
                        </select>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group" id="config_page">
                    <?php echo $form->LabelEx($model,"config_page",array("class"=>"col-sm-2 control-label"));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"config_page",array("class"=>"form-control"));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
            </div>
            <footer class="panel-footer text-center bg-light lter">
                <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
            </footer>
        </section>
        <?php  $this->endWidget();?>
    </div>
</section>
</section>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
    <div class="wrapper"></div>
</aside>
</section>
</section>
</section>
<script type="text/javascript">
    $("input[name='CaiCapture[type]']").change(function(){
        var value=parseInt($("input[name='CaiCapture[type]']:checked").val());
        if(value == 1){
            $("#nav_id").show();
            $("#config_page").show();
        }else{
            $("#nav_id").hide();
            $("#config_page").hide();
        }
    })
</script>