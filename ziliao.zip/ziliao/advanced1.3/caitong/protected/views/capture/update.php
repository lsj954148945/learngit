<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index");?>">首页</a> ->
                <a href="<?php echo $this->createUrl("capture/index");?>">采集配置管理</a> ->
                <a>修改采集配置</a></p>
        </header>
<?php $this->renderPartial('_form',array('model'=>$model,"nav"=>$nav,"periods"=>$periods));?>