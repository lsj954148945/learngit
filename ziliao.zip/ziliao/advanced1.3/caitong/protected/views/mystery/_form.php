<section class="scrollable wrapper w-f">
    <div class="col-sm-12">
        <?php  $form=$this->beginWidget("CActiveForm",array(
            'htmlOptions'=>array("class"=>"form-horizontal","enctype"=>"multipart/form-data")
        ));?>
        <section class="panel panel-default">
            <header class="panel-heading f20"> <strong>玄机内容管理界面</strong> </header>
            <div class="panel-body">
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'period_id',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"period_id",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"period_id");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'kbs',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"kbs",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"kbs");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'bs',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"bs",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"bs");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'slx',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"slx",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"slx");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'cyz',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"cyz",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"cyz");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'question',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"question",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"question");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'explain',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textArea($model,"explain",array("class"=>"form-control","style"=>"height:100px;"));?>
                        <?php echo $form->error($model,"explain");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>

            </div>
            <footer class="panel-footer text-center bg-light lter">
                <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
            </footer>
        </section>
        <?php  $this->endWidget();?>
    </div>
</section>
</section>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
    <div class="wrapper"></div>
</aside>
</section>
</section>
</section>