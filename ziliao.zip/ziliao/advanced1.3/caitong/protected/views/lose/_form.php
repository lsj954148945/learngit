<section class="scrollable wrapper w-f">
    <div class="col-sm-12">
        <?php $form=$this->beginWidget('CActiveForm',array(
            'htmlOptions'=>array('class'=>'form-horizontal','enctype'=>'multipart/form-data')
        ));?>
        <section class="panel panel-default">
            <header class="panel-heading f20"> <strong>平特输精光管理界面</strong></header>
            <div class="panel-body">
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'period_id',array('class'=>'col-sm-3 control-label'));?>
                    <div class="col-sm-3">
                        <?php echo $form->textField($model,'period_id',array('class'=>'form-control')); ?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'pt_title',array('class'=>'col-sm-3 control-label'));?>
                    <div class="col-sm-5">
                        <?php echo $form->textField($model,'pt_title',array('class'=>'form-control')); ?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'pt_answer',array('class'=>'col-sm-3 control-label'));?>
                    <div class="col-sm-5">
                        <?php echo $form->textField($model,'pt_answer',array('class'=>'form-control')); ?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'jg_title',array('class'=>'col-sm-3 control-label'));?>
                    <div class="col-sm-5">
                        <?php echo $form->textField($model,'jg_title',array('class'=>'form-control')); ?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
            </div>
            <footer class="panel-footer text-right bg-light lter">
                <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
            </footer>
        </section>
        <?php $this->endWidget();?>
    </div>
</section>