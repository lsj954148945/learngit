<section class="scrollable wrapper w-f">
    <div class="col-sm-12">
        <?php  $form=$this->beginWidget("CActiveForm",array(
            'htmlOptions'=>array("class"=>"form-horizontal","enctype"=>"multipart/form-data")
        ));?>
        <section class="panel panel-default">
            <header class="panel-heading f20"> <strong>金字塔管理界面</strong> </header>
            <div class="panel-body">
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'period_id',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"period_id",array("class"=>"form-control","placeholder"=>""));?>
                        <?php echo $form->error($model,"period_id");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'name',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"name",array("class"=>"form-control","placeholder"=>""));?>
                        <?php echo $form->error($model,"name");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'content',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"content",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"content");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>

            </div>
            <footer class="panel-footer text-center bg-light lter">
                <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
            </footer>
        </section>
        <?php  $this->endWidget();?>
    </div>
</section>
</section>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
    <div class="wrapper"></div>
</aside>
</section>
</section>
</section>