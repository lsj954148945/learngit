<section class="scrollable wrapper w-f">
    <div class="col-sm-12">
        <?php $form=$this->beginWidget('CActiveForm',array(
            'htmlOptions'=>array('class'=>'form-horizontal','enctype'=>'multipart/form-data')
        ));?>
        <section class="panel panel-default">
            <header class="panel-heading f20"> <strong>横幅管理界面</strong></header>
            <div class="panel-body">
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'hf_position',array('class'=>'col-sm-3 control-label'));?>
                    <div class="col-sm-6">
                        <?php echo $form->textField($model,'hf_position',array('class'=>'form-control')); ?>
                        <div style="margin-top: 5px;color: red;">注意：横幅显示位置为整数，从1开始,显示多个位置是用英文的逗号隔开</div>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'hf_intro',array('class'=>'col-sm-3 control-label'));?>
                    <div class="col-sm-6">
                        <?php echo $form->textField($model,'hf_intro',array('class'=>'form-control')); ?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'hf_alt',array('class'=>'col-sm-3 control-label'));?>
                    <div class="col-sm-6">
                        <?php echo $form->textField($model,'hf_alt',array('class'=>'form-control')); ?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'hf_url',array('class'=>'col-sm-3 control-label'));?>
                    <div class="col-sm-6">
                        <?php echo $form->urlField($model,'hf_url',array('class'=>'form-control')); ?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'hf_src',array('class'=>'col-sm-3 control-label'));?>
                    <div class="col-sm-4">
                        <?php echo $form->fileField($model,'hf_src',array('class'=>'form-control')); ?>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-3"></div>
                    <div class="col-sm-4">
                        <?php echo !empty($model->hf_src) ? '<img src="'.$model->hf_src.'" style="width: 600px;height:80px;">' : ''?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
            </div>
            <footer class="panel-footer text-right bg-light lter">
                <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
            </footer>
        </section>
        <?php $this->endWidget();?>
    </div>
</section>