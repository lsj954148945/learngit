<section class="scrollable wrapper w-f">
    <div class="col-sm-12">
        <?php $form=$this->beginWidget('CActiveForm',array(
            'htmlOptions'=>array('class'=>'form-horizontal','enctype'=>'multipart/form-data')
        ));?>
        <section class="panel panel-default">
            <header class="panel-heading f20"> <strong>对联管理界面</strong></header>
            <div class="panel-body">
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'couplet_url',array('class'=>'col-sm-3 control-label'));?>
                    <div class="col-sm-5">
                        <?php echo $form->urlField($model,'couplet_url',array('class'=>'form-control')); ?>
                    </div>
                </div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'couplet_position',array('class'=>'col-sm-3 control-label'));?>
                    <div class="col-sm-5">
                        <?php echo $form->radioButtonList($model,'couplet_position',array('1'=>'对联左边','2'=>'对联右边'),array('separator'=>'&nbsp;&nbsp;&nbsp;')); ?>
                    </div>
                </div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'couplet_src',array('class'=>'col-sm-3 control-label'));?>
                    <div class="col-sm-3">
                        <?php echo $form->fileField($model,'couplet_src',array('class'=>'form-control')); ?>
                    </div>
                    <div class="col-sm-4">
                        <?php echo !empty($model->couple_src) ? '<img src="'.$model->couplet_src.'" style="width: 240px;height:240px;">' : ''?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
            </div>
            <footer class="panel-footer text-right bg-light lter">
                <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
            </footer>
        </section>
        <?php $this->endWidget();?>
    </div>
</section>