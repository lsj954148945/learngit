<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index")?>">首页</a> ->
                <a href="<?php echo $this->createUrl("advertisement/index")?>">广告管理</a> ->
                <a href="">广告修改</a></p>
        </header>
        <?php $this->renderpartial("_form",array("model"=>$model));?>
    </section>
    <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
</section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
    <div class="wrapper">Notification</div>
</aside>
</section>
</section>
</section>