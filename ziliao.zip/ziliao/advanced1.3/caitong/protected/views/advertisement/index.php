<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index")?>">首页</a> ->
                <a href="<?php echo $this->createUrl("advertisement/index");?>">横幅管理</a> ->
                <a>横幅管理页面</a></p>
        </header>
        <section class="scrollable padder">
            <div class="m-b-md">
                <h3 class="m-b-none">横幅管理界面</h3>
            </div>
            <section class="panel panel-default">
                <header class="panel-heading"> 横幅列表</header>
                <div class="row text-sm wrapper">
                    <div class="col-sm-9 m-b-xs f16">
                        <button type="submit" class="btn btn-success btn-s-xs"><a href="<?php echo $this->createUrl('advertisement/add')?>" class="btn-success">添加横幅</a></button>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped b-t b-light text-sm">
                        <thead>
                        <tr>
                            <th class="30"><input type="checkbox"></th>
                            <th style="width:200px !important;" >序号</th>
                            <th class="th-sortable col-sm-3" data-toggle="class">横幅图片 </th>
                            <th class="th-sortable col-sm-2" data-toggle="class">横幅地址 </th>
                            <th class="th-sortable col-sm-3" data-toggle="class">横幅简介 </th>
                            <th class="th-sortable col-sm-2" data-toggle="class">横幅显示位置</th>
                            <th class="col-sm-2">操作</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if(isset($ad) && is_array($ad)){
                            foreach($ad as $k =>$v){?>
                                <tr>
                                    <td><input type="checkbox" name="post[]" value="<?php echo $v->id?>"></td>
                                    <td><?php echo $v->id?></td>
                                    <td><img src="<?php echo $v->hf_src ? $v->hf_src : ""?>" width="300" height="50" onmouseover="showImg('<?php echo $v->hf_src;?>')" onmouseout="hideImg()"></td>
                                    <td><?php echo $v->hf_url ? $v->hf_url : ""?></td>
                                    <td><?php echo $v->hf_intro ? $v->hf_intro : ""?></td>
                                    <td><?php echo $v->hf_position ? $v->hf_position : ""?></td>
                                    <td>
                                        <a href="<?php echo $this->createUrl("advertisement/update",array("id"=>$v->id));?>" class="btn btn-s-md btn-info">修 改</a>
                                        <a onclick="deleteAd(<?php echo $v->id;?>)" class="btn btn-s-md btn-warning mf20">删除</a>
                                    </td>
                                </tr>
                            <?php }}?>
                        </tbody>
                    </table>
                </div>
            </section>
        </section>
    </section>
    <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
    </section>
        <aside class="bg-light lter b-l aside-md hide" id="notes">
    <div class="wrapper">Notification</div>
    <input type="hidden" name="csrf" id="csrf" value="<?php echo Yii::app()->request->getCsrfToken();?>">
</aside>
<div id="zoomPic" style="z-index: 999;position: absolute;top: 20%;left:15%;display: none"><img src=""  height="100"></div>
</section>
</section>
</section>
<script type="text/javascript">
    function showImg(param){
        $("#zoomPic img").attr("src",param);
        $("#zoomPic").show();
    }
    function hideImg(){
        $("#zoomPic").hide();
    }
    function deleteAd(param){
        if(confirm("确定删除吗？")){
            if(param && param > 0){
                $.ajax({
                    type:"post",
                    dataType:"json",
                    url:"<?php echo $this->createUrl("advertisement/delete")?>",
                    data:{id:param,csrf:$("#csrf").val()},
                    success:function(data){
                        if(data && data == 200){
                            window.location.href="";
                        }
                    }
                })
            }
        }
    }
</script>
