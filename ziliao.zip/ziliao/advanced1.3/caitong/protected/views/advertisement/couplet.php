<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index")?>">首页</a> ->
                <a href="<?php echo $this->createUrl("advertisement/couplet");?>">对联管理</a> ->
                <a href="<?php echo $this->createUrl("advertisement/couplet");?>">对联管理页面</a></p>
        </header>
        <section class="scrollable padder">
            <div class="m-b-md">
                <h3 class="m-b-none">对联管理界面</h3>
            </div>
            <section class="panel panel-default">
                <header class="panel-heading"> 对联列表</header>
                <div class="row text-sm wrapper">
                    <div class="col-sm-9 m-b-xs f16">
                        <button type="submit" class="btn btn-success btn-s-xs"><a href="<?php echo $this->createUrl('advertisement/addCouplet')?>" class="btn-success">添加对联</a></button>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped b-t b-light text-sm">
                        <thead>
                        <tr>
                            <th class="30"><input type="checkbox"></th>
                            <th style="width:200px !important;" >序号</th>
                            <th class="th-sortable col-sm-3" data-toggle="class">对联图片 </th>
                            <th class="th-sortable col-sm-4" data-toggle="class">对联地址 </th>
                            <th class="th-sortable col-sm-2" data-toggle="class">对联位置 </th>
                            <th class="col-sm-2">操作</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if(isset($model)){
                            foreach($model as $k =>$v){?>
                                <tr>
                                    <td><input type="checkbox" name="post[]" value="<?php echo $v->id?>"></td>
                                    <td><?php echo $v->id?></td>
                                    <td><img src="<?php echo $v->couplet_src;?>" width="50" height="50" onmouseover="showImg('<?php echo $v->couplet_src;?>')" onmouseout="hideImg()"></td>
                                    <td><?php echo $v->couplet_url;?></td>
                                    <td><?php echo $v->couplet_position == 1 ? "左边" : "右边";?></td>
                                    <td>
                                        <a href="<?php echo $this->createUrl("advertisement/updateCouplet",array("id"=>$v->id));?>" class="btn btn-s-md btn-info">修 改</a>
                                        <a onclick="deleteCouplet(<?php echo $v->id;?>)" class="btn btn-s-md btn-warning mf20">删除</a>
                                    </td>
                                </tr>
                            <?php }}?>
                        </tbody>
                    </table>
                </div>
            </section>
        </section>
    </section>
    <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
</section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
    <div class="wrapper">Notification</div>
</aside>
<input type="hidden" name="csrf" id="csrf" value="<?php echo Yii::app()->request->getCsrfToken();?>">
<div id="zoomPic" style="z-index: 999;position: absolute;top: 30%;left:25%;display: none"><img src=""  width="100%" height="300"></div>
</section>
</section>
</section>
<script type="text/javascript">
    function showImg(param){
        $("#zoomPic img").attr("src",param);
        $("#zoomPic").show();
    }
    function hideImg(){
        $("#zoomPic").hide();
    }
    function deleteCouplet(param){
        if(confirm("确定删除吗？")){
            if(param && param > 0){
                $.ajax({
                    type:"post",
                    dataType:"json",
                    url:"<?php echo $this->createUrl("advertisement/deleteCouplet")?>",
                    data:{id:param,csrf:$("#csrf").val()},
                    success:function(data){
                        if(data && data == 200){
                            window.location.href="";
                        }
                    }
                })
            }
        }
    }

</script>
