<section class="scrollable wrapper w-f">
    <div class="col-sm-12">
        <?php  $form=$this->beginWidget("CActiveForm",array(
            'htmlOptions'=>array("class"=>"form-horizontal","enctype"=>"multipart/form-data")
        ));?>
        <section class="panel panel-default">
            <header class="panel-heading f20"> <strong>香港彩图管理界面</strong> </header>
            <div class="panel-body">
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'period_id',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-7">
                        <?php echo $form->textField($model,"period_id",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"period_id");?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'gpct',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-3">
                        <?php echo $form->fileField($model,"gpct",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"gpct");?>
                    </div>
                    <?php if($model->gpct)  echo '<div class="col-sm-3"><img src="'.$model->gpct.'" width="200" height="200"></div>'?>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,'mdxj',array('class'=>'col-sm-2 control-label'));?>
                    <div class="col-sm-3">
                        <?php echo $form->fileField($model,"mdxj",array("class"=>"form-control"));?>
                        <?php echo $form->error($model,"mdxj");?>
                    </div>
                    <?php if($model->mdxj)  echo '<div class="col-sm-3"><img src="'.$model->mdxj.'" width="200" height="200"></div>'?>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
            </div>
            <footer class="panel-footer text-center bg-light lter">
                <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
            </footer>
        </section>
        <?php  $this->endWidget();?>
    </div>
</section>
</section>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
    <div class="wrapper"></div>
</aside>
</section>
</section>
</section>