<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index");?>">首页</a> ->
                <a href="<?php echo $this->createUrl("picture/lotteryPic");?>">六合彩图内容管理</a> ->
                <a>添加六合彩图内容</a>
            </p>
        </header>
<?php $this->renderPartial('_form_lottery_pic',array('model'=>$model));?>