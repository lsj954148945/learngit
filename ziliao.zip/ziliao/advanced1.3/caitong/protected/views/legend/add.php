<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index");?>">首页</a> ->
                <a href="<?php echo $this->createUrl("legend/index");?>">香港传奇特平管理</a> ->
                <a>添加香港传奇特平</a></p>
        </header>
<?php $this->renderPartial('_form',array('model'=>$model));?>