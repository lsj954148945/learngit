<!DOCTYPE html>
<html lang="en" class="app">
<head>
    <meta charset="utf-8" />
    <title>手机内容管理系统</title>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/css/app.v2.css" type="text/css" />
    <!--<script type="text/javascript" src="<?php /*echo Yii::app()->request->baseUrl; */?>/themes/js/jquery-1.11.3.min.js"></script>-->
    <script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/themes/js/common.js"></script>
    <!--[if lt IE 9]>
    <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/js/ie/html5shiv.js" cache="false"></script>
    <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/js/ie/respond.min.js" cache="false"></script>
    <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/js/ie/excanvas.js" cache="false"></script>
    <![endif]-->
    <style>
        #caozuo{height: 30px;}
        #caozuo a {float: left;}
    </style>
</head>
<body style="overflow-y:scroll;">
<section class="vbox">
    <header class="bg-dark dk header navbar navbar-fixed-top-xs">
        <div class="navbar-header aside-md">
            <a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen" data-target="#nav"> <i class="fa fa-bars"></i> </a>
            <a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".nav-user"> <i class="fa fa-cog"></i> </a>
        </div>
        <ul class="nav navbar-nav hidden-xs">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle dker" data-toggle="dropdown">
                    <i class="fa fa-building-o"></i> <span class="font-bold">手机内容管理系统</span>
                </a>
            </li>
        </ul>
        <ul class="nav navbar-nav navbar-right hidden-xs nav-user">
            <li class="hidden-xs">
                <a href="<?php echo "http://".$_SERVER["HTTP_HOST"];?>" class="dropdown-toggle dk" style="font-size: 16px;font-weight: bold" target="_blank">网站首页</a>
            </li>
            <li class="dropdown hidden-xs">
                <a href="#" class="dropdown-toggle dker" data-toggle="dropdown"><i class="fa fa-fw fa-search"></i></a>
                <section class="dropdown-menu aside-xl animated fadeInUp">
                    <section class="panel bg-white">
                        <form role="search">
                            <div class="form-group wrapper m-b-none">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search">
                                  <span class="input-group-btn">
                                    <button type="submit" class="btn btn-info btn-icon"><i class="fa fa-search"></i></button>
                                  </span>
                                </div>
                            </div>
                        </form>
                    </section>
                </section>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <span class="thumb-sm avatar pull-left"> <img src="<?php echo Yii::app()->request->baseUrl;?>/themes/image/avatar.jpg"> </span>
                    <?php echo Yii::app()->session["usernames"];?>
                    <b class="caret"></b>
                </a>
                <ul class="dropdown-menu animated fadeInRight">
                    <span class="arrow top"></span>
                    <li> <a href="<?php echo Yii::app()->createUrl("site/updatePassword");?>">密码修改</a> </li>
                    <li class="divider"></li>
                    <li> <a href="<?php echo Yii::app()->createUrl("site/logout");?>"><b>注 销</b></a></li>
                </ul>
            </li>
        </ul>
    </header>
    <section>
        <section class="hbox stretch"> <!-- .aside -->
            <aside class="bg-dark lter aside-md hidden-print" id="nav">
                <section class="vbox">
                    <section class="w-f scrollable">
                        <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="5px" data-color="#333333">
                            <nav class="nav-primary hidden-xs">
                                <ul class="nav">
                                    <li class="active">
                                        <a href="<?php echo $this->createUrl("site/index");?>" class="active"> <i class="fa fa-dashboard icon"> <b class="bg-danger"></b> </i> <span>首页</span> </a>
                                    </li>
                                    <li >
                                        <a href="#layout" >
                                            <i class="fa fa-columns icon"> <b class="bg-warning"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span>
                                            <span>网站日常管理</span>
                                        </a>
                                        <ul class="nav lt">
                                            <li > <a href="<?php echo $this->createUrl("site/index");?>" > <i class="fa fa-angle-right"></i> <span>网站seo管理</span> </a> </li>
                                        </ul>
                                    </li>
                                    <li >
                                        <a href="#layout1" >
                                            <i class="fa fa-columns icon"> <b class="bg-warning"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span>
                                            <span>共用信息管理</span>
                                        </a>
                                        <ul class="nav lt">
                                            <li > <a href="<?php echo $this->createUrl("period/index");?>" > <i class="fa fa-angle-right"></i> <span>开奖期数页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("jcxx/index");?>" > <i class="fa fa-angle-right"></i> <span>特码管理</span> </a> </li>
                                        </ul>
                                    </li>
                                    <li >
                                        <a href="#pages" >
                                            <i class="fa fa-file-text icon"> <b class="bg-primary"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span>
                                            <span>综合内容管理</span>
                                        </a>
                                        <ul class="nav lt">
                                            <li > <a href="<?php echo $this->createUrl("news/index");?>" > <i class="fa fa-angle-right"></i> <span>栏目新闻管理页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("drawLottery/index");?>" > <i class="fa fa-angle-right"></i> <span>开奖管理页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("xgPicture/index");?>" > <i class="fa fa-angle-right"></i> <span>香港彩图内容页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("gpSixAnimals/index");?>" > <i class="fa fa-angle-right"></i> <span>挂牌六肖内容页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("forum/index");?>" > <i class="fa fa-angle-right"></i> <span>高手贴内容页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("weChat/index");?>" > <i class="fa fa-angle-right"></i> <span>微信内容页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("lose/index");?>" > <i class="fa fa-angle-right"></i> <span>平特输光尽内容页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("pyramid/index");?>" > <i class="fa fa-angle-right"></i> <span>金字塔内容页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("mystery/index");?>" > <i class="fa fa-angle-right"></i> <span>玄机内容页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("sixLottery/index");?>" > <i class="fa fa-angle-right"></i> <span>六和绝杀内容页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("legend/index");?>" > <i class="fa fa-angle-right"></i> <span>香港传奇内容页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("mysteryAnimal/index");?>" > <i class="fa fa-angle-right"></i> <span>玄机一肖内容页面</span> </a> </li>
                                            <!--<li > <a href="<?php /*echo $this->createUrl("news/yearPic");*/?>" > <i class="fa fa-angle-right"></i> <span>全年资料图</span> </a> </li>-->
                                            <li > <a href="<?php echo $this->createUrl("picture/lotteryPic");?>" > <i class="fa fa-angle-right"></i> <span>六和彩图</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("Integrated/index");?>" > <i class="fa fa-angle-right"></i> <span>综合资料</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("fourAnimals/index");?>" > <i class="fa fa-angle-right"></i> <span>三期必出四生肖</span> </a> </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="#pages1" >
                                            <i class="fa fa-file-text icon"> <b class="bg-primary"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span>
                                            <span>导航管理</span>
                                        </a>
                                        <ul class="nav lt">
                                            <li > <a href="<?php echo $this->createUrl("news/menu");?>" > <i class="fa fa-angle-right"></i> <span>导航管理页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("news/secondMenu");?>" > <i class="fa fa-angle-right"></i> <span>子栏目管理页面</span> </a> </li>
                                        </ul>
                                    </li>
                                    <li >
                                        <a href="#pages" >
                                            <i class="fa fa-file-text icon"> <b class="bg-primary"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span>
                                            <span>新闻作者管理</span>
                                        </a>
                                        <ul class="nav lt">
                                            <li > <a href="<?php echo $this->createUrl("author/index");?>" > <i class="fa fa-angle-right"></i> <span>新闻作者管理页面</span> </a> </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="#pages2" >
                                            <i class="fa fa-file-text icon"> <b class="bg-primary"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span>
                                            <span>广告管理</span>
                                        </a>
                                        <ul class="nav lt">
                                            <li > <a href="<?php echo $this->createUrl("Advertisement/index");?>" > <i class="fa fa-angle-right"></i> <span>横幅管理页面</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("Advertisement/couplet");?>" > <i class="fa fa-angle-right"></i> <span>对联管理页面</span> </a> </li>
                                        </ul>
                                    </li>
                                    <li >
                                        <a href="#pages4" >
                                            <i class="fa fa-file-text icon"> <b class="bg-primary"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span>
                                            <span>友情链接管理</span>
                                        </a>
                                        <ul class="nav lt">
                                            <li > <a href="<?php echo $this->createUrl("flinks/index");?>" > <i class="fa fa-angle-right"></i> <span>友情链接页面</span> </a> </li>
                                        </ul>
                                    </li>
                                    <li >
                                        <a href="#pages3" >
                                            <i class="fa fa-file-text icon"> <b class="bg-primary"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span>
                                            <span>用户管理</span>
                                        </a>
                                        <ul class="nav lt">
                                            <li > <a href="<?php echo $this->createUrl("site/updatePassword");?>" > <i class="fa fa-angle-right"></i> <span>密码修改</span> </a> </li>
                                        </ul>
                                    </li>
                                    <li >
                                        <a href="#pages4" >
                                            <i class="fa fa-file-text icon"> <b class="bg-primary"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span>
                                            <span>采集管理</span>
                                        </a>
                                        <ul class="nav lt">
                                            <li > <a href="<?php echo $this->createUrl("capture/index");?>" > <i class="fa fa-angle-right"></i> <span>采集配置列表</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("capture/general");?>" > <i class="fa fa-angle-right"></i> <span>综合采集配置列表</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("capture/lottery");?>" > <i class="fa fa-angle-right"></i> <span>开奖采集配置列表</span> </a> </li>
                                            <li > <a href="<?php echo $this->createUrl("capture/picture");?>" > <i class="fa fa-angle-right"></i> <span>彩图采集配置列表</span> </a> </li>
                                        </ul>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </section>
                </section>
            </aside>
            <?php echo $content; ?>
            <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/js/app.v2.js"></script>
</body>
</html>