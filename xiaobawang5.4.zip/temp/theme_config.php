<?php
return array (
  'company/shebei' => '',
  'company/shebeijixie' => '',
  'company/xys_blue' => '',
  'company/xys_lvse' => '',
  'company/xys_qiye1' => '',
  'news/default' => '',
  'news/xbwseo01' => '',
  'news/xbwseo02' => '',
  'news/xbwseo03' => '',
  'news/xbwseo04' => '',
  'news/xbwseo05' => '',
  'news/xbwseo06' => '',
  'news/xbwseo07' => '',
  'news/xbwseo08' => '',
  'news/xbwseo09' => '',
  'news/xbwseo10' => '',
  'news/xbwseo11' => '',
  'xiaoshuo/biqu' => '',
  'video/movie' => '',
  'bbs/xiuno' => '',
);
?>