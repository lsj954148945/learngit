<?php
return array (
  53 => 
  array (
    'urlrules' => 
    array (
      'list' => 
      array (
        'tplfile' => 'list',
        'rules' => 'category/{数字4}.html,class/{数字4}.html,list/{数字4}.html,readlist/{数字4}.html,list/{字母3}/,category/{字母3}/',
        'system' => '1',
      ),
      'show' => 
      array (
        'tplfile' => 'show',
        'rules' => 'download/{数字5}.html,html/{数字5}.html,read/{数字5}.html',
        'system' => '1',
      ),
      'chapter' => 
      array (
        'tplfile' => 'chapter',
        'rules' => 'chapter/{数字5}/{数字2}/,chapter/{数字5}/,zhangjie/{数字5}/',
        'system' => '',
      ),
    ),
    'domain' => 
    array (
      0 => 'temp.cm',
      1 => 'a.com',
    ),
  ),
);
?>