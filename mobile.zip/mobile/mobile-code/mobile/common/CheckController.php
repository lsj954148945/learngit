<?php

class CheckController extends Controller{
    public function __construct($id,$module=null){
        parent::__construct($id,$module);
        self::checkType();
    }

    public  function checkType(){
        $jump=false;
        if(isset ($_SERVER['HTTP_X_WAP_PROFILE']))     $jump=true;
        $useragent=isset($_SERVER["HTTP_USER_AGENT"]) ? $_SERVER["HTTP_USER_AGENT"] : "";
        $types=array("sony","ericsson","mot","samsung","htc","sgh","lg","sharp","sie-","philips",
            "panasonic","alcatel","lenovo","iphone","ipod","blackberry","meizu","android",
            "netfront","symbian","ucweb","windowsce","palm","operamini","operamobi","openwave","nexusone",
            "cldc","midp","wap","mobile");

        if(preg_match('/'.implode("|",$types).'/',strtolower($useragent)))     $jump=true;
        if($jump)   $this->redirect(Yii::app()->request->baseUrl."/wap/",true,301);
    }

}