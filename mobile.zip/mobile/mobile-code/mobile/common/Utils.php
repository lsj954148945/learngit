<?php

class Utils
{
    const PAGE_SIZE_FIVE=5;
    const PAGE_SIZE_EIGHT=8;
    const PAGE_SIZE_SEVEN=7;
    const PAGE_SIZE_TEN=10;
    const PAGE_SIZE_FIFTEEN=15;
    const PAGE_SIZE_NINE=9;
    const PAGE_SIZE_THIRTYFIVE=35;
    const PAGE_SIZE_THIRTYFOUR=34;
    const PAGE_SIZE_SEVENTY=70;
    const PAGE_SIZR_TWO=2;
    const PAGE_SIZE_TWELVE=12;
    const PAGE_SIZE_FORTYTWO=42;
    const PAGE_SIZE_FIVETYTWO=52;
    const PAGE_SIZE_TWEENTYFIVE=25;
    const PAGE_SIZE_TWEENTY=20;

    public static $ext_name=array("jpg","jpeg","gif","png");
    public static $img_path="../upload/image/";
    public static $week=array("日","一","二","三","四","五","六");
    public static $ad_position="1,2,3,4,5,6";
    public static $all_code=array('UTF-8', 'ASCII', 'GBK', 'GB2312', 'BIG5', 'JIS', 'eucjp-win', 'sjis-win', 'EUC-JP');
    public static $pattern=array("/","'",'"','?','!');
    public static $replace=array("\\/","\\'",'\\"','\?','\!');
    public static $lottery_type=array(1=>"重庆时时彩",2=>"北京赛车pk10",3=>"广东11选五");

    public static function CutString($string,$start,$length,$type="utf-8",$filter=false,$tags=""){
        $str_len=strlen($string);
        if($filter == true)    $strings=mb_substr(strip_tags($string,$tags),$start,$length,$type);
        else        $strings=mb_substr($string,$start,$length,$type);
        return $str_len > $length ? $strings."..." : $strings;
    }

    public  static function checkType(){
        $jump=false;
        if(isset ($_SERVER['HTTP_X_WAP_PROFILE']))     $jump=true;
        $useragent=isset($_SERVER["HTTP_USER_AGENT"]) ? $_SERVER["HTTP_USER_AGENT"] : "";
        $types=array("sony","ericsson","mot","samsung","htc","sgh","lg","sharp","sie-","philips",
            "panasonic","alcatel","lenovo","iphone","ipod","blackberry","meizu","android",
            "netfront","symbian","ucweb","windowsce","palm","operamini","operamobi","openwave","nexusone",
            "cldc","midp","wap","mobile");

        if(preg_match('/'.implode("|",$types).'/',strtolower($useragent)))     $jump=true;
        return $jump;
    }

}