<?php

/**
 * LoginForm class.
 * LoginForm is the data structure for keeping
 * user login form data. It is used by the 'login' action of 'SiteController'.
 */
class LoginForm extends CFormModel
{
	public $uname;
	public $passwd;
    public $verifyCode;

    private $_identity;
    private   $_crp="caitong2017";

    /**
     * Declares the validation rules.
     * The rules state that username and password are required,
     * and password needs to be authenticated.
     */
    public function rules()
	{
        return array(
        // username and password are required
        array('uname, passwd, verifyCode', 'required'),
        // password needs to be authenticated
        array('passwd', 'authenticate'),
        array('verifyCode','captcha','message'=>'请输入正确的验证码'),
        //array('verifyCode','captcha','allowEmpty'=>!CCaptcha::checkRequirements()),
    );
    }

    /**
     * Declares attribute labels.
     */
    public function attributeLabels()
	{
        return array(
        'rememberMe'=>'Remember me next time',
        'uname'=>Yii::t('uname','uname'),
        'passwd'=>Yii::t('passwd','passwd'),
        'verifyCode'=>Yii::t('verifyCode','verifyCode'),
    );
    }

    /**
     * Authenticates the password.
     * This is the 'authenticate' validator as declared in rules().
     */
    public function authenticate($usernames,$password)
	{
        if(!$this->hasErrors())
        {
			$this->_identity=new MbUser($this->uname=$usernames,$this->passwd=md5($this->_crp.$password));
			return !$this->_identity->authenticate($usernames,$password) ? false : true;
		}
	}

	/**
	 * Logs in the user using the given username and password in the model.
	 * @return boolean whether login is successful
	 */
	public function login($usernames,$password)
    {
         return $this->authenticate($usernames,$password);
	}

}
