<?php

/**
 * This is the model class for table "cai_seo".
 *
 * The followings are the available columns in table 'cai_seo':
 * @property string $id
 * @property string $title
 * @property string $keywords
 * @property string $description
 * @property string $copyright
 * @property string $statistics
 * @property string $logo_src
 */
class MbSeo extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'mb_seo';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('title, keywords', 'length', 'max'=>200),
			array('description', 'length', 'max'=>255),
			array('copyright', 'length', 'max'=>150),
			array('statistics', 'length', 'max'=>230),
			array('logo_src', 'length', 'max'=>50),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, title, keywords, description, copyright, statistics, logo_src', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'title' => '网站标题',
			'keywords' => '网站关键词',
			'description' => '网站描述',
			'copyright' => '版权',
			'statistics' => '统计',
			'logo_src' => 'logo地址',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('title',$this->title,true);
		$criteria->compare('keywords',$this->keywords,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('copyright',$this->copyright,true);
		$criteria->compare('statistics',$this->statistics,true);
		$criteria->compare('logo_src',$this->logo_src,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CaiSeo the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
