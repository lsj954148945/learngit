<?php
/**
 * Created by JetBrains PhpStorm.
 * User: SE MON
 * Date: 17-7-24
 * Time: 下午2:12
 * To change this template use File | Settings | File Templates.
 */

class AdminController extends Controller{
    public function __construct($id,$module=null){
        parent::__construct($id,$module=null);
        $this->validateLand();
    }
    public function validateLand(){
       if(Yii::app()->session["uname"] === null){
            $this->redirect($this->createUrl("login/login"));
           die;
        }
    }
    public function jumpUrl($url,$time=3){
        if(!empty($url)){
            echo '<script>window.location.href="http://'.$_SERVER["HTTP_HOST"].$url.'";</script>';exit;
        }
    }
}