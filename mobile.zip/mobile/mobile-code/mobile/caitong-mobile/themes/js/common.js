    function ajaxCommon(page,pages,url,total){
        if(page > 0 && page <= pages){
            $.ajax({
                ur:''+url+'',
                data:{page:page,isAjax:1},
                dataType:"json",
                method:"post",
                success:function(data){
                    if(data){
                        $(".page").each(function(i,n){
                            $(this).removeClass("page_red");
                         });
                        $("#page"+page).addClass("page_red");
                        $("#news").html(data.html);
                        $("#cu_pg").val(parseInt(data.page));
                    }
                }
            })
        }
        var pages=pages;
        var html='<a class="page" onclick="newContent(1)">首页</a>';
        if(page > 0 && page <= pages){
            var currentPage=page-8;
            if(pages > 10){
                if(page >= 10){
                    for(var i=currentPage;i<=page+1;i++)
                        if(i <= pages && i > 0) html += '<a class="page  '+(i == page ? "page_red" : "")+'" id="page'+i+'" onclick="newContent('+i+');">'+i+'</a>';
                }else{
                    for(var i=1;i<=10;i++)
                        if(i < 11)  html += '<a class="page  '+(i == page ? "page_red" : "")+'" id="page'+i+'" onclick="newContent('+i+');">'+i+'</a>';
                }
            }else{
                for(var i=1;i<=pages;i++)
                    if(i < 11)  html += '<a class="page  '+(i == page ? "page_red" : "")+'" id="page'+i+'" onclick="newContent('+i+');">'+i+'</a>';
            }
        }
        if(page < pages)  html += '<a class="page" onclick="nextPage()">下一页</a>';
        html += '<a class="page" onclick="newContent('+pages+')">最后一页</a>'+
        '<span>共'+pages+'页</span> '+
        '<span>共'+total+'条数据</span>'+
        '<input id="inputPage" type="text" value="" style="width: 50px;margin: 0 6px;">'+
            '<a class="page" onclick="inputPage()">跳转</a>';
        $("#pageCss").html(html);
    }

    function deleteInfo(param,batch,url){
        var content="";
        if(batch == true){
            $("[name='numberId']:checked").each(
                function(i){
                    content +=$(this).val()+",";
                }
            );
            param=content;
        }
        if(param != ""){
            if(confirm("确定要删除吗？")){
                $.ajax({
                    method:"post",
                    dataType:"json",
                    url:url,
                    data:{id:param,csrf:$("#csrf").val()},
                    success:function(data){
                        if(data && data == 200){
                            window.location.href="";
                        }
                    }
                })
            }
        }
    }