<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>登录</title>
    <link rel="stylesheet" href="<?php echo Yii::app()->baseUrl;?>/themes/css/layui.css" media="all" />
    <link rel="stylesheet" href="<?php echo Yii::app()->baseUrl;?>/themes/css/login.css" />
    <script type="text/javascript" src="<?php echo Yii::app()->baseUrl?>/themes/js/jquery-1.11.3.min.js"></script>
</head>
<body class="beg-login-bg">
<div class="beg-login-box">
    <header>
        <h1>后台登录</h1>
    </header>
    <div class="beg-login-main">
            <?php $form=$this->beginWidget("CActiveForm",array(
                    "enableAjaxValidation" =>true,
                    "enableClientValidation" => true,
                    "clientOptions" => array("validateOnSubmit"=>true),
                    "htmlOptions"=>array("class"=>"layui-form"),
            ));?>
            <div class="layui-form-item">
                <?php echo $form->textField($model,"uname",array("class"=>"layui-input","placeholder"=>"这里输入登录名")); ?>
                <?php echo $form->error($model,"uname");?>
            <div class="layui-form-item">
                <?php echo $form->passwordField($model,"passwd",array("class"=>"layui-input","placeholder"=>"这里输入密码")); ?>
                <?php echo $form->error($model,"passwd");?>
            </div>
            <?php if(CCaptcha::checkRequirements()): ?>
                <div class="layui-form-item" style="display: flex">
                    <?php echo $form->textField($model,"verifyCode",array("class"=>"layui-input","placeholder"=>"这里输入验证码"))?>
                    <?php $this->widget("CCaptcha",
                        array(
                            "showRefreshButton"=>false,
                            "clickableImage"=>true,
                            "imageOptions"=>array("alt"=>"点击换图","title"=>"点击换图","style"=>"cursor:pointer;height:38px;")));?>
                    <?php echo $form->error($model,"verifyCode")?>
                </div>
            <?php endif?>
            <div class="layui-form-item">
                <div>
                    <button class="layui-btn" lay-submit lay-filter="login">登&nbsp;&nbsp;&nbsp;&nbsp;录</button>
                </div>
                <div class="beg-clear"></div>
            </div>
        <?php $this->endWidget();?>
    </div>
</div>
<script type="text/javascript" src="<?php echo Yii::app()->baseUrl;?>/themes/js/layui.js"></script>
</body>
</html>