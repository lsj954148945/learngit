            <section id="content">
                <section class="vbox">
                    <header class="header bg-white b-b b-light">
                        <p class="f16"><a href="<?php echo $this->createUrl("site/index")?>">首页</a> ->
                            <a href="<?php echo $this->createUrl("site/index")?>">网站日常管理</a> ->
                            <a href="<?php echo $this->createUrl("site/index")?>">网站seo管理</a></p>
                    </header>
                    <section class="scrollable wrapper w-f">
                        <div class="col-sm-12">
                            <?php $form=$this->beginWidget('CActiveForm',array(
                                    'htmlOptions'=>array('class'=>'form-horizontal','enctype'=>'multipart/form-data')
                            ));?>
                                <section class="panel panel-default">
                                    <header class="panel-heading f20"> <strong>网站seo优化管理界面</strong> </header>
                                    <div class="panel-body">
                                        <div class="form-group">
                                            <?php echo $form->LabelEx($model,'title',array('class'=>'col-sm-3 control-label'));?>
                                            <div class="col-sm-9">
                                                <?php echo $form->textField($model,'title',array('class'=>'form-control','placeholder'=>'网站标题')); ?>
                                            </div>
                                        </div>
                                        <div class="line line-dashed line-lg pull-in"></div>
                                        <div class="form-group">
                                            <?php echo $form->LabelEx($model,'keywords',array('class'=>'col-sm-3 control-label'));?>
                                            <div class="col-sm-9">
                                                <?php echo $form->textField($model,'keywords',array('class'=>'form-control','placeholder'=>'网站关键词')); ?>
                                            </div>
                                        </div>
                                        <div class="line line-dashed line-lg pull-in"></div>
                                        <div class="form-group">
                                            <?php echo $form->LabelEx($model,'description',array('class'=>'col-sm-3 control-label'));?>
                                            <div class="col-sm-9">
                                                <?php echo $form->textField($model,'description',array('class'=>'form-control','placeholder'=>'网站描述')); ?>
                                            </div>
                                        </div>
                                        <div class="line line-dashed line-lg pull-in"></div>
                                        <div class="form-group">
                                            <?php echo $form->LabelEx($model,'copyright',array('class'=>'col-sm-3 control-label'));?>
                                            <div class="col-sm-9">
                                                <?php echo $form->textField($model,'copyright',array('class'=>'form-control','placeholder'=>'版权')); ?>
                                            </div>
                                        </div>
                                        <div class="line line-dashed line-lg pull-in"></div>
                                        <div class="form-group">
                                            <?php echo $form->LabelEx($model,'statistics',array('class'=>'col-sm-3 control-label'));?>
                                            <div class="col-sm-9">
                                                <?php echo $form->textField($model,'statistics',array('class'=>'form-control','placeholder'=>'统计,多个统计用逗号隔开，只填写地址，如：http://js.users.51.la/18931395.js，http://js.users.51.la/18953299.js')); ?>
                                            </div>
                                        </div>
                                        <div class="line line-dashed line-lg pull-in"></div>
                                       <!-- <div class="form-group">
                                            <?php /*echo $form->LabelEx($model,'logo_src',array('class'=>'col-sm-3 control-label'));*/?>
                                            <div class="col-sm-2">
                                                <?php /*echo $form->fileField($model,'logo_src',array('class'=>'form-control','placeholder'=>'logo图')); */?>
                                            </div>
                                            <div class="col-sm-2"><img src="<?php /*echo $model->logo_src;*/?>" width="200" height="100"></div>
                                        </div>
                                        <div class="line line-dashed line-lg pull-in"></div>-->
                                    </div>
                                    <footer class="panel-footer text-center bg-light lter">
                                        <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
                                    </footer>
                                </section>
                            <?php $this->endWidget();?>
                        </div>
                    </section>
                </section>
                <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a>
            </section>
             <aside class="bg-light lter b-l aside-md hide" id="notes">
                <div class="wrapper">Notification</div>
            </aside>
        </section>
    </section>
</section>