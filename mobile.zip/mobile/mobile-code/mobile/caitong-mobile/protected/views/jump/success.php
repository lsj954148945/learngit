<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $message;?></title>
<style>
    .info{width:800px;height:auto;margin: 200px auto;}
    h1{font-size: 80px;text-align:center; }
</style>
</head>
<body>
    <div class="info">
        <h1>数据添加成功！</h1>
        <p></p>
    </div>
</body>
</html>
<script type="text/javascript">
    function jump(){
        window.location.href='<?php $this->createUrl($url);?>';
    }
    setTimeout('jump()',<?php echo $time?>);
</script>