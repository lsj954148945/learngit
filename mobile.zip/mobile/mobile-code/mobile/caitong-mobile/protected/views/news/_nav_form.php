            <?php $form=$this->beginWidget("CActiveForm",array(
                "htmlOptions"=>array("class"=>"form-horizontal")
            ));?>
            <div class="panel-body">
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"nav_name",array("class"=>"col-sm-3 control-label"));?>
                    <div class="col-sm-9">
                        <?php echo $form->textField($model,"nav_name",array("class"=>"form-control"));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"title",array("class"=>"col-sm-3 control-label"));?>
                    <div class="col-sm-9">
                        <?php echo $form->textField($model,"title",array("class"=>"form-control"));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"keywords",array("class"=>"col-sm-3 control-label"));?>
                    <div class="col-sm-9">
                        <?php echo $form->textField($model,"keywords",array("class"=>"form-control"));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>
                <div class="form-group">
                    <?php echo $form->LabelEx($model,"nickname",array("class"=>"col-sm-3 control-label"));?>
                    <div class="col-sm-9">
                        <?php echo $form->textField($model,"nickname",array("class"=>"form-control"));?>
                    </div>
                </div>
                <div class="line line-dashed line-lg pull-in"></div>

            </div>
            <footer class="panel-footer text-right bg-light lter">
                <button type="submit" class="btn btn-success btn-s-xs">提 交</button>
            </footer>
        </section>
        <?php $this->endWidget();?>
