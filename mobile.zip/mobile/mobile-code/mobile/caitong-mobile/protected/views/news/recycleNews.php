<section id="content">
    <section class="vbox">
        <header class="header bg-white b-b b-light">
            <p class="f16"><a href="<?php echo $this->createUrl("site/index");?>">首页</a> ->
                <a href="<?php echo $this->createUrl("news/index");?>">新闻管理</a> ->
                <a href="<?php echo $this->createUrl("news/recyleNews");?>">新闻回收站</a></p>
        </header>
        <section class="scrollable padder">
            <section class="panel panel-default">
                <header class="panel-heading"> 新闻列表</header>
                <div class="row text-sm wrapper"></div>
                <div class="table-responsive">
                    <table class="table table-striped b-t b-light text-sm">
                        <thead>
                        <tr>
                            <th class="30"><input type="checkbox"></th>
                            <th style="width:100px !important;" >序号</th>
                            <th class="th-sortable col-sm-3" data-toggle="class">标题 </th>
                            <th class="col-sm-5">内容</th>
                            <th class="col-sm-1">时间</th>
                            <th class="col-sm-1">发表人</th>
                            <th class="col-sm-2">操作</th>
                        </tr>
                        </thead>
                        <tbody id="news">
                        <?php foreach($data as $k => $v){?>
                            <tr>
                                <td><input type="checkbox" name="post[]" value="<?php echo$v->id;?>"></td>
                                <td><?php echo$v->id;?></td>
                                <td><?php echo Utils::CutString($v->title,0,80,"UTF-8");?></td>
                                <td>
                                    <div style="height: 30px !important;overflow: hidden;">
                                        <?php echo Utils::CutString($v->content,0,50,"UTF-8",true)?>
                                    </div>
                                </td>
                                <td><?php echo date("Y-m-d H:i:s",$v->publish_time);?></td>
                                <td><?php echo $v->user->usernames;?></td>
                                <td>
                                    <div id="caozuo">
                                        <a onclick="recoverNews(<?php echo $v->id?>)" class="btn btn-s-md btn-info">恢复新闻</a>
                                    </div>
                                </td>
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>
                <footer class="panel-footer">
                    <div class="row">
                        <div class="col-sm-4 hidden-xs"></div>
                        <div class="col-sm-8 text-left text-center-xs">
                            <ul class="pagination pagination-sm m-t-none m-b-none" id="pageCss">
                                <a class="page" onclick="newContent(1)">首页</a>
                                <?php if($pages){
                                    for($i=1;$i<=$pages;$i++){
                                        ?>
                                        <a class="page  <?php echo $i == 1 ? "page_red" : "";?>" id="page<?php echo $i;?>" onclick="newContent(<?php echo $i?>);"><?php echo $i;?></a>
                                    <?php }}?>
                                <?php if($pages > 1) echo '<a class="page" onclick="newContent('.$pages.')">最后一页</a>';?>
                            </ul>
                        </div>
                    </div>
                </footer>
            </section>
        </section>
    </section>
    <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
    <div class="wrapper"><input type="hidden" id="cu_pg" value="1"></div>
</aside>
</section>
</section>
</section>
<script type="text/javascript">
    function newContent(page){
        if(page && page >0){
            $.ajax({
                ur:"<?php echo $this->createUrl("news/index")?>",
                data:{page:page,isAjax:1},
                dataType:"json",
                method:"post",
                success:function(data){
                    if(data){
                        $(".page").each(function(i,n){
                            $(this).removeClass("page_red");
                        });
                        $("#page"+page).addClass("page_red");
                        $("#news").html(data.html);
                    }
                }
            })
        }
    }
    function recoverNews(param){
        if(param && parseInt(param) > 0){
            if(confirm("确定要恢复吗？")){
                $.ajax({
                    method:"post",
                    dataType:"json",
                    url:"<?php echo $this->createUrl("news/recover");?>",
                    data:{id:param},
                    success:function(data){
                        if(data){
                            window.location.href="";
                        }
                    }
                })
            }
        }
    }
</script>