            <section id="content">
                <section class="vbox">
                    <header class="header bg-white b-b b-light">
                        <p class="f16"><a href="<?php echo $this->createUrl("site/index");?>">首页</a> ->
                            <a href="<?php echo $this->createUrl("news/index");?>">新闻管理</a> ->
                            <a href="<?php echo $this->createUrl("news/index");?>">新闻内容管理</a></p>
                    </header>
                    <section class="scrollable padder">
                        <section class="panel panel-default">
                            <header class="panel-heading"> 新闻列表</header>
                            <div class="row text-sm wrapper">
                                <div class="col-sm-6 m-b-xs f16">
                                    <button type="submit" class="btn btn-success btn-s-xs"><a href="<?php echo $this->createUrl("news/add");?>" class="btn-success">添加新闻</a></button>
                                </div>
                                <form method="post" action="<?php echo $this->createUrl("news/index");?>">
                                    <div class="col-sm-5">
                                        <div class="input-group" style="float: right;display: flex;">
                                            <select name="nid" class="input-sm form-control" id="category">
                                                <option value="">全部</option>
                                            <?php if(isset($nav) && count($nav) > 0){
                                                    foreach($nav as $k =>$v){
                                            ?>
                                                <option value="<?php echo $v->id;?>" <?php echo isset($nid) && $v->id == $nid ? 'selected="selected"' : '';?>><?php echo $v->nav_name;?></option>
                                            <?php }}?>
                                            </select>
                                            <input type="text" class="input-sm form-control" placeholder="Search" name="findContent">
                                            <input type="hidden" name="csrf" id="csrf" value="<?php echo Yii::app()->request->getCsrfToken();?>">
                                            <span class="input-group-btn"><button class="btn btn-sm btn-default" type="submit" >查 询</button></span>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-striped b-t b-light text-sm">
                                    <thead>
                                    <tr>
                                        <th class="30"><input type="checkbox"></th>
                                        <th style="width:100px !important;" >序号</th>
                                        <th class="th-sortable col-sm-2" data-toggle="class">标题 </th>
                                        <th class="col-sm-5">内容</th>
                                        <th class="col-sm-1">是否热门计划</th>
                                        <th class="col-sm-2">时间</th>
                                        <th class="col-sm-2">操作</th>
                                    </tr>
                                    </thead>
                                    <tbody id="news">
                                        <?php
                                            if(isset($data)){
                                                foreach($data as $k => $v){?>
                                                    <tr>
                                                        <td><input type="checkbox" name="post[]" value="<?php echo$v->id;?>"></td>
                                                        <td><?php echo$v->id;?></td>
                                                        <td><?php echo Utils::CutString($v->title,0,80,"UTF-8");?></td>
                                                        <td>
                                                            <div style="height: 30px !important;overflow: hidden;">
                                                                <?php echo Utils::CutString($v->content,0,50,"UTF-8",true)?>
                                                            </div>
                                                        </td>
                                                        <td><?php echo $v->is_hot ? "是" : "否";?></td>
                                                       <td><?php echo date("Y-m-d H:i:s",$v->publish_time);?></td>
                                                        <td>
                                                            <div id="caozuo">
                                                                <a href="<?php echo $this->createUrl("news/update",array("id"=>$v->id));?>" class="btn btn-s-md btn-info">修 改</a>
                                                                <a onclick="deleteNews(<?php echo $v->id ;?>)" class="btn btn-s-md btn-warning mf20">删除</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php }
                                            }?>
                                    </tbody>
                                </table>
                            </div>
                            <footer class="panel-footer">
                                <div class="row">
                                    <div class="col-sm-4 hidden-xs"></div>
                                    <div class="col-sm-8 text-left text-center-xs">
                                        <?php if(isset($pages)){?>
                                        <ul class="pagination pagination-sm m-t-none m-b-none" id="pageCss">
                                            <a class="page" onclick="newContent(1)">首页</a>
                                            <?php if($pages){
                                                for($i=1;$i<=$pages;$i++){
                                                    if($i<11){
                                            ?>
                                            <a class="page  <?php echo $i == 1 ? "page_red" : "";?>" id="page<?php echo $i;?>" onclick="newContent(<?php echo $i.(isset($nid) ? ",".$nid : "")?>);"><?php echo $i;?></a>
                                            <?php }}}?>
                                            <?php
                                                if($pages > 1 && $page < $pages){
                                                    echo '<a class="page" onclick="nextPage('.(isset($nid) ? $nid : "").')">下一页</a>';
                                                }
                                            ?>
                                            <?php if($pages > 1) echo '<a class="page" onclick="newContent('.$pages.')">最后一页</a>';?>
                                            <span>共<?php echo $pages;?>页</span>
                                            <span>共<?php echo $total;?>条记录</span>
                                            <input id="inputPage" type="text" value="" style="width: 50px;margin: 0 6px;">
                                            <a class="page" onclick="inputPage(<?php echo isset($nid) ? $nid : ""?>)">跳转</a>
                                        </ul>
                                        <?php }?>
                                    </div>
                                </div>
                            </footer>
                        </section>
                    </section>
                </section>
                <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
            <aside class="bg-light lter b-l aside-md hide" id="notes">
                <div class="wrapper"><input type="hidden" id="cu_pg" value="1"></div>
            </aside>
        </section>
    </section>
</section>
<script type="text/javascript">
    function newContent(page,nid){
        commonAjax(page,nid);
    }

    function nextPage(nid){
        var page=parseInt($("#cu_pg").val())+1;
        commonAjax(page,nid);
    }

    function inputPage(nid){
        var page=parseInt($("#inputPage").val());
        commonAjax(page,nid);
    }

    function commonAjax(page,nid){
        if(page > 0 && page <= <?php echo $pages;?>){
            $.ajax({
                ur:"<?php echo $this->createUrl("news/index")?>",
                data:{page:page,nid:nid,isAjax:1},
                dataType:"json",
                method:"post",
                success:function(data){
                    if(data){
                        $(".page").each(function(i,n){
                            $(this).removeClass("page_red");
                        });
                        $("#page"+page).addClass("page_red");
                        $("#news").html(data.html);
                        $("#cu_pg").val(parseInt(data.page));
                    }
                }
            })
        }
        var pages=<?php echo $pages;?>;
        var html='<a class="page" onclick="newContent(1)">首页</a>';
        if(page >= 10 && page <= pages){
            var currentPage=page-8;
            if(pages > 10 ){
                for(var i=currentPage;i<=page+1;i++)
                   if(i <= pages) html += '<a class="page  '+(i == page ? "page_red" : "")+'" id="page'+i+'" onclick="newContent('+i+","+nid+');">'+i+'</a>';
            }
        }else if(page > 0 && page < 10 && page < pages){
            for(var i=1;i<=pages;i++){
                if(i < 11)  html += '<a class="page  '+(i == page ? "page_red" : "")+'" id="page'+i+'" onclick="newContent('+i+","+nid+');">'+i+'</a>';
            }
        }
        if(page < pages)  html += '<a class="page" onclick="nextPage('+nid+')">下一页</a>';
        html += '<a class="page" onclick="newContent(<?php echo $pages?>)">最后一页</a>'+
            '<span>共<?php echo $pages;?>页</span>'+
            '<input id="inputPage" type="text" value="" style="width: 50px;margin: 0 6px;">'+
            '<a class="page" onclick="inputPage('+nid+')">跳转</a>';
        $("#pageCss").html(html);
    }

    function deleteNews(param){
        if(param && param > 0){
            if(confirm("确定要删除吗？")){
                $.ajax({
                    method:"post",
                    dataType:"json",
                    url:"<?php echo $this->createUrl("news/delete")?>",
                    data:{id:parseInt(param),csrf:$("#csrf").val()},
                    success:function(data){
                        if(data && data == 200){
                            window.location.href="";
                        }
                    }
                })
            }
        }
    }

    function findCategory(){
        var nid=parseInt($("#category option").select().val());
        if(nid > 0){
            $.ajax({
                type:"post",
                dataType:"json",
                url:"<?php echo $this->createUrl("news/index");?>",
                data:{nid:nid,csrf:$("#csrf").val()},
                success:function(data){
                    if(data.status == 200){
                        $("#news").html(data.html);
                    }
                }
            })
        }
    }

</script>