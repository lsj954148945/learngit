<?php

class DrawLotteryController extends AdminController{
    public function actionIndex(){
        $page=(int)Yii::app()->request->getParam("page");
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=CaiKj::model()->count();
        $pages=ceil($total/$pageSize);
        $condition=array("order"=>"t.period_id desc","limit"=>$pageSize,"offset"=>0);
        if($page && $page > 0 && $page <= $pages){
            $condition["offset"]=($page-1)*$pageSize;
            $html="";
            $lottery=CaiKj::model()->with("jcxx")->findAll($condition);
            if(isset($lottery[0])){
                $num=$total-($page-1)*$pageSize;
                foreach($lottery as $k => $v){
                    $info=explode("：",preg_replace("/，|[a-zA-z]+/is","",$v->num_sym_col));
                    $html1=$html2="";
                    foreach($info as $k1 => $v1){
                        if($k1 % 2 == 0 && !empty($v1))    $html1 .=$v1." ";
                        else      $html2 .=$v1." ";
                    }
                    $html .='<tr>
                            <td><input type="checkbox" name="numberId" value="'.$v->id.'"></td>
                            <td>'.$num.'</td>
                            <td>'.$v->period_id.'</td>
                            <td>'.$html1.'</td>
                            <td>'.$html2.'</td>
                            <td>'.(isset($v->jcxx) ? ($v->jcxx->right_number ." ".$v->jcxx->symbolic_name) : "").'</td>
                            <td>'.date("Y-m-d H:i:s",strtotime($v->next_kj_time)).'</td>
                            <td>
                                <div id="caozuo">
                                    <a href="'.$this->createUrl("drawLottery/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                    <a onclick="deleteLottery('.$v->id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                                </div>
                            </td>
                        </tr>';
                    $num--;
                }
            }
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $lottery=CaiKj::model()->with("jcxx")->findAll($condition);
        $this->render("index",array("lottery"=>$lottery,"pages"=>$pages,"total"=>$total,"page"=>$page,"pageSize"=>$pageSize));
    }

    public function actionAdd(){
        $model=new CaiKj();
        if(isset($_POST["CaiKj"])){
            $model->attributes=$_POST["CaiKj"];
            $model->period_id=trim($_POST["CaiKj"]["period_id"]);
            $model->save() ? $this->redirect($this->createUrl("drawLottery/index")) : $model->getErrors();
        }
        $this->render("add",array("model"=>$model));
    }

    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiKj::model()->findByPk($id);
        if(isset($_POST["CaiKj"])){
            $model->attributes=$_POST["CaiKj"];
            $model->period_id=trim($_POST["CaiKj"]["period_id"]);
            $model->save()  ?  $this->redirect($this->createUrl("drawLottery/index")) : $this->redirect($this->createUrl("drawLottery/update",array("id"=>$model->id)));
        }
        $this->render("update",array("model"=>$model));
    }

    public function actionDelete(){
        $id=Yii::app()->request->getParam("id");
        if(strpos($id,",") === false){
            $id=intval($id);
            if($id && $id > 0){
                $res=CaiKj::model()->deleteByPk($id);
            }
        }else{
            $id=explode(",",$id);
            array_pop($id);
            $res=CaiKj::model()->deleteByPk($id);
        }
        die(json_encode($res ? 200 : -200));
    }
}