<?php

class CaptureController extends AdminController{
    public function actionIndex(){
        $page=(int)Yii::app()->request->getParam("page");
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=MbCapture::model()->count();
        $pages=ceil($total/$pageSize);
        $condition=array("limit"=>$pageSize,"offset"=>0);
        if($page > 0 && $page <= $pages){
            $condition["offset"]=($page-1)*$pageSize;
            $model=MbCapture::model()->findAll($condition);
            $html="";
            foreach($model as $k => $v){
                $html .='<tr>
                        <td><input type="checkbox" name="post[]" value="'.$v->id.'"></td>
                        <td>'.$v->id.'</td>
                        <td>'.$v->config_name.'</td>
                        <td>'.$v->capture_url.'</td>
                        <td>'.htmlentities($v->url_area).'</td>
                        <td>'.htmlentities($v->title_rule).'</td>
                        <td>'.htmlentities($v->content_rule).'</td>
                        <td>'.$v->contain_url.'</td>
                        <td>
                            <div id="caozuo">
                                <a href="'.$this->createUrl("capture/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                <a onclick="capture('.$v->id.')" class="btn btn-s-md btn-primary mf20 ">采集</a>
                                <a onclick="deleteCapture('.$v->id .')" class="btn btn-s-md btn-warning mf20">删除</a>
                            </div>
                        </td>
                    </tr>';
            }
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $model=MbCapture::model()->findAll($condition);
        $this->render("index",array("model"=>$model,"pages"=>$pages));
    }

    public function actionAdd(){
        $model=new MbCapture();
        $nav=MbNav::model()->findAll();
        if(isset($_POST["MbCapture"])){
            $model->attributes=$_POST["MbCapture"];
            $model->nav_id=$_POST["MbCapture"]["nav_id"];
            if($model->save())      $this->redirect($this->createUrl("capture/index"));
            else    $this->redirect($this->createUrl("capture/add"));
        }
        $this->render("add",array("model"=>$model,"nav"=>$nav));
    }

    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=MbCapture::model()->findByPk($id);
        $nav=MbNav::model()->findAll();
        if(isset($_POST["MbCapture"])){
            $model->attributes=$_POST["MbCapture"];
            if($model->save())      $this->redirect($this->createUrl("capture/index"));
            else    $this->redirect($this->createUrl("capture/update",array("id"=>$model->id)));
        }
        $this->render("update",array("model"=>$model,"nav"=>$nav));
    }

    public function actionDelete(){
        $id=(int)Yii::app()->request->getParam("id");
        $res=MbCapture::model()->deleteByPk($id);
        die(json_encode($res ? 200 : -200));
    }

    //栏目
    public function actionAddContent(){
        ini_set("max_execution_time",600);
        $id=(int)Yii::app()->request->getParam("id");
        if($id > 0){
            $config=MbCapture::model()->with("nav")->findByPk($id);
            $contents=file_get_contents($config->capture_url);
            $nums=$i=0;
            if($config->is_hot == 1){
                preg_match_all('/'.str_replace(Utils::$pattern,Utils::$replace,$config->contain_url).'/ism',$contents,$urls);
                $data=array();
                foreach($urls[0] as $k => $v)   $data[$k]=$config->domain.$v;
                $data=array_unique($data);
                $nums=$this::captureContent($data,$config,0,true);
            }else{
                $contents=str_replace('<div class="m_cont mTop">',"[or]",$contents);
                $contents=explode("[or]",$contents);
                foreach($contents as $c => $co){
                    if($c>2){
                        preg_match_all('/'.str_replace(Utils::$pattern,Utils::$replace,$config->contain_url).'/ism',$co,$urls);
                        preg_match('/<h2 class=\"list-tit\">.*<\/h2>/ism',$co,$period);
                        $data=array();
                        foreach($urls[0] as $k => $v)   $data[$k]=$config->domain.$v;
                        $num=$this::captureContent($data,$config,ltrim(strstr(strip_tags($period[0]),">"),">"));
                        $nums +=$num;
                    }
                }
            }
            die(json_encode(array("msg"=>($config->nav->nav_name."共发布了".$nums."条数据"))));
        }
    }

    //采集对应的栏目内容
    public static function captureContent($urls,$rule,$period,$is_hot=false){
        $i=0;
        $data=self::multiCurl($urls);
        foreach($data as $k => $v){
            $code=mb_detect_encoding($v,Utils::$all_code);
            $contents=mb_convert_encoding($v,"utf-8",$code);
            preg_match("/".str_replace(Utils::$pattern,Utils::$replace,$rule->title_rule)."/ism",$contents,$title);
            preg_match("/".str_replace(Utils::$pattern,Utils::$replace,$rule->content_rule)."/ism",$contents,$content);
            $pattern=array("</h6>","</div>","<!--内容开始--!>","<!--内容--!>","惠泽手机网投，彩票全网最高9.82倍!","7K彩票, 10元提款, 天天登陆888红包!");
            $coloum=array(
                "title"=>isset($title[0]) ? trim(strip_tags($title[0])) : "",
                "content"=>isset($content[0]) ? trim(strip_tags(str_replace($pattern,array(),$content[0]),"<br>")) : "",
                "nav_id"=>$rule->nav_id,
                "period"=>$period
            );
            $coloum["nickname"]=str_replace("胆","",ltrim(strrchr($coloum["title"],">"),">"));
            $coloum["is_hot"]=$is_hot ? 1 : 0;
            $i++;
           try{
               ($is_hot ? self::updateNav($coloum) : self::insertNav($coloum)) ? $i++ : $i;
            }catch (Exception $e){};
        }
        return $i;
    }

    public static function getImage($url,$filename){
        if(empty($url) && empty($filename))    return false;
        ob_start();
        readfile($url);
        $img=ob_get_contents();
        ob_end_clean();
        $fp=fopen($filename,"a");
        $size=fwrite($fp,$img);
        fclose($fp);
        return $size > 0 ? $filename : "";
    }

    public static function createCh($url){
        $ch=curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_USERAGENT,"Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0)");
        curl_setopt($ch,CURLOPT_REFERER,$url);//设置来源
        curl_setopt($ch,CURLOPT_ENCODING,"gzip");//编码压缩
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($ch,CURLOPT_FOLLOWLOCATION,1);
        curl_setopt($ch,CURLOPT_MAXREDIRS,5);
        curl_setopt($ch,CURLOPT_TIMEOUT,600);
        curl_setopt($ch,CURLOPT_HEADER,0);
        return $ch;
    }

    public static function multiCurl($urls=array()){
        if($urls){
            $curl=$data=array();
            $handle=curl_multi_init();
            foreach($urls as $k => $v){
                $curl[$k]=self::createCh($v);
                curl_multi_add_handle($handle,$curl[$k]);
            }
            do{
                $mrc=curl_multi_exec($handle,$active);
            }while($mrc == CURLM_CALL_MULTI_PERFORM);
            while($active && $mrc == CURLM_OK){
                if(curl_multi_select($handle) != -1)  usleep(10);
                do{
                    $mrc=curl_multi_exec($handle,$active);
                }while($mrc==CURLM_CALL_MULTI_PERFORM);
            }
            foreach($curl as $k1 => $v1){
                if(curl_error($curl[$k1]) == ""){
                    $data[$k1]=(string)curl_multi_getcontent($curl[$k1]);
                }else{
                    var_dump(curl_error($curl[$k1]));
                }

                curl_multi_remove_handle($handle,$curl[$k1]);
                curl_close($curl[$k1]);
            }
            return $data;
        }
        return false;
    }

    public static function insertNav($data){
        if($data){
            $model=new MbNews();
            $model->title=$data["title"];
            $model->content=$data["content"];
            $model->period=$data["period"];
            $model->nickname=$data["nickname"];
            $model->nav_id=$data["is_hot"] ? "0" :  $data["nav_id"];
            $model->is_hot=$data["is_hot"];
            $model->publish_time=time();
            if($model->save())  return  true;
        }
        return   false;
    }

    public static function updateNav($data){
        if($data){
            $model=MbNews::model()->find("title =:title",array(":title"=>$data["title"]));
            if($model){
                $model->is_hot=1;
                if($model->save())    return true;
            }
        }
        return false;
    }

}