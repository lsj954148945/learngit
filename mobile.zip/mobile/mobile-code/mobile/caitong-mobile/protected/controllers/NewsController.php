<?php

class NewsController extends AdminController{
    public function actionIndex(){
        $page=Yii::app()->request->getParam('page');
        $page=$page ?  $page : 1;
        $cate=Yii::app()->request->getParam('cate');
        $ajax=Yii::app()->request->getParam('isAjax');
        $content=Yii::app()->request->getParam('findContent');
        $nav_id=isset($_POST["nid"]) && !empty($_POST["nid"]);
        $nid=$nav_id ? intval($_POST["nid"]) : "";
        $criteria=new CDbCriteria();
        $criteria->order='t.id desc';
        $criteria->condition="t.status =1".($nav_id ? " and t.nav_id=".$nid : "").(!empty($content) ? " and t.content like'%".trim($content)."%'" : "");
        $total = MbNews::model()->count($criteria);
        $condition=array(
            'criteria'=>$criteria,
            'pagination'=>array(
                'pageSize'=>Utils::PAGE_SIZE_TEN,
                'currentPage'=>$page-1
            ));

        if(isset($page) && isset($ajax) && $ajax == 1){
            $condition['pagination']['currentPage']=$page-1;
            $data=(new CActiveDataProvider('MbNews',$condition))->getData();
            $html=$this->ajaxNews($data);
            die(json_encode(array('html'=>$html,'page'=>$page)));
        }

        $data=(new CActiveDataProvider('MbNews',$condition))->getData();
        $nav=MbNav::model()->findAll(array('select'=>'id,nav_name'));
        $pages=ceil($total/Utils::PAGE_SIZE_TEN);
        $data=array('data'=>$data,"pages"=>$pages,"nav"=>$nav,"page"=>$page,"nid"=>$nid,"total"=>$total);
        $data["nid"]=isset($_POST["nid"]) ? $_POST["nid"] : "";
        $this->render('index',$data);
    }

    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $nav=MbNav::model()->findAll();
        $criteria=new CDbCriteria();
        $criteria->addCondition('t.id=:id');
        $criteria->params[':id']=$id;
        $model=MbNews::model()->find($criteria);
        if(isset($_POST['MbNews']) && $_POST['MbNews']){
            preg_match_all('/src=["\"].*?["\"]/',$model->content,$match);
            $urls="";
            $num=count($match[0]);
            if($num > 0)
                for($i=0;$i<$num;$i++)      $urls .= preg_replace('/"|src=/',"",$match[0][$i]).",";
            $model->attributes=$_POST['MbNews'];
            $model->img_src=!empty($urls) ? $urls : "";
            $model->title=trim($_POST['MbNews']['title']);
            $model->content=trim($_POST['MbNews']['content']);
            $bool=$model->save();
            $this->redirect($this->createUrl($bool ? 'news/index' : 'news/update/id/'.$id));
        }
        $this->render('update',array('nav'=>$nav,"model"=>$model));
    }

    public function actionAdd(){
        $nav=MbNav::model()->findAll();
        $model=new MbNews();
        $author=MbAuthor::model()->findAll();
        if(is_array($nav) && count($nav) <= 0)    $this->redirect($this->createUrl('news/nav'));
        if(isset($_POST['MbNews'])  &&  $_POST['MbNews']){
            preg_match_all('/src=["\"].*?["\"]/',$_POST['MbNews']["content"],$match);
            $urls="";
            $num=count($match[0]);
            if($num > 0)
                for($i=0;$i<$num;$i++)      $urls .= preg_replace('/"|src=/',"",$match[0][$i]).",";
            $model->attributes=$_POST['MbNews'];
            $model->img_src=!empty($urls) ? $urls : "";
            $model->publish_time=time();
            $model->u_id=1;
            $this->redirect($this->createUrl($model->save() ? 'news/index' : 'news/add'));
        }
        $this->render('add',array('model'=>$model,'nav'=>$nav,"author"=>$author));
    }

    public function actionDelete(){
        $id=(int)Yii::app()->request->getParam("id");
        if($id && $id > 0){
            $res=MbNews::model()->updateByPk($id,array("status"=>0),"status =:status",array(":status"=>1));
            die(json_encode($res ? 200 : -200));
        }
    }

    public function actionNav(){
        header('Content-Type:text/html;charset=utf-8');
        $model=new MbNav();
        if(isset($_POST['MbNav'])){
            $model->attributes=$_POST["MbNav"];
            $model->updatetime=time();
            $model->sort=0;
            $model->save();
            $this->redirect($this->createUrl($model->save() ? 'news/menu' : 'news/nav'));
        }
        $this->render('nav',array("model"=>$model));
    }

    public function actionMenu(){
        $page=(int)Yii::app()->request->getParam("page");
        $pageSize=Utils::PAGE_SIZE_TEN;
        $condition=array("order"=>"id desc","offset"=>0,"limit"=>$pageSize);
        $total=MbNav::model()->count();
        $pages=ceil($total/$pageSize);
        if($page && $page > 0){
            $condition["offset"]=($page-1)*(Utils::PAGE_SIZE_TEN);
            $nav=MbNav::model()->findAll($condition);
            $html="";
            foreach($nav as $k => $v){
                $html .='<tr>
                            <td><input type="checkbox" name="post[]" value="'.$v->id.'"></td>
                            <td>'.$v->id.'</td>
                            <td>'.$v->nav_name.'</td>
                            <td>'.$v->title.'</td>
                            <td>'.$v->keywords.'</td>
                            <td>'.$v->nickname.'</td>
                            <td>'.date('Y-m-d',$v->addtime).'</td>
                            <td>
                                <a href="'.$this->createUrl("news/updateNav",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>
                                <a onclick="deleteNav('.$v->id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                            </td>
                        </tr>';
            }
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $nav=MbNav::model()->findAll($condition);
        $this->render('menu',array("nav"=>$nav,"pages"=>$pages));
    }

    public function actionDeleteNav(){
        $id=(int)Yii::app()->request->getParam("id");
        if($id && $id > 0){
            $res=MbNav::model()->deleteByPk($id);
            die(json_encode($res ? 200 : -200));
        }
    }

    public function actionUpdateNav($id){
        $model=MbNav::model()->findByPk($id);
        if(isset($_POST['MbNav']) && $_POST['MbNav']){
            $model->attributes=$_POST['MbNav'];
            $model->sort=0;
            $model->updatetime=time();
            if($model->save())     $this->redirect($this->createUrl('menu'));
            else    $this->redirect($this->createUrl('menu'));
        };
        $this->render('updateNav',array('model'=>$model));
    }

    public function actionSecondMenu(){
        $page=(int)Yii::app()->request->getParam("page");
        $pageSize=Utils::PAGE_SIZE_TEN;
        $total=MbNav::model()->count("n_id is not null");
        $pages=ceil($total/$pageSize);
        $condition=array("condition"=>"n_id is not null","order"=>"id desc","offset"=>0,"limit"=>$pageSize);
        $nav_name=MbNav::model()->findAll(array("select"=>"id,nav_name","condition"=>"n_id is null"));
        $arr=array();
        foreach($nav_name as $k => $v)        $arr[$v->n_id]=$v->nav_name;
        if($page && $page > 0){
            $condition["offset"]=($page-1)*$pageSize;
            $data=MbNav::model()->findAll($condition);
            $html="";
            foreach($data as $k1 => $v1){
                $html .=' <tr>
                            <td><input type="checkbox" name="post[]" value="'.$v1->n_id.'"></td>
                            <td>'.$v1->n_id.'</td>
                            <td>'.$v1->c_name.'</td>
                            <td>'.$arr[$v1->n_id].'</td>
                            <td>'.date("Y-m-d H:i:s",$v1->time).'</td>
                            <td>
                                <div id="caozuo">
                                    <a href="'.$this->createUrl("author/update",array("id"=>$v1->n_id)).'" class="btn btn-s-md btn-info">修 改</a>
                                    <a onclick="deleteSecondMenu('.$v1->n_id.')" class="btn btn-s-md btn-warning mf20">删除</a>
                                </div>
                            </td>
                        </tr>';
            }
            die(json_encode($html));
        }
        $data=MbNav::model()->findAll($condition);
        $this->render("secondMenu",array("data"=>$data,"nav_name"=>$arr,"pages"=>$pages));
    }

    public function actionAddSecondMenu(){
        $model=new MbNav();
        $nav=MbNav::model()->findAll(array("condition"=>"n_id is null"));
        if(isset($_POST["MbNav"])){
            $model->attributes=$_POST["MbNav"];
            $model->time=time();
            $res=$model->save();
            $this->redirect($this->createUrl($res ? "news/secondMenu" : "news/addSecondMenu"));
        }
        $this->render("addSecondMenu",array("nav"=>$nav,"model"=>$model));
    }

    public function actionUpdateSecondMenu(){
        $id=(int)Yii::app()->request->getParam("id");
        $nav=MbNav::model()->findAll(array("condition"=>"n_id is null"));
        $model=MbNav::model()->findByPk($id);
        if(isset($_POST["MbNav"])){
            $model->attributes=$_POST["MbNav"];
            $model->update_time=time();
            $res=$model->save();
            $this->redirect($this->createUrl($res ? "news/secondMenu" : "news/update&id=".$model->n_id));
        }
        $this->render("updateSecondMenu",array("model"=>$model,"nav"=>$nav));
    }

    public function actionDeleteSecondMenu(){
        $id=(int)Yii::app()->request->getParam("id");
        $res=MbNav::model()->deleteByPk($id);
        die(json_encode($res ? 200 : -200));
    }

    public function actionRecycleNews(){
        $page=(int)Yii::app()->request->getParam("page");
        $pageSize=Utils::PAGE_SIZE_TEN;
        $condition=array("condition"=>"status = 0","order"=>"sort desc","limit"=>$pageSize);
        $total=MbNews::model()->count($condition);
        $condition["offset"]=0;
        $pages=ceil($total/ $pageSize);
        if($page && $page > 0){
            $condition["offset"]=($page-1)*$pageSize;
            $data=MbNews::model()->findAll($condition);
            $html=$this->ajaxNews($data);
            die(json_encode(array("html"=>$html,"page"=>$page)));
        }
        $data=MbNews::model()->findAll($condition);
        $this->render("recycleNews",array("data"=>$data,"pages"=>$pages));
    }

    public function actionRecover(){
        $id=(int)Yii::app()->request->getParam("id");
        if($id && $id > 0){
            $res=MbNews::model()->updateByPk($id,array("status"=>1),"status=:status",array(":status"=>0));
            die(json_encode($res ? 200 : -200));
        }
    }

    public function ajaxNews($data){
        if(count($data) > 0){
            $html="";
            foreach($data as $k => $v){
                $html .='<tr>'.
                    '<td><input type="checkbox" name="post[]" value="'.$v->id.'"></td>'.
                    '<td>'.$v->id.'</td>'.
                    '<td>'.mb_substr($v->title,0,30,"UTF-8").'</td>'.
                    '<td><div style="height: 30px !important;overflow: hidden;">'.mb_substr(strip_tags($v->content),0,80,"UTF-8").'......</div></td>'.
                    '<td>'.($v->is_hot ? "是" : "否").'</td>'.
                    '<td>'.date("Y-m-d H:i:s",$v->publish_time).'</td>'.
                    '<td>'.
                    '<div id="caozuo">'.
                    '<a href="'.$this->createUrl("news/update",array("id"=>$v->id)).'" class="btn btn-s-md btn-info">修 改</a>'.
                    '<a href="'.$this->createUrl("news/delete",array("id"=>$v->id)).'" class="btn btn-s-md btn-warning">删除</a>'.
                    '</div>'.
                    '</td>'.
                    '</tr>';
            }
            return $html;
        }
    }

}