<?php

class FlinksController extends AdminController{
    public function actionIndex(){
        $data=CaiFlinks::model()->findAll();
        $this->render("index",array("data"=>$data));
    }

    public function actionAdd(){
        $model=new CaiFlinks();
        if(isset($_POST["CaiFlinks"])){
            $model->attributes=$_POST["CaiFlinks"];
            $model->addtime=time();
            $this->redirect($this->createUrl($model->save() ? "flinks/index" : "flinks/add"));
        }
        $this->render("add",array("model"=>$model));
    }

    public function actionUpdate(){
        $id=(int)Yii::app()->request->getParam("id");
        $model=CaiFlinks::model()->findByPk($id);
        if(isset($_POST["CaiFlinks"])){
            $model->attributes=$_POST["CaiFlinks"];
            $this->redirect($this->createUrl($model->save() ? "flinks/index" : "flinks/update&id=".$model->id));
        }
        $this->render("update",array("model"=>$model));
    }

    public function actionDelete(){
        $id=(int)Yii::app()->request->getParam("id");
        $res=CaiFlinks::model()->deleteByPk($id);
        die(json_encode($res ? 200 : -200));
    }

}