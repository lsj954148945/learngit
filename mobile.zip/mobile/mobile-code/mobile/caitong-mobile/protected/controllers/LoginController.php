<?php
/**
 * Created by JetBrains PhpStorm.
 * User: SE MON
 * Date: 17-7-27
 * Time: 下午6:23
 * To change this template use File | Settings | File Templates.
 */

class LoginController extends Controller{
    public function actions()
    {
        return array(
            // captcha action renders the CAPTCHA image displayed on the contact page
            'captcha'=>array(
                'class'=>'CCaptchaAction',
                'backColor'=>0xFFFFFF,
                'padding' => 2,
                'height' => 38,
                'maxLength' => 4,
                'minLength' => 4,
                'testLimit' =>999,
                'offset' => 4,
                //'fixedVerifyCode' => substr(md5(time()),11,4),
            ),
            // page action renders "static" pages stored under 'protected/views/site/pages'
            // They can be accessed via: index.php?r=site/page&view=FileName
            'page'=>array(
                'class'=>'CViewAction',
            ),
        );
    }
    /**
     * Displays the login page
     */
    public function actionLogin()
    {
        $this->layout="main1";
        $model=new LoginForm();
        if(isset($_POST["LoginForm"]["verifyCode"]))
        {
            if($this->createAction("captcha")->validate($_POST["LoginForm"]["verifyCode"],false)){
                $crp="caitong2017";
                $password=md5($crp.($_POST['LoginForm']['passwd']));
                if($model->login($_POST['LoginForm']["uname"],$password)){
                    Yii::app()->session["uname"]=trim($_POST["LoginForm"]["uname"]);
                    $this->redirect($this->createUrl('site/index'));
                }else{
                    $this->redirect(Yii::app()->request->getUrlReferrer());
                }
            }else{
                $model->addError("verifyCode","验证码错误");
            }
        }
        $this->render("//site/login",array("model"=>$model));
    }
}